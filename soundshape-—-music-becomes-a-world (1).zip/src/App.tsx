import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  AIAnalysisStatus,
  AudioAnalysisResult,
  DrumSoundType,
  EditScope,
  LAYER_CONFIGS,
  MultiLayerEdit,
  MusicalLayerType,
  ViewMode,
  WorldEditState,
  WorldScene,
} from './types/world';
import { extractAudioFeatures } from './audio/featureExtractor';
import { enrichSceneWithMusicalMetadata } from './audio/metadataEnricher';
import { generateSampleAudioBuffer } from './audio/sampleAudioGenerator';
import { realAudioEngine, RealAudioEngine, BeforeAfterProgress, downloadWavBlob } from './audio/realAudioEngine';

import { Header } from './components/Header';
import { LeftSidebar } from './components/LeftSidebar';
import { RightSidebar } from './components/RightSidebar';
import { BottomPlaybackBar } from './components/BottomPlaybackBar';
import { MusicWorldCanvas } from './three/MusicWorldCanvas';
import { EmptyStateModal } from './components/EmptyStateModal';
import { GeminiAnalysisModal } from './components/GeminiAnalysisModal';
import { DifferentiationDemoModal } from './components/DifferentiationDemoModal';
import { AudioPipelineTestModal } from './components/AudioPipelineTestModal';
import { SelectedSculptureType } from './three/SceneManager';
import { Sparkles, Activity } from 'lucide-react';

export const App: React.FC = () => {
  // Application State
  const [scene, setScene] = useState<WorldScene | null>(null);
  const [audioAnalysis, setAudioAnalysis] = useState<AudioAnalysisResult | null>(null);
  const [editState, setEditState] = useState<WorldEditState>({});
  const [filename, setFilename] = useState<string>('');
  const [duration, setDuration] = useState<number>(0);
  const [tempo, setTempo] = useState<number>(120);

  // View & Interaction state
  const [viewMode, setViewMode] = useState<ViewMode>('world');
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null);
  const [selectedStepIndex, setSelectedStepIndex] = useState<number | null>(null);
  const [selectedSculptureType, setSelectedSculptureType] = useState<SelectedSculptureType | null>(null);
  const [interactionMode, setInteractionMode] = useState<'explore' | 'edit'>('explore');
  const [isCinemaMode, setIsCinemaMode] = useState<boolean>(false);

  // Multi-Layer Spatial Music Editing State (Prompt 4)
  const [activeLayer, setActiveLayer] = useState<MusicalLayerType>('energy');
  const [editScope, setEditScope] = useState<EditScope>('moment');
  const [momentDuration, setMomentDuration] = useState<number>(0.5);
  const [multiLayerEdits, setMultiLayerEdits] = useState<MultiLayerEdit[]>([]);
  const [selectedTimestamp, setSelectedTimestamp] = useState<number | null>(null);

  // AI Analysis status & Modals
  const [aiStatus, setAiStatus] = useState<AIAnalysisStatus>('idle');
  const [modelUsed, setModelUsed] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isBlueprintOpen, setIsBlueprintOpen] = useState<boolean>(false);
  const [isDemoOpen, setIsDemoOpen] = useState<boolean>(false);
  const [isAudioTestOpen, setIsAudioTestOpen] = useState<boolean>(false);
  const [comparisonProgress, setComparisonProgress] = useState<BeforeAfterProgress | null>(null);
  const [comparisonToast, setComparisonToast] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  // Playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackTime, setPlaybackTime] = useState<number>(0);
  const [isEditedMode, setIsEditedMode] = useState<boolean>(true);
  const [followMusicMode, setFollowMusicMode] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.85);

  // Audio Context & Buffer Refs
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const animFrameRef = useRef<number>(0);
  const hiddenFileInputRef = useRef<HTMLInputElement>(null);
  const momentTimerRef = useRef<number | null>(null);

  // Initialize Web Audio Context via RealAudioEngine
  const ensureAudioContext = () => {
    const ctx = realAudioEngine.init();
    realAudioEngine.setMasterVolume(volume);
    realAudioEngine.setEditedMode(isEditedMode);
    return ctx;
  };

  // Helper to build initial edit state from a scene
  const buildInitialEditState = (newScene: WorldScene): WorldEditState => {
    const edits: WorldEditState = {};
    newScene.sections.forEach((sec) => {
      const rhythmObj = sec.objects.find((o) => o.type === 'rhythm_towers');
      const bassObj = sec.objects.find((o) => o.type === 'bass_river');
      const coreObj = sec.objects.find((o) => o.type === 'energy_core');

      edits[sec.id] = {
        rhythmSteps: rhythmObj?.rhythmSteps ? JSON.parse(JSON.stringify(rhythmObj.rhythmSteps)) : [],
        rhythmDensity: 0.7,
        bassIntensity: bassObj?.bassIntensity ?? 0.5,
        energyLevel: coreObj?.energyLevel ?? sec.energy,
      };
    });
    return edits;
  };

  // Process an AudioBuffer through the full pipeline
  const processAudioBuffer = async (buffer: AudioBuffer, trackName: string) => {
    stopAudio();
    audioBufferRef.current = buffer;
    realAudioEngine.setBuffer(buffer);
    realAudioEngine.setEditedMode(isEditedMode);
    realAudioEngine.setMasterVolume(volume);

    setFilename(trackName);
    setDuration(buffer.duration);
    setPlaybackTime(0);

    // Step 2: Extract features
    setAiStatus('extracting_features');
    await new Promise((r) => setTimeout(r, 60)); // Allow UI tick

    const analysis = extractAudioFeatures(buffer);
    setAudioAnalysis(analysis);
    setTempo(analysis.tempoEstimate);

    // Step 3: Request Gemini analysis
    setAiStatus('requesting_gemini');
    try {
      const response = await fetch('/api/analyze-world', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioFeatures: analysis,
          filename: trackName,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Gemini API call failed');
      }

      setAiStatus('building_world');
      await new Promise((r) => setTimeout(r, 60));

      const rawScene: WorldScene = data.scene;
      const model = data.modelUsed || 'gemini-4-argon';
      setModelUsed(model);

      const enrichedScene = enrichSceneWithMusicalMetadata(rawScene, analysis);
      setScene(enrichedScene);
      setEditState(buildInitialEditState(enrichedScene));
      setAiStatus('gemini_complete');
      setViewMode('world');
      setSelectedSectionId(enrichedScene.sections[0]?.id || null);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn('[SoundShape] Gemini request failed:', msg);
      setErrorMessage(msg);
      setAiStatus('gemini_failed');
    }
  };

  // Switch to honest local procedural generation fallback
  const handleUseLocalFallback = async () => {
    if (!audioAnalysis) return;
    setAiStatus('building_world');

    try {
      const res = await fetch('/api/local-world', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioFeatures: audioAnalysis,
          filename,
        }),
      });
      const data = await res.json();
      if (data.success) {
        const rawScene: WorldScene = data.scene;
        const localScene = enrichSceneWithMusicalMetadata(rawScene, audioAnalysis);
        setScene(localScene);
        setModelUsed('local-audio-engine');
        setEditState(buildInitialEditState(localScene));
        setAiStatus('local_only');
        setViewMode('world');
        setSelectedSectionId(localScene.sections[0]?.id || null);
      }
    } catch {
      // Fallback directly
      setAiStatus('local_only');
    }
  };

  // Listen to 2 seconds of the recording around a selected timestamp
  const handleListenToMoment = (timestamp: number) => {
    if (!audioBufferRef.current) return;
    ensureAudioContext();

    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }

    const startOffset = Math.max(0, timestamp - 1.0);
    realAudioEngine.seek(startOffset);
    realAudioEngine.play(startOffset, () => {
      setIsPlaying(false);
    });
    setPlaybackTime(startOffset);
    setIsPlaying(true);

    momentTimerRef.current = window.setTimeout(() => {
      realAudioEngine.stop();
      setIsPlaying(false);
    }, 2200);
  };

  // Verified 2-3 Second Before / After Comparison around the selected sculpture
  const handleCompareMoment = async (timestamp: number) => {
    if (!audioBufferRef.current || !scene || !selectedSectionId) return;
    ensureAudioContext();

    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }

    const start = Math.max(0, timestamp - 1.2);

    await realAudioEngine.playBeforeAfterComparison({
      startSeconds: start,
      durationSeconds: 2.5,
      sectionId: selectedSectionId,
      scene,
      editState,
      onProgress: (p) => {
        setComparisonProgress(p);
        setComparisonToast(p.label);
        if (p.phase === 'before' || p.phase === 'after') {
          setIsPlaying(true);
        } else {
          setIsPlaying(false);
        }
        if (p.phase === 'complete') {
          setIsPlaying(false);
          setTimeout(() => {
            setComparisonProgress(null);
            setComparisonToast(null);
          }, 2400);
        }
      },
    });
  };

  // Handle User File Upload
  const handleFileUpload = async (file: File) => {
    try {
      setAiStatus('decoding');
      const ctx = ensureAudioContext();
      const arrayBuffer = await file.arrayBuffer();
      const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
      await processAudioBuffer(audioBuffer, file.name);
    } catch (err) {
      console.error('[SoundShape] Failed to decode audio file:', err);
      setErrorMessage('Could not decode audio file. Please try a valid MP3 or WAV clip.');
      setAiStatus('gemini_failed');
    }
  };

  // Handle Load Sample (Cosmic Aurora or Cyber Pulse Apex)
  const handleLoadSample = async (type: 'cosmic' | 'cyber' = 'cosmic') => {
    try {
      setAiStatus('decoding');
      ensureAudioContext();
      const sample =
        type === 'cyber'
          ? await (await import('./audio/sampleAudioGenerator')).generateCyberPulseSampleBuffer()
          : await generateSampleAudioBuffer();
      await processAudioBuffer(sample.audioBuffer, sample.filename);
    } catch (err) {
      console.error('[SoundShape] Sample generation error:', err);
      setErrorMessage('Failed to generate sample audio.');
      setAiStatus('gemini_failed');
    }
  };

  // Playback Control: Start / Resume
  const playAudio = () => {
    ensureAudioContext();
    if (!audioBufferRef.current) return;

    realAudioEngine.setEditedMode(isEditedMode);
    realAudioEngine.play(playbackTime, () => {
      setIsPlaying(false);
    });
    setIsPlaying(true);
  };

  // Playback Control: Stop / Pause
  const stopAudio = () => {
    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }
    const offset = realAudioEngine.stop();
    setPlaybackTime(offset);
    setIsPlaying(false);
  };

  // Toggle Play / Pause
  const handleTogglePlay = () => {
    if (isPlaying) {
      stopAudio();
    } else {
      playAudio();
    }
  };

  // Seek Timeline
  const handleSeek = (newTime: number) => {
    const clamped = Math.max(0, Math.min(duration, newTime));
    realAudioEngine.seek(clamped, () => setIsPlaying(false));
    setPlaybackTime(clamped);
  };

  // Restart from beginning
  const handleRestart = () => {
    handleSeek(0);
  };

  // Volume Change
  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    realAudioEngine.setMasterVolume(newVol);
  };

  // Toggle Original vs Edited Mode (Seamless non-destructive crossfade)
  const handleToggleEditedMode = () => {
    const nextMode = !isEditedMode;
    setIsEditedMode(nextMode);
    realAudioEngine.setEditedMode(nextMode);
  };

  // Continuous playback tick & real audio DSP automation
  useEffect(() => {
    const tick = () => {
      if (isPlaying) {
        const cur = realAudioEngine.getCurrentPlaybackTime();
        setPlaybackTime(cur);

        // Process real audio DSP automation (Multi-Layer + Rhythm + Bass + Energy)
        if (scene && scene.sections.length > 0) {
          realAudioEngine.processPlaybackTick(cur, scene, editState, multiLayerEdits);
        }
      }
      animFrameRef.current = requestAnimationFrame(tick);
    };

    animFrameRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isPlaying, scene, editState, isEditedMode, multiLayerEdits]);

  // View Navigation Handlers
  const handleSelectSection = useCallback((sectionId: string) => {
    setSelectedSectionId(sectionId);
    setSelectedStepIndex(null);
    setSelectedSculptureType(null);
    setViewMode('section');
    if (scene) {
      const sec = scene.sections.find((s) => s.id === sectionId);
      if (sec) {
        setSelectedTimestamp((sec.start + sec.end) / 2);
      }
    }
  }, [scene]);

  const handleSelectElement = useCallback((sectionId: string, stepIndex: number) => {
    setSelectedSectionId(sectionId);
    setSelectedStepIndex(stepIndex);
    setSelectedSculptureType('rhythm_tower');
    setActiveLayer('treble');
    setViewMode('element');
    const sec = scene?.sections.find((s) => s.id === sectionId);
    const secEdit = editState[sectionId];
    const step = secEdit?.rhythmSteps.find((s) => s.index === stepIndex);
    if (sec && step) {
      const t = step.eventTimeSeconds ?? sec.start + step.timeRatio * (sec.end - sec.start);
      setSelectedTimestamp(t);
    }
  }, [scene, editState]);

  const handleSelectSculpture = useCallback((sectionId: string, type: SelectedSculptureType) => {
    setSelectedSectionId(sectionId);
    setSelectedSculptureType(type);
    setSelectedStepIndex(null);
    if (type === 'bass_river') setActiveLayer('bass');
    if (type === 'energy_core') setActiveLayer('energy');
    if (scene) {
      const sec = scene.sections.find((s) => s.id === sectionId);
      if (sec) setSelectedTimestamp((sec.start + sec.end) / 2);
    }
    if (viewMode === 'world') {
      setViewMode('section');
    }
  }, [viewMode, scene]);

  const handleSelectTime = useCallback((time: number) => {
    setSelectedTimestamp(time);
    if (scene) {
      const sec = scene.sections.find((s) => time >= s.start && time <= s.end);
      if (sec) {
        setSelectedSectionId(sec.id);
      }
    }
  }, [scene]);

  const handleSetViewMode = useCallback((mode: ViewMode, sectionId?: string) => {
    setViewMode(mode);
    if (mode === 'world') {
      setSelectedStepIndex(null);
      setSelectedSculptureType(null);
    } else if (mode === 'section') {
      if (sectionId) setSelectedSectionId(sectionId);
      setSelectedStepIndex(null);
      setSelectedSculptureType(null);
    } else if (mode === 'element') {
      if (selectedStepIndex === null) {
        setSelectedStepIndex(0);
        setSelectedSculptureType('rhythm_tower');
      }
    }
  }, [selectedStepIndex]);

  // Sculptural Editing Handlers (Updating State and Real-Time DSP)
  const handleUpdateStep = (
    sectionId: string,
    stepIndex: number,
    updates: { intensity?: number; active?: boolean; type?: DrumSoundType }
  ) => {
    setEditState((prev) => {
      const sec = prev[sectionId];
      if (!sec) return prev;
      const newSteps = sec.rhythmSteps.map((s) => {
        if (s.index === stepIndex) {
          return {
            ...s,
            intensity: updates.intensity !== undefined ? updates.intensity : s.intensity,
            active: updates.active !== undefined ? updates.active : s.active,
            type: updates.type !== undefined ? updates.type : s.type,
          };
        }
        return s;
      });
      return {
        ...prev,
        [sectionId]: {
          ...sec,
          rhythmSteps: newSteps,
        },
      };
    });
  };

  const handleTowerIntensityChange = useCallback((sectionId: string, stepIndex: number, intensity: number) => {
    handleUpdateStep(sectionId, stepIndex, { intensity });
  }, []);

  const handleUpdateSectionRhythmDensity = (sectionId: string, density: number) => {
    setEditState((prev) => {
      const sec = prev[sectionId];
      if (!sec) return prev;
      const totalSteps = sec.rhythmSteps.length;
      const activeCount = Math.round(density * totalSteps);
      const newSteps = sec.rhythmSteps.map((s, idx) => ({
        ...s,
        active: idx < activeCount || s.index === 0,
      }));
      return {
        ...prev,
        [sectionId]: {
          ...sec,
          rhythmDensity: density,
          rhythmSteps: newSteps,
        },
      };
    });
  };

  const handleUpdateSectionBass = (sectionId: string, bass: number) => {
    // Real-time DSP update
    realAudioEngine.updateBassInRealtime(RealAudioEngine.bassIntensityToDb(bass));

    setEditState((prev) => {
      const sec = prev[sectionId];
      if (!sec) return prev;
      return {
        ...prev,
        [sectionId]: {
          ...sec,
          bassIntensity: bass,
        },
      };
    });
  };

  const handleUpdateSectionEnergy = (sectionId: string, energy: number) => {
    // Real-time DSP update
    realAudioEngine.updateEnergyInRealtime(RealAudioEngine.energyLevelToLinearGain(energy));

    setEditState((prev) => {
      const sec = prev[sectionId];
      if (!sec) return prev;
      return {
        ...prev,
        [sectionId]: {
          ...sec,
          energyLevel: energy,
        },
      };
    });
  };

  const handleResetElement = (sectionId: string, stepIndex: number) => {
    if (!scene) return;
    const sec = scene.sections.find((s) => s.id === sectionId);
    const origObj = sec?.objects.find((o) => o.type === 'rhythm_towers');
    const origStep = origObj?.rhythmSteps?.find((s) => s.index === stepIndex);
    if (origStep) {
      handleUpdateStep(sectionId, stepIndex, {
        intensity: origStep.intensity,
        active: origStep.active,
        type: origStep.type,
      });
    }
  };

  const handleResetSection = (sectionId: string) => {
    if (!scene) return;
    const origSec = scene.sections.find((s) => s.id === sectionId);
    if (!origSec) return;
    const origRhythm = origSec.objects.find((o) => o.type === 'rhythm_towers');
    const origBass = origSec.objects.find((o) => o.type === 'bass_river');
    const origCore = origSec.objects.find((o) => o.type === 'energy_core');

    const defaultBass = origBass?.bassIntensity ?? 0.5;
    const defaultEnergy = origCore?.energyLevel ?? origSec.energy;

    realAudioEngine.updateBassInRealtime(RealAudioEngine.bassIntensityToDb(defaultBass));
    realAudioEngine.updateEnergyInRealtime(RealAudioEngine.energyLevelToLinearGain(defaultEnergy));

    setEditState((prev) => ({
      ...prev,
      [sectionId]: {
        rhythmSteps: origRhythm?.rhythmSteps ? JSON.parse(JSON.stringify(origRhythm.rhythmSteps)) : [],
        rhythmDensity: 0.7,
        bassIntensity: defaultBass,
        energyLevel: defaultEnergy,
      },
    }));
  };

  const handleResetWorld = () => {
    if (scene) {
      setEditState(buildInitialEditState(scene));
      realAudioEngine.updateBassInRealtime(0.0);
      realAudioEngine.updateEnergyInRealtime(1.0);
    }
  };

  // Multi-Layer Edit Creator/Updater (Prompt 4)
  const handleUpdateLayerEdit = (layer: MusicalLayerType, editedValue: number) => {
    if (!scene || !selectedSectionId) return;
    const sec = scene.sections.find((s) => s.id === selectedSectionId);
    if (!sec) return;

    const centerTime = selectedTimestamp !== null ? selectedTimestamp : (sec.start + sec.end) / 2;
    let startTime: number;
    let endTime: number;

    if (editScope === 'moment') {
      const dur = Math.max(0.2, Math.min(2.0, momentDuration));
      startTime = Math.max(0, centerTime - dur / 2);
      endTime = Math.min(duration || scene.duration, startTime + dur);
    } else {
      startTime = sec.start;
      endTime = sec.end;
    }

    const cfg = LAYER_CONFIGS[layer];

    setMultiLayerEdits((prev) => {
      const existingIdx = prev.findIndex(
        (e) =>
          e.sectionId === selectedSectionId &&
          e.layer === layer &&
          e.scope === editScope &&
          Math.abs(e.startTime - startTime) < 0.25
      );

      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = {
          ...copy[existingIdx],
          editedValue,
          enabled: true,
        };
        return copy;
      } else {
        const newEdit: MultiLayerEdit = {
          editId: `edit_${layer}_${Date.now()}`,
          sectionId: selectedSectionId,
          scope: editScope,
          startTime,
          endTime,
          layer,
          property: cfg.property,
          originalValue: cfg.defaultValue,
          editedValue,
          unit: cfg.unit,
          enabled: true,
        };
        return [...prev, newEdit];
      }
    });

    if (layer === 'energy') {
      realAudioEngine.updateEnergyInRealtime(RealAudioEngine.dbToLinear(editedValue));
    } else if (layer === 'bass') {
      realAudioEngine.updateBassInRealtime(editedValue);
    } else if (layer === 'treble') {
      realAudioEngine.updateTrebleInRealtime(editedValue);
    } else if (layer === 'texture') {
      realAudioEngine.updateTextureInRealtime(editedValue);
    }
  };

  const handleDeleteLayerEdit = (editId: string) => {
    setMultiLayerEdits((prev) => prev.filter((e) => e.editId !== editId));
  };

  const handleToggleLayerEdit = (editId: string) => {
    setMultiLayerEdits((prev) =>
      prev.map((e) => (e.editId === editId ? { ...e, enabled: !e.enabled } : e))
    );
  };

  const handleResetLayerProperty = (layer: MusicalLayerType) => {
    const cfg = LAYER_CONFIGS[layer];
    handleUpdateLayerEdit(layer, cfg.defaultValue);
  };

  const handleExportWav = async () => {
    if (!scene || !audioBufferRef.current) return;
    try {
      const blob = await realAudioEngine.exportEditedAudioWav(scene, editState, multiLayerEdits);
      const safeName = (filename || 'soundshape_track').replace(/\.[^/.]+$/, '');
      downloadWavBlob(blob, `${safeName}_soundshape_edited.wav`);
    } catch (err) {
      console.error('[SoundShape] WAV export failed:', err);
    }
  };

  const handlePlayBeforeAudition = async (start: number, end: number) => {
    if (!audioBufferRef.current || !scene) return;
    ensureAudioContext();
    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }
    const durationSec = Math.max(0.5, Math.min(4.0, end - start));
    await realAudioEngine.playBeforeAudition({
      startSeconds: start,
      durationSeconds: durationSec,
      onProgress: (p) => {
        setComparisonProgress(p);
        setIsPlaying(p.phase === 'before');
        if (p.phase === 'complete') {
          setIsPlaying(false);
          setTimeout(() => {
            setComparisonProgress((prev) => (prev?.type === 'before_only' ? null : prev));
          }, 1500);
        }
      },
    });
  };

  const handlePlayAfterAudition = async (start: number, end: number) => {
    if (!audioBufferRef.current || !scene || !selectedSectionId) return;
    ensureAudioContext();
    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }
    const durationSec = Math.max(0.5, Math.min(4.0, end - start));
    await realAudioEngine.playAfterAudition({
      startSeconds: start,
      durationSeconds: durationSec,
      sectionId: selectedSectionId,
      scene,
      editState,
      multiLayerEdits,
      onProgress: (p) => {
        setComparisonProgress(p);
        setIsPlaying(p.phase === 'after');
        if (p.phase === 'complete') {
          setIsPlaying(false);
          setTimeout(() => {
            setComparisonProgress((prev) => (prev?.type === 'after_only' ? null : prev));
          }, 1500);
        }
      },
    });
  };

  const handlePlayABComparison = async (start: number, end: number) => {
    if (!audioBufferRef.current || !scene || !selectedSectionId) return;
    ensureAudioContext();
    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }
    const durationSec = Math.min(3.0, Math.max(1.8, end - start));
    await realAudioEngine.playBeforeAfterComparison({
      startSeconds: start,
      durationSeconds: durationSec,
      sectionId: selectedSectionId,
      scene,
      editState,
      multiLayerEdits,
      onProgress: (p) => {
        setComparisonProgress(p);
        setIsPlaying(p.phase === 'before' || p.phase === 'after');
        if (p.phase === 'complete') {
          setIsPlaying(false);
          setTimeout(() => {
            setComparisonProgress((prev) => (prev?.type === 'ab_comparison' ? null : prev));
          }, 2400);
        }
      },
    });
  };

  const handleStopComparison = () => {
    if (momentTimerRef.current) {
      clearTimeout(momentTimerRef.current);
      momentTimerRef.current = null;
    }
    realAudioEngine.cancelComparison();
    setComparisonProgress(null);
    setIsPlaying(false);
  };

  const handleListenToWindow = (start: number, end: number) => {
    handlePlayAfterAudition(start, end);
  };

  const handleCompareWindow = (start: number, end: number) => {
    handlePlayABComparison(start, end);
  };

  const handleVerifyAndRepairWorld = async () => {
    if (!scene) return;
    setIsVerifying(true);
    try {
      const response = await fetch('/api/verify-and-repair', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scene,
          audioFeatures: audioAnalysis,
        }),
      });
      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Verification and repair failed');
      }

      const repairedScene: WorldScene = data.scene;
      const enrichedScene = enrichSceneWithMusicalMetadata(repairedScene, audioAnalysis);
      setScene(enrichedScene);
      setComparisonToast('Argon World Verification & Integrity Seal Complete ✓');
      setTimeout(() => setComparisonToast(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn('[SoundShape] Verify and repair failed:', msg);
      setComparisonToast(`Verification: ${msg}`);
      setTimeout(() => setComparisonToast(null), 3000);
    } finally {
      setIsVerifying(false);
    }
  };

  const selectedStep =
    selectedSectionId && selectedStepIndex !== null
      ? editState[selectedSectionId]?.rhythmSteps.find((s) => s.index === selectedStepIndex)
      : null;
  const activeTimestamp =
    selectedTimestamp !== null ? selectedTimestamp : (selectedStep?.eventTimeSeconds ?? null);

  return (
    <div className="flex flex-col w-screen h-screen bg-[#070A14] text-[#EAF2FF] overflow-hidden font-['Inter',sans-serif]">
      {/* Hidden File Input for MP3 / Audio upload */}
      <input
        ref={hiddenFileInputRef}
        type="file"
        accept="audio/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFileUpload(file);
        }}
      />

      {/* Top Header Bar */}
      <Header
        scene={scene}
        viewMode={viewMode}
        selectedSectionId={selectedSectionId}
        selectedStepIndex={selectedStepIndex}
        aiStatus={aiStatus}
        modelUsed={modelUsed}
        isCinemaMode={isCinemaMode}
        onSetViewMode={handleSetViewMode}
        onToggleCinemaMode={() => setIsCinemaMode((prev) => !prev)}
        onResetWorld={handleResetWorld}
        onOpenBlueprint={() => setIsBlueprintOpen(true)}
        onOpenDemo={() => setIsDemoOpen(true)}
        onOpenAudioTests={() => setIsAudioTestOpen(true)}
      />

      {/* Main Studio Workspace */}
      <div className="flex flex-1 relative overflow-hidden">
        {/* Left Sidebar (Music Track Overview & Section Navigation) */}
        {!isCinemaMode && (
          <LeftSidebar
            scene={scene}
            filename={filename}
            duration={duration}
            tempo={tempo}
            isPlaying={isPlaying}
            selectedSectionId={selectedSectionId}
            onFileUpload={handleFileUpload}
            onLoadSample={handleLoadSample}
            onSelectSection={handleSelectSection}
            onTogglePlay={handleTogglePlay}
          />
        )}

        {/* Center 3D Music World Canvas */}
        <main className="flex-1 relative h-full bg-[#070A14] overflow-hidden">
          <MusicWorldCanvas
            scene={scene}
            viewMode={viewMode}
            selectedSectionId={selectedSectionId}
            selectedStepIndex={selectedStepIndex}
            selectedSculptureType={selectedSculptureType}
            activeLayer={activeLayer}
            selectedTimestamp={activeTimestamp}
            editScope={editScope}
            interactionMode={interactionMode}
            playbackTime={playbackTime}
            isPlaying={isPlaying}
            isEditedMode={isEditedMode}
            editState={editState}
            followMusicMode={followMusicMode}
            onSelectSection={handleSelectSection}
            onSelectElement={handleSelectElement}
            onSelectSculpture={handleSelectSculpture}
            onSelectLayer={setActiveLayer}
            onScopeChange={setEditScope}
            onInteractionModeChange={setInteractionMode}
            onTowerIntensityChange={handleTowerIntensityChange}
            onBassIntensityChange={handleUpdateSectionBass}
            onEnergyLevelChange={handleUpdateSectionEnergy}
            onViewModeChange={handleSetViewMode}
          />

          {/* Floating Comparison Progress Banner (Requirement 6 & 8) */}
          {comparisonProgress && (
            <div className="absolute top-14 left-1/2 -translate-x-1/2 z-40 px-5 py-3 rounded-2xl bg-[#0B1020]/95 border border-[#62D5E8]/40 shadow-2xl flex flex-col gap-1.5 animate-fade-in pointer-events-none min-w-[280px]">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#62D5E8] animate-ping" />
                  <span className="text-xs font-bold text-white tracking-wide">
                    {comparisonProgress.label}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-[#62D5E8]">
                  {Math.round(comparisonProgress.progressRatio * 100)}%
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#62D5E8] to-[#A58BFA] transition-all duration-100"
                  style={{ width: `${Math.round(comparisonProgress.progressRatio * 100)}%` }}
                />
              </div>
            </div>
          )}

          {/* Simple Toast Fallback */}
          {!comparisonProgress && comparisonToast && (
            <div className="absolute top-14 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-xl bg-[#111A30]/95 border border-[#62D5E8]/40 shadow-2xl flex items-center gap-2 animate-fade-in pointer-events-none">
              <div className="w-2 h-2 rounded-full bg-[#62D5E8] animate-ping" />
              <span className="text-xs font-semibold text-white tracking-wide">
                {comparisonToast}
              </span>
            </div>
          )}

          {/* Empty / Loading / Error Overlay Modal */}
          <EmptyStateModal
            status={aiStatus}
            errorMessage={errorMessage}
            onOpenUpload={() => hiddenFileInputRef.current?.click()}
            onLoadSample={handleLoadSample}
            onRetryGemini={() => {
              if (audioBufferRef.current) processAudioBuffer(audioBufferRef.current, filename);
            }}
            onUseLocalFallback={handleUseLocalFallback}
          />
        </main>

        {/* Right Sidebar (Object Inspector) */}
        {!isCinemaMode && (
          <RightSidebar
            scene={scene}
            editState={editState}
            viewMode={viewMode}
            selectedSectionId={selectedSectionId}
            selectedStepIndex={selectedStepIndex}
            selectedSculptureType={selectedSculptureType}
            activeLayer={activeLayer}
            editScope={editScope}
            momentDuration={momentDuration}
            multiLayerEdits={multiLayerEdits}
            selectedTimestamp={activeTimestamp}
            onSelectLayer={setActiveLayer}
            onScopeChange={setEditScope}
            onMomentDurationChange={setMomentDuration}
            onUpdateLayerEdit={handleUpdateLayerEdit}
            onDeleteLayerEdit={handleDeleteLayerEdit}
            onToggleLayerEdit={handleToggleLayerEdit}
            onResetLayerProperty={handleResetLayerProperty}
            onExportWav={handleExportWav}
            onUpdateStep={handleUpdateStep}
            onUpdateSectionRhythmDensity={handleUpdateSectionRhythmDensity}
            onUpdateSectionBass={handleUpdateSectionBass}
            onUpdateSectionEnergy={handleUpdateSectionEnergy}
            onResetElement={handleResetElement}
            onResetSection={handleResetSection}
            onBackToSection={() => {
              if (selectedSectionId) handleSelectSection(selectedSectionId);
            }}
            onBackToWorld={() => handleSetViewMode('world')}
            comparisonProgress={comparisonProgress}
            onPlayBeforeAudition={handlePlayBeforeAudition}
            onPlayAfterAudition={handlePlayAfterAudition}
            onPlayABComparison={handlePlayABComparison}
            onStopComparison={handleStopComparison}
            onListenToMoment={handleListenToMoment}
            onCompareMoment={handleCompareMoment}
            onListenToWindow={handleListenToWindow}
            onCompareWindow={handleCompareWindow}
            onOpenAudioTests={() => setIsAudioTestOpen(true)}
          />
        )}
      </div>

      {/* Bottom Playback Bar with Object Timeline Markers and Follow Music Mode */}
      <BottomPlaybackBar
        scene={scene}
        editState={editState}
        playbackTime={playbackTime}
        duration={duration}
        isPlaying={isPlaying}
        isEditedMode={isEditedMode}
        volume={volume}
        selectedTimestamp={activeTimestamp}
        selectedSectionId={selectedSectionId}
        activeLayer={activeLayer}
        editScope={editScope}
        momentDuration={momentDuration}
        multiLayerEdits={multiLayerEdits}
        followMusicMode={followMusicMode}
        onTogglePlay={handleTogglePlay}
        onSeek={handleSeek}
        onToggleEditedMode={handleToggleEditedMode}
        onVolumeChange={handleVolumeChange}
        onRestart={handleRestart}
        onToggleFollowMusic={() => setFollowMusicMode((prev) => !prev)}
        onListenToMoment={handleListenToMoment}
        onSelectElement={handleSelectElement}
        onSelectTime={handleSelectTime}
      />

      {/* Inspectable Gemini Blueprint Summary Modal (Requirement 9 & Argon Verification) */}
      <GeminiAnalysisModal
        isOpen={isBlueprintOpen}
        onClose={() => setIsBlueprintOpen(false)}
        scene={scene}
        audioAnalysis={audioAnalysis}
        modelUsed={modelUsed}
        aiStatus={aiStatus}
        filename={filename}
        onVerifyAndRepair={handleVerifyAndRepairWorld}
        isVerifying={isVerifying}
      />

      {/* 30-Second Differentiation Tour Modal (Requirement 11) */}
      <DifferentiationDemoModal
        isOpen={isDemoOpen}
        onClose={() => setIsDemoOpen(false)}
        onLoadCosmic={() => handleLoadSample('cosmic')}
        onLoadCyber={() => handleLoadSample('cyber')}
        onSelectSampleTower={() => {
          if (scene && scene.sections[0]) {
            handleSelectElement(scene.sections[0].id, 0);
          }
        }}
        onCompareCurrentMoment={() => {
          if (selectedTimestamp !== null) {
            handleCompareMoment(selectedTimestamp);
          } else if (scene && scene.sections[0]) {
            handleCompareMoment(scene.sections[0].start + 1.0);
          }
        }}
      />

      {/* Automated OfflineAudioContext DSP Test Suite Modal (Requirement 9) */}
      <AudioPipelineTestModal
        isOpen={isAudioTestOpen}
        onClose={() => setIsAudioTestOpen(false)}
        audioBuffer={audioBufferRef.current}
        filename={filename}
      />
    </div>
  );
};

export default App;
