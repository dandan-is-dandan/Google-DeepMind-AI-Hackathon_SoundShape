import { DrumSoundType, RhythmStep, WorldEditState } from '../types/world';

/**
 * Web Audio Real-time Synthesis Engine.
 * Translates 3D musical sculpture edits into audible synthesized layers
 * synchronized with audio playback or triggered as live audition previews.
 */
export class SoundShapeSynthEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private scheduledEvents: number[] = [];

  constructor() {
    // Lazy initialized on first user interaction
  }

  public init(context?: AudioContext) {
    if (!this.ctx) {
      this.ctx = context || new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    if (!this.masterGain && this.ctx) {
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);

      this.compressor = this.ctx.createDynamicsCompressor();
      this.compressor.threshold.setValueAtTime(-10, this.ctx.currentTime);
      this.compressor.knee.setValueAtTime(8, this.ctx.currentTime);
      this.compressor.ratio.setValueAtTime(6, this.ctx.currentTime);
      this.compressor.attack.setValueAtTime(0.003, this.ctx.currentTime);
      this.compressor.release.setValueAtTime(0.08, this.ctx.currentTime);

      this.masterGain.connect(this.compressor);
      this.compressor.connect(this.ctx.destination);
    }
    return this.ctx;
  }

  public getContext(): AudioContext | null {
    return this.ctx;
  }

  public setMasterVolume(volume: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime, 0.05);
    }
  }

  /**
   * Instantly auditions a drum hit when the user clicks or drags a Rhythm Tower.
   */
  public previewDrumHit(type: DrumSoundType, intensity: number) {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const velocity = Math.max(0.1, Math.min(1, intensity));

    switch (type) {
      case 'kick':
        this.triggerKick(now, velocity);
        break;
      case 'snare':
        this.triggerSnare(now, velocity);
        break;
      case 'hihat':
        this.triggerHiHat(now, velocity);
        break;
    }
  }

  /**
   * Instantly auditions a bass pulse when adjusting the Bass River.
   */
  public previewBass(intensity: number) {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(55, now); // A1 note
    osc.frequency.exponentialRampToValueAtTime(45, now + 0.35);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(150 + intensity * 600, now);
    filter.Q.setValueAtTime(4, now);

    gain.gain.setValueAtTime(0.3 * intensity, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.45);
  }

  /**
   * Instantly auditions energy core resonance.
   */
  public previewEnergy(energy: number) {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440 + energy * 440, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.5);

    gain.gain.setValueAtTime(0.15 * energy, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.52);
  }

  /**
   * Schedules synthesized edited notes for a short lookahead window during playback.
   */
  public scheduleEditedPlayback(
    currentTime: number,
    section: { id: string; start: number; end: number },
    editState: WorldEditState[string] | undefined,
    isEditedMode: boolean
  ) {
    if (!isEditedMode || !editState || !this.ctx || !this.masterGain) return;

    const secDuration = section.end - section.start;
    const currentSectionTime = currentTime - section.start;
    if (currentSectionTime < 0 || currentSectionTime > secDuration) return;

    const lookahead = 0.2; // 200ms lookahead
    const nextTime = currentSectionTime + lookahead;

    const steps = editState.rhythmSteps || [];
    const energyMult = editState.energyLevel !== undefined ? editState.energyLevel : 0.8;
    const bassMult = editState.bassIntensity !== undefined ? editState.bassIntensity : 0.5;

    steps.forEach((step) => {
      if (!step.active) return;
      const stepTime = step.timeRatio * secDuration;

      // Check if step falls within the upcoming lookahead interval
      if (stepTime >= currentSectionTime && stepTime < nextTime) {
        const scheduleAudioTime = this.ctx!.currentTime + (stepTime - currentSectionTime);
        const velocity = step.intensity * energyMult;

        if (step.type === 'kick') {
          this.triggerKick(scheduleAudioTime, velocity);
        } else if (step.type === 'snare') {
          this.triggerSnare(scheduleAudioTime, velocity);
        } else if (step.type === 'hihat') {
          this.triggerHiHat(scheduleAudioTime, velocity);
        }
      }
    });

    // Sub-bass layer on every quarter of the section if bass is boosted
    if (bassMult > 0.4) {
      const beatDur = Math.max(0.4, secDuration / 8);
      const stepInSec = currentSectionTime % beatDur;
      if (stepInSec < lookahead && Math.floor(currentSectionTime / beatDur) % 2 === 0) {
        const bassTime = this.ctx.currentTime + (beatDur - stepInSec);
        this.triggerBassNote(bassTime, 55, bassMult * energyMult);
      }
    }
  }

  private triggerKick(time: number, velocity: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(145, time);
    osc.frequency.exponentialRampToValueAtTime(38, time + 0.14);

    gain.gain.setValueAtTime(Math.min(1, velocity * 0.5), time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.3);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.32);
  }

  private triggerSnare(time: number, velocity: number) {
    if (!this.ctx || !this.masterGain) return;

    // Body tone
    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(190, time);
    osc.frequency.exponentialRampToValueAtTime(75, time + 0.09);
    oscGain.gain.setValueAtTime(velocity * 0.3, time);
    oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.1);
    osc.connect(oscGain);
    oscGain.connect(this.masterGain);
    osc.start(time);
    osc.stop(time + 0.11);

    // Noise crack
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.15);
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(1200, time);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(velocity * 0.35, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);

    noiseSource.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.masterGain);

    noiseSource.start(time);
    noiseSource.stop(time + 0.19);
  }

  private triggerHiHat(time: number, velocity: number) {
    if (!this.ctx || !this.masterGain) return;
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.045);
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(7500, time);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(velocity * 0.22, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.04);

    noiseSource.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    noiseSource.start(time);
    noiseSource.stop(time + 0.045);
  }

  private triggerBassNote(time: number, freq: number, velocity: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, time);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(240, time);
    filter.Q.setValueAtTime(2, time);

    gain.gain.setValueAtTime(velocity * 0.2, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.36);
  }

  public dispose() {
    this.scheduledEvents = [];
    if (this.ctx && this.ctx.state !== 'closed') {
      try {
        this.ctx.close();
      } catch {
        // Ignore close error
      }
    }
    this.ctx = null;
    this.masterGain = null;
    this.compressor = null;
  }
}

export const synthEngine = new SoundShapeSynthEngine();
