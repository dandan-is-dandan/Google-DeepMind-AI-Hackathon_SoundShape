import {
  AudioAnalysisResult,
  SceneObject,
  SceneSection,
  SceneVerificationReport,
  VerificationCheck,
  WorldScene,
} from '../types/world';

/**
 * Validates a generated 3D World Scene against acoustic truth and spatial architectural rules.
 */
export function verifyWorldScene(
  scene: WorldScene,
  audioFeatures?: AudioAnalysisResult | null
): {
  passed: boolean;
  report: SceneVerificationReport;
  diagnostics: string[];
} {
  const checks: VerificationCheck[] = [];
  const diagnostics: string[] = [];

  // Check 1: Duration Fidelity
  const measuredDuration = audioFeatures?.duration ?? scene.duration;
  const durationDiff = Math.abs(scene.duration - measuredDuration);
  const durationPass = durationDiff < 0.1;
  checks.push({
    id: 'duration_fidelity',
    name: 'Duration Fidelity',
    category: 'continuity',
    passed: durationPass,
    details: durationPass
      ? `Scene duration (${scene.duration.toFixed(2)}s) accurately matches measured audio duration.`
      : `Scene duration (${scene.duration.toFixed(2)}s) diverges by ${durationDiff.toFixed(2)}s from measured audio (${measuredDuration.toFixed(2)}s).`,
  });
  if (!durationPass) {
    diagnostics.push(`Duration divergence: scene=${scene.duration}s vs measured=${measuredDuration}s.`);
  }

  // Check 2: Timestamp Continuity & Section Non-Overlap
  let continuityPass = true;
  let continuityMessage = 'All section boundaries are strictly contiguous with zero gaps.';
  if (!scene.sections || scene.sections.length === 0) {
    continuityPass = false;
    continuityMessage = 'Scene contains no sections.';
    diagnostics.push(continuityMessage);
  } else {
    if (Math.abs(scene.sections[0].start) > 0.05) {
      continuityPass = false;
      diagnostics.push(`Section 1 starts at ${scene.sections[0].start}s instead of 0.0s.`);
    }
    for (let i = 0; i < scene.sections.length - 1; i++) {
      const cur = scene.sections[i];
      const next = scene.sections[i + 1];
      const gap = Math.abs(cur.end - next.start);
      if (gap > 0.05) {
        continuityPass = false;
        diagnostics.push(`Boundary discontinuity between "${cur.label}" (${cur.end}s) and "${next.label}" (${next.start}s) with gap of ${gap.toFixed(3)}s.`);
      }
    }
    const lastSec = scene.sections[scene.sections.length - 1];
    if (Math.abs(lastSec.end - scene.duration) > 0.05) {
      continuityPass = false;
      diagnostics.push(`Final section end (${lastSec.end}s) does not match total duration (${scene.duration}s).`);
    }
  }

  checks.push({
    id: 'section_continuity',
    name: 'Timestamp Continuity & Zero-Gap Island Layout',
    category: 'continuity',
    passed: continuityPass,
    details: continuityPass
      ? 'Contiguous chronological arrangement with zero temporal gaps or overlaps across all islands.'
      : `Discontinuities detected: ${diagnostics.filter(d => d.includes('gap') || d.includes('starts at') || d.includes('Final section')).join('; ')}`,
  });

  // Check 3: Tri-Layer Sculptures Completeness (Energy, Bass, Rhythm)
  let sculpturesPass = true;
  const missingSculptures: string[] = [];
  scene.sections.forEach((sec, idx) => {
    const hasRhythm = sec.objects.some((o) => o.type === 'rhythm_towers' && o.rhythmSteps && o.rhythmSteps.length >= 4);
    const hasBass = sec.objects.some((o) => o.type === 'bass_river');
    const hasCore = sec.objects.some((o) => o.type === 'energy_core');

    if (!hasRhythm || !hasBass || !hasCore) {
      sculpturesPass = false;
      const missing: string[] = [];
      if (!hasRhythm) missing.push('Rhythm Crystals');
      if (!hasBass) missing.push('Bass River');
      if (!hasCore) missing.push('Energy Orb');
      missingSculptures.push(`Section ${idx + 1} ("${sec.label}") missing ${missing.join(', ')}`);
    }
  });

  checks.push({
    id: 'trilayer_sculptures',
    name: 'Complete Tri-Layer Editable Sculptures',
    category: 'sculptures',
    passed: sculpturesPass,
    details: sculpturesPass
      ? 'Every section provides full 3D interactive controls: Rhythm Crystals, Bass Rivers, and Energy Orbs.'
      : `Missing sculptures in: ${missingSculptures.join('; ')}.`,
  });
  if (!sculpturesPass) {
    diagnostics.push(...missingSculptures);
  }

  // Check 4: Rhythm Grid Monotonic Integrity
  let rhythmPass = true;
  let rhythmAnomalyCount = 0;
  scene.sections.forEach((sec) => {
    const rhythmObj = sec.objects.find((o) => o.type === 'rhythm_towers');
    if (rhythmObj && rhythmObj.rhythmSteps) {
      let prevRatio = -0.001;
      for (const step of rhythmObj.rhythmSteps) {
        if (step.timeRatio < prevRatio || step.timeRatio > 1.0) {
          rhythmPass = false;
          rhythmAnomalyCount++;
        }
        prevRatio = step.timeRatio;
      }
    }
  });

  checks.push({
    id: 'rhythm_grid_integrity',
    name: 'Rhythm Grid & Transient Synchronization',
    category: 'rhythm',
    passed: rhythmPass,
    details: rhythmPass
      ? 'All rhythm crystal steps adhere to monotonic chronological progression synchronized with musical tempo.'
      : `${rhythmAnomalyCount} rhythm steps had non-monotonic or out-of-bound time ratios.`,
  });
  if (!rhythmPass) {
    diagnostics.push(`Detected ${rhythmAnomalyCount} rhythm steps with improper temporal ordering.`);
  }

  // Check 5: Procedural Landscape Diversity
  const landscapeTypes = new Set(scene.sections.map((s) => s.landscapeType));
  const hasDiversity = scene.sections.length <= 1 || landscapeTypes.size >= 2;
  checks.push({
    id: 'landscape_diversity',
    name: 'Procedural Landscape Archetype Differentiation',
    category: 'archetypes',
    passed: hasDiversity,
    details: hasDiversity
      ? `Distinct visual silhouettes assigned across islands: [${Array.from(landscapeTypes).join(', ')}].`
      : 'All sections share the exact same landscape archetype despite differing musical dynamics.',
  });
  if (!hasDiversity) {
    diagnostics.push('All sections share identical landscape archetype.');
  }

  // Check 6: DSP Parameter Safety & Value Ranges
  let dspPass = true;
  const dspIssues: string[] = [];
  scene.sections.forEach((sec, idx) => {
    if (sec.energy < 0 || sec.energy > 1) {
      dspPass = false;
      dspIssues.push(`Section ${idx + 1} energy (${sec.energy}) outside [0, 1]`);
    }
    const river = sec.objects.find((o) => o.type === 'bass_river');
    if (river && river.bassIntensity !== undefined && (river.bassIntensity < 0 || river.bassIntensity > 1)) {
      dspPass = false;
      dspIssues.push(`Section ${idx + 1} bass intensity (${river.bassIntensity}) outside [0, 1]`);
    }
  });

  checks.push({
    id: 'dsp_parameters',
    name: 'Acoustic DSP Limits & Parameter Safety',
    category: 'dsp',
    passed: dspPass,
    details: dspPass
      ? 'All gain levels, frequency filters, and physical dimensions fall strictly within safe audio DSP ranges.'
      : `DSP parameter limits exceeded: ${dspIssues.join('; ')}.`,
  });
  if (!dspPass) {
    diagnostics.push(...dspIssues);
  }

  const allPassed = checks.every((c) => c.passed);

  const report: SceneVerificationReport = {
    verifiedBy: 'gemini-4-argon',
    allPassed,
    timestamp: new Date().toISOString(),
    checks,
    repairsApplied: [],
    diagnostics: diagnostics.length > 0 ? diagnostics : undefined,
  };

  return { passed: allPassed, report, diagnostics };
}

/**
 * Deterministic repair engine that automatically repairs any structural or acoustic discrepancies
 * to guarantee that the 3D scene is 100% mathematically and acoustically pristine.
 */
export function repairWorldScene(
  scene: WorldScene,
  audioFeatures?: AudioAnalysisResult | null,
  modelName: string = 'gemini-4-argon'
): {
  repairedScene: WorldScene;
  repairsApplied: string[];
  report: SceneVerificationReport;
} {
  const repairs: string[] = [];
  const measuredDuration = audioFeatures?.duration ?? scene.duration;

  // 1. Repair Duration
  const sanitizeColor = (col: string | undefined, defaultCol = '#62D5E8'): string => {
    if (!col) return defaultCol;
    let clean = col.trim().replace(/^https?:\/\//i, '');
    if (!clean.startsWith('#')) clean = '#' + clean;
    return clean;
  };

  const repairedScene: WorldScene = {
    ...scene,
    duration: measuredDuration,
    globalPalette: (scene.globalPalette || ['#62D5E8', '#A58BFA', '#FFB66E', '#0B1020']).map((c) => sanitizeColor(c, '#62D5E8')),
    sections: JSON.parse(JSON.stringify(scene.sections)),
  };

  if (Math.abs(scene.duration - measuredDuration) > 0.05) {
    repairs.push(`Aligned scene duration to measured audio (${measuredDuration.toFixed(2)}s).`);
  }

  // 2. Repair Section Boundaries & Contiguity
  const totalSections = repairedScene.sections.length;
  if (totalSections > 0) {
    // Ensure section 0 starts at 0
    if (repairedScene.sections[0].start !== 0) {
      repairedScene.sections[0].start = 0;
      repairs.push('Aligned Section 1 start timestamp to 0.0s.');
    }

    for (let i = 0; i < totalSections - 1; i++) {
      const cur = repairedScene.sections[i];
      const next = repairedScene.sections[i + 1];

      // Enforce strict continuity: next.start = cur.end
      if (Math.abs(cur.end - next.start) > 0.001) {
        next.start = cur.end;
        repairs.push(`Seamlessly bridged island boundary between "${cur.label}" and "${next.label}".`);
      }
    }

    // Ensure last section ends exactly at duration
    const lastSec = repairedScene.sections[totalSections - 1];
    if (Math.abs(lastSec.end - measuredDuration) > 0.01) {
      lastSec.end = measuredDuration;
      repairs.push(`Synchronized final section end boundary to track duration (${measuredDuration.toFixed(2)}s).`);
    }
  }

  // 3. Repair Missing Sculptures & Ensure Complete Tri-Layer Controls
  repairedScene.sections.forEach((sec, idx) => {
    sec.dominantColor = sanitizeColor(sec.dominantColor, '#62D5E8');
    sec.accentColor = sanitizeColor(sec.accentColor, '#A58BFA');

    let hasRhythm = sec.objects.some((o) => o.type === 'rhythm_towers');
    let hasBass = sec.objects.some((o) => o.type === 'bass_river');
    let hasCore = sec.objects.some((o) => o.type === 'energy_core');

    const secEnergy = Math.max(0.1, Math.min(1.0, sec.energy ?? 0.5));

    if (!hasRhythm) {
      const stepCount = 8;
      const steps = Array.from({ length: stepCount }, (_, sIdx) => ({
        index: sIdx,
        timeRatio: sIdx / stepCount,
        intensity: sIdx % 2 === 0 ? 0.8 : 0.45,
        active: true,
        type: sIdx % 4 === 0 ? ('kick' as const) : sIdx % 2 === 0 ? ('snare' as const) : ('hihat' as const),
      }));

      sec.objects.push({
        id: `rhythm_${sec.id}`,
        type: 'rhythm_towers',
        editable: true,
        name: `${sec.label} Rhythm Crystals`,
        description: 'Interactive rhythm towers controlling beat amplitude and drum transient filtering.',
        rhythmSteps: steps,
      });
      repairs.push(`Synthesized complete rhythm crystal grid in Section ${idx + 1} ("${sec.label}").`);
    } else {
      // Normalize existing rhythm steps
      const rhythmObj = sec.objects.find((o) => o.type === 'rhythm_towers');
      if (rhythmObj && rhythmObj.rhythmSteps) {
        rhythmObj.rhythmSteps = rhythmObj.rhythmSteps
          .map((step, sIdx) => ({
            ...step,
            index: sIdx,
            timeRatio: Math.max(0, Math.min(1, step.timeRatio ?? sIdx / rhythmObj.rhythmSteps!.length)),
            intensity: Math.max(0, Math.min(1, step.intensity ?? 0.6)),
            active: step.active !== false,
            type: ['kick', 'snare', 'hihat'].includes(step.type) ? step.type : 'hihat',
          }))
          .sort((a, b) => a.timeRatio - b.timeRatio);
      }
    }

    if (!hasBass) {
      sec.objects.push({
        id: `bass_${sec.id}`,
        type: 'bass_river',
        editable: true,
        name: `${sec.label} Sub-Bass River`,
        description: 'Winding resonant bass canal controlling low-frequency EQ (+/-12dB at 120Hz).',
        bassIntensity: 0.55,
      });
      repairs.push(`Added interactive Sub-Bass River to Section ${idx + 1} ("${sec.label}").`);
    }

    if (!hasCore) {
      sec.objects.push({
        id: `core_${sec.id}`,
        type: 'energy_core',
        editable: true,
        name: `${sec.label} Energy Core`,
        description: 'Luminous dynamic orb controlling section loudness and output gain (-18dB to +6dB).',
        energyLevel: secEnergy,
      });
      repairs.push(`Added dynamic Energy Core orb to Section ${idx + 1} ("${sec.label}").`);
    }

    // 4. Archetype Alignment to Acoustic Energy
    if (secEnergy < 0.35 && sec.landscapeType !== 'glass_island') {
      sec.landscapeType = 'glass_island';
      repairs.push(`Assigned calm Glass Sanctuary archetype to Section ${idx + 1} ("${sec.label}") for acoustic coherence.`);
    } else if (secEnergy > 0.65 && !['crystal_peak', 'rising_crystals'].includes(sec.landscapeType)) {
      sec.landscapeType = 'crystal_peak';
      repairs.push(`Assigned dramatic Fractured Peak archetype to Section ${idx + 1} ("${sec.label}") to match peak energy.`);
    } else if (secEnergy >= 0.35 && secEnergy <= 0.65 && !['cyber_grid', 'floating_plateau'].includes(sec.landscapeType)) {
      sec.landscapeType = 'cyber_grid';
      repairs.push(`Assigned Rhythm City architecture archetype to Section ${idx + 1} ("${sec.label}").`);
    }
  });

  // Ensure landscape diversity is genuinely achieved across multiple islands
  const distinctArchetypes = new Set(repairedScene.sections.map((s) => s.landscapeType));
  if (repairedScene.sections.length > 1 && distinctArchetypes.size < 2) {
    const archetypes: Array<'glass_island' | 'cyber_grid' | 'crystal_peak' | 'floating_plateau'> = [
      'glass_island',
      'cyber_grid',
      'crystal_peak',
      'floating_plateau',
    ];
    repairedScene.sections.forEach((sec, idx) => {
      sec.landscapeType = archetypes[idx % archetypes.length];
    });
    repairs.push(`Differentiated identical landscape archetypes across ${repairedScene.sections.length} islands.`);
  }

  // Re-verify the repaired scene deterministically
  const { report } = verifyWorldScene(repairedScene, audioFeatures);
  report.verifiedBy = modelName;
  report.repairsApplied = repairs;
  report.localCorrectionsApplied = repairs;

  // Mark repaired checks as repaired ONLY if the check actually passed
  report.checks.forEach((c) => {
    if (c.passed) {
      if (c.id === 'duration_fidelity' && repairs.some((r) => r.includes('duration'))) {
        c.repaired = true;
      }
      if (c.id === 'section_continuity' && repairs.some((r) => r.includes('boundary') || r.includes('Aligned'))) {
        c.repaired = true;
      }
      if (c.id === 'trilayer_sculptures' && repairs.some((r) => r.includes('Synthesized') || r.includes('Added'))) {
        c.repaired = true;
      }
      if (c.id === 'landscape_diversity' && repairs.some((r) => r.includes('archetype'))) {
        c.repaired = true;
      }
    }
  });

  // Strictly compute overall allPassed from individual check pass states
  report.allPassed = report.checks.every((c) => c.passed);
  repairedScene.verificationReport = report;

  return { repairedScene, repairsApplied: repairs, report };
}
