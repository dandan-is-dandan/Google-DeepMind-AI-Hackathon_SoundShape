import { AudioAnalysisResult, RhythmStep, SceneObject, SceneSection, WorldScene } from '../types/world';

export function formatTimestamp(seconds: number): string {
  const totalTenths = Math.round(seconds * 10);
  const totalSeconds = Math.floor(totalTenths / 10);
  const tenths = totalTenths % 10;
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}.${tenths}`;
}

/**
 * Enriches all RhythmSteps and musical sculptures with deterministic audio-time mapping metadata.
 * Couples each sculpture directly to real audio timeline timestamps and measured FFT features.
 */
export function enrichSceneWithMusicalMetadata(
  scene: WorldScene,
  analysis?: AudioAnalysisResult | null
): WorldScene {
  const enrichedSections: SceneSection[] = scene.sections.map((section) => {
    const secDuration = Math.max(0.1, section.end - section.start);

    const enrichedObjects: SceneObject[] = section.objects.map((obj) => {
      if (obj.type === 'rhythm_towers' && obj.rhythmSteps) {
        const enrichedSteps: RhythmStep[] = obj.rhythmSteps.map((step) => {
          const eventTime = Math.round((section.start + step.timeRatio * secDuration) * 100) / 100;
          const timeFormatted = formatTimestamp(eventTime);

          // Find closest audio feature window if analysis is available
          let featureVal = Math.round(step.intensity * 100) / 100;
          let featureName = 'Rhythmic Grid & Transient Onset';

          if (analysis && analysis.windows.length > 0) {
            const closestWindow = analysis.windows.reduce((prev, curr) =>
              Math.abs(curr.time - eventTime) < Math.abs(prev.time - eventTime) ? curr : prev
            );

            if (step.type === 'kick') {
              featureVal = Math.round(closestWindow.low * 100) / 100;
              featureName = 'Low-Frequency Energy (20-250Hz) & Sub-Bass Peak';
            } else if (step.type === 'snare') {
              featureVal = Math.round(closestWindow.mid * 100) / 100;
              featureName = 'Mid-Frequency Spectral Flux (250-2500Hz) & Snare Transient';
            } else {
              featureVal = Math.round(closestWindow.high * 100) / 100;
              featureName = 'High-Frequency Treble (2500-12000Hz) & Cymbal Sizzle';
            }
          }

          const instrumentLabel =
            step.type === 'kick'
              ? 'Synthesized Kick Drum (Analysis-Informed)'
              : step.type === 'snare'
              ? 'Synthesized Snare Drum (Analysis-Informed)'
              : 'Synthesized Hi-Hat (Analysis-Informed)';

          return {
            ...step,
            objectId: `tower_${section.id}_step${step.index}`,
            sectionId: section.id,
            eventTimeSeconds: eventTime,
            timeRange: timeFormatted,
            instrumentType: instrumentLabel,
            sourceFeatureType: featureName,
            sourceFeatureValue: featureVal,
            originalParameter: step.originalParameter ?? step.intensity,
            editedParameter: step.intensity,
            isActive: step.active,
          };
        });

        return {
          ...obj,
          rhythmSteps: enrichedSteps,
        };
      }

      if (obj.type === 'bass_river') {
        const timeRangeFormatted = `${formatTimestamp(section.start)} - ${formatTimestamp(section.end)}`;
        return {
          ...obj,
          description: `Winding resonance river corresponding to [${timeRangeFormatted}]. Associated with Low-Frequency Sub-Bass (20-250Hz).`,
        };
      }

      if (obj.type === 'energy_core') {
        const timeRangeFormatted = `${formatTimestamp(section.start)} - ${formatTimestamp(section.end)}`;
        return {
          ...obj,
          description: `Orbital energy core corresponding to [${timeRangeFormatted}]. Associated with Section RMS Energy (${Math.round(section.energy * 100)}%).`,
        };
      }

      return obj;
    });

    return {
      ...section,
      objects: enrichedObjects,
    };
  });

  return {
    ...scene,
    sections: enrichedSections,
  };
}
