/**
 * Procedurally generates a pristine 24-second multi-section music piece
 * called "Cosmic Aurora" directly using Web Audio OfflineAudioContext.
 * Guaranteed zero 404 dependencies and perfectly segmented for 3D world testing.
 */
export async function generateSampleAudioBuffer(): Promise<{
  audioBuffer: AudioBuffer;
  wavBlob: Blob;
  filename: string;
}> {
  const sampleRate = 44100;
  const duration = 24.0;
  const totalSamples = Math.floor(sampleRate * duration);
  const offlineCtx = new OfflineAudioContext(2, totalSamples, sampleRate);

  // Master bus
  const masterGain = offlineCtx.createGain();
  masterGain.gain.setValueAtTime(0.85, 0);

  const compressor = offlineCtx.createDynamicsCompressor();
  compressor.threshold.setValueAtTime(-12, 0);
  compressor.knee.setValueAtTime(10, 0);
  compressor.ratio.setValueAtTime(4, 0);
  compressor.attack.setValueAtTime(0.005, 0);
  compressor.release.setValueAtTime(0.1, 0);

  masterGain.connect(compressor);
  compressor.connect(offlineCtx.destination);

  const bpm = 124;
  const beatSec = 60 / bpm; // ~0.484s

  // SECTION 1: 0.0s - 8.0s (Opening Ambient Pad & Soft Pulse)
  // Warm minor chord progression: Am -> F -> C -> G
  const padFrequencies = [
    [220.0, 261.63, 329.63], // Am
    [174.61, 220.0, 261.63], // F
    [261.63, 329.63, 392.0], // C
    [196.0, 246.94, 293.66], // G
  ];

  padFrequencies.forEach((chord, chordIdx) => {
    const chordStart = chordIdx * 2.0;
    const chordEnd = chordStart + 2.1;
    chord.forEach((freq) => {
      const osc = offlineCtx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, chordStart);

      const filter = offlineCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(400, chordStart);
      filter.frequency.exponentialRampToValueAtTime(800 + chordIdx * 150, chordStart + 1.2);
      filter.frequency.exponentialRampToValueAtTime(350, chordEnd);

      const gain = offlineCtx.createGain();
      gain.gain.setValueAtTime(0, chordStart);
      gain.gain.linearRampToValueAtTime(0.07, chordStart + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, chordEnd);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(masterGain);

      osc.start(chordStart);
      osc.stop(chordEnd);
    });
  });

  // Soft rhythmic ambient pulse in Section 1
  for (let t = 0.5; t < 7.8; t += beatSec) {
    const pulseOsc = offlineCtx.createOscillator();
    pulseOsc.type = 'sine';
    pulseOsc.frequency.setValueAtTime(110, t);
    pulseOsc.frequency.exponentialRampToValueAtTime(55, t + 0.25);

    const pulseGain = offlineCtx.createGain();
    pulseGain.gain.setValueAtTime(0.12, t);
    pulseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    pulseOsc.connect(pulseGain);
    pulseGain.connect(masterGain);
    pulseOsc.start(t);
    pulseOsc.stop(t + 0.26);
  }

  // SECTION 2: 8.0s - 16.0s (Build-up with Arpeggiated Bass and Crisp Percussion)
  // Driving synth bassline
  const bassNotes = [110, 110, 130.81, 146.83, 110, 164.81, 146.83, 130.81];
  let bassNoteIdx = 0;
  for (let t = 8.0; t < 15.9; t += beatSec / 2) {
    const freq = bassNotes[bassNoteIdx % bassNotes.length];
    bassNoteIdx++;

    const bassOsc = offlineCtx.createOscillator();
    bassOsc.type = 'triangle';
    bassOsc.frequency.setValueAtTime(freq / 2, t);

    const bassFilter = offlineCtx.createBiquadFilter();
    bassFilter.type = 'lowpass';
    bassFilter.frequency.setValueAtTime(600, t);
    bassFilter.frequency.exponentialRampToValueAtTime(180, t + 0.2);

    const bGain = offlineCtx.createGain();
    bGain.gain.setValueAtTime(0.18, t);
    bGain.gain.exponentialRampToValueAtTime(0.001, t + beatSec / 2);

    bassOsc.connect(bassFilter);
    bassFilter.connect(bGain);
    bGain.connect(masterGain);

    bassOsc.start(t);
    bassOsc.stop(t + beatSec / 2);
  }

  // Hi-hats in Section 2 (16th notes)
  for (let t = 8.0; t < 15.9; t += beatSec / 4) {
    scheduleHiHat(offlineCtx, masterGain, t, 0.04);
  }

  // Snare on beats 2 & 4 in Section 2
  for (let bar = 0; bar < 4; bar++) {
    const barStart = 8.0 + bar * (beatSec * 4);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec, 0.15);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec * 3, 0.15);
  }

  // SECTION 3: 16.0s - 24.0s (Climax / Full Dynamic Drop)
  // Four-on-the-floor Kick Drum
  for (let t = 16.0; t < 23.8; t += beatSec) {
    scheduleKick(offlineCtx, masterGain, t, 0.35);
  }

  // Climax Snares on beats 2 & 4
  for (let bar = 0; bar < 4; bar++) {
    const barStart = 16.0 + bar * (beatSec * 4);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec, 0.22);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec * 3, 0.22);
  }

  // Shimmering Hi-Hats with accents
  let hhIdx = 0;
  for (let t = 16.0; t < 23.8; t += beatSec / 4) {
    const vol = hhIdx % 2 === 1 ? 0.08 : 0.04;
    scheduleHiHat(offlineCtx, masterGain, t, vol);
    hhIdx++;
  }

  // Soaring Lead Arpeggio & Rich Bass Chords in Section 3
  const leadMelody = [440, 523.25, 659.25, 783.99, 880, 783.99, 659.25, 523.25];
  let leadIdx = 0;
  for (let t = 16.0; t < 23.8; t += beatSec / 2) {
    const freq = leadMelody[leadIdx % leadMelody.length];
    leadIdx++;

    const leadOsc = offlineCtx.createOscillator();
    leadOsc.type = 'sawtooth';
    leadOsc.frequency.setValueAtTime(freq, t);

    const leadFilter = offlineCtx.createBiquadFilter();
    leadFilter.type = 'bandpass';
    leadFilter.frequency.setValueAtTime(1400, t);
    leadFilter.Q.setValueAtTime(3, t);

    const leadGain = offlineCtx.createGain();
    leadGain.gain.setValueAtTime(0.08, t);
    leadGain.gain.exponentialRampToValueAtTime(0.001, t + beatSec / 2);

    leadOsc.connect(leadFilter);
    leadFilter.connect(leadGain);
    leadGain.connect(masterGain);

    leadOsc.start(t);
    leadOsc.stop(t + beatSec / 2);
  }

  // Render the audio graph to buffer
  const renderedBuffer = await offlineCtx.startRendering();
  const wavBlob = audioBufferToWavBlob(renderedBuffer);

  return {
    audioBuffer: renderedBuffer,
    wavBlob,
    filename: 'Cosmic_Aurora_Dreamy.wav',
  };
}

/**
 * Procedurally generates a contrasting high-intensity Cyber Electro track
 * called "Cyber Pulse Apex" with aggressive 808 sub-bass, rapid 148 BPM syncopation,
 * and sharp digital stabs.
 */
export async function generateCyberPulseSampleBuffer(): Promise<{
  audioBuffer: AudioBuffer;
  wavBlob: Blob;
  filename: string;
}> {
  const sampleRate = 44100;
  const duration = 24.0;
  const totalSamples = Math.floor(sampleRate * duration);
  const offlineCtx = new OfflineAudioContext(2, totalSamples, sampleRate);

  const masterGain = offlineCtx.createGain();
  masterGain.gain.setValueAtTime(0.9, 0);

  const compressor = offlineCtx.createDynamicsCompressor();
  compressor.threshold.setValueAtTime(-8, 0);
  compressor.ratio.setValueAtTime(8, 0);
  compressor.attack.setValueAtTime(0.002, 0);
  compressor.release.setValueAtTime(0.05, 0);

  masterGain.connect(compressor);
  compressor.connect(offlineCtx.destination);

  const bpm = 148;
  const beatSec = 60 / bpm; // ~0.405s

  // SECTION 1: 0.0s - 7.0s (Menacing Cyber Sub Build-Up)
  // Low resonant drone (F# 46.25Hz)
  const subOsc = offlineCtx.createOscillator();
  subOsc.type = 'sawtooth';
  subOsc.frequency.setValueAtTime(46.25, 0);
  const subFilter = offlineCtx.createBiquadFilter();
  subFilter.type = 'lowpass';
  subFilter.frequency.setValueAtTime(90, 0);
  subFilter.frequency.linearRampToValueAtTime(280, 7.0);
  const subGain = offlineCtx.createGain();
  subGain.gain.setValueAtTime(0.3, 0);
  subGain.gain.linearRampToValueAtTime(0.45, 7.0);
  subOsc.connect(subFilter);
  subFilter.connect(subGain);
  subGain.connect(masterGain);
  subOsc.start(0);
  subOsc.stop(7.0);

  // Rapid metallic hi-hat ticks in Section 1 (8th notes and 16ths)
  for (let t = 0; t < 6.9; t += beatSec / 2) {
    scheduleHiHat(offlineCtx, masterGain, t, 0.07);
    if (t > 3.5) {
      scheduleHiHat(offlineCtx, masterGain, t + beatSec / 4, 0.04);
    }
  }

  // Heavy cyber kick on beats 1 & 3
  for (let t = 0; t < 6.9; t += beatSec * 2) {
    scheduleHeavyKick(offlineCtx, masterGain, t, 0.45);
  }

  // SECTION 2: 7.0s - 15.0s (Aggressive Industrial Cyber Groove)
  // Rapid 16th-note sub-bass bounce
  const notes = [46.25, 46.25, 55.0, 61.74, 46.25, 69.3, 61.74, 55.0];
  let nIdx = 0;
  for (let t = 7.0; t < 14.9; t += beatSec / 2) {
    const freq = notes[nIdx % notes.length];
    nIdx++;
    const bOsc = offlineCtx.createOscillator();
    bOsc.type = 'sawtooth';
    bOsc.frequency.setValueAtTime(freq, t);
    const bFilt = offlineCtx.createBiquadFilter();
    bFilt.type = 'bandpass';
    bFilt.frequency.setValueAtTime(320, t);
    bFilt.Q.setValueAtTime(4, t);
    const bG = offlineCtx.createGain();
    bG.gain.setValueAtTime(0.35, t);
    bG.gain.exponentialRampToValueAtTime(0.001, t + beatSec / 2);
    bOsc.connect(bFilt);
    bFilt.connect(bG);
    bG.connect(masterGain);
    bOsc.start(t);
    bOsc.stop(t + beatSec / 2);
  }

  // Driving four-on-the-floor kicks in Section 2
  for (let t = 7.0; t < 14.9; t += beatSec) {
    scheduleHeavyKick(offlineCtx, masterGain, t, 0.5);
  }
  // Sharp industrial snare on beats 2 & 4
  for (let bar = 0; bar < 5; bar++) {
    const barStart = 7.0 + bar * (beatSec * 4);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec, 0.28);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec * 3, 0.28);
  }

  // SECTION 3: 15.0s - 24.0s (Apex Distortion Drop & Neon Stabs)
  for (let t = 15.0; t < 23.8; t += beatSec) {
    scheduleHeavyKick(offlineCtx, masterGain, t, 0.6);
  }
  for (let bar = 0; bar < 6; bar++) {
    const barStart = 15.0 + bar * (beatSec * 4);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec, 0.35);
    scheduleSnare(offlineCtx, masterGain, barStart + beatSec * 3, 0.35);
  }

  // Neon saw synth stabs
  const stabFreqs = [370.0, 440.0, 554.37, 440.0, 659.25, 554.37];
  let stabIdx = 0;
  for (let t = 15.0; t < 23.8; t += beatSec / 2) {
    if (stabIdx % 3 !== 2) {
      const f = stabFreqs[stabIdx % stabFreqs.length];
      const sOsc = offlineCtx.createOscillator();
      sOsc.type = 'sawtooth';
      sOsc.frequency.setValueAtTime(f, t);
      const sFilt = offlineCtx.createBiquadFilter();
      sFilt.type = 'lowpass';
      sFilt.frequency.setValueAtTime(1800, t);
      sFilt.frequency.exponentialRampToValueAtTime(300, t + beatSec / 2);
      const sGain = offlineCtx.createGain();
      sGain.gain.setValueAtTime(0.2, t);
      sGain.gain.exponentialRampToValueAtTime(0.001, t + beatSec / 2);
      sOsc.connect(sFilt);
      sFilt.connect(sGain);
      sGain.connect(masterGain);
      sOsc.start(t);
      sOsc.stop(t + beatSec / 2);
    }
    stabIdx++;
  }

  const renderedBuffer = await offlineCtx.startRendering();
  const wavBlob = audioBufferToWavBlob(renderedBuffer);

  return {
    audioBuffer: renderedBuffer,
    wavBlob,
    filename: 'Cyber_Pulse_Apex.wav',
  };
}

function scheduleHeavyKick(
  ctx: BaseAudioContext,
  dest: AudioNode,
  time: number,
  volume: number
) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(180, time);
  osc.frequency.exponentialRampToValueAtTime(35, time + 0.16);

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(350, time);
  filter.frequency.exponentialRampToValueAtTime(70, time + 0.16);

  gain.gain.setValueAtTime(volume, time);
  gain.gain.exponentialRampToValueAtTime(0.001, time + 0.32);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(dest);

  osc.start(time);
  osc.stop(time + 0.33);
}

// Procedural drum synthesizer helpers
function scheduleKick(
  ctx: BaseAudioContext,
  dest: AudioNode,
  time: number,
  volume: number
) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(150, time);
  osc.frequency.exponentialRampToValueAtTime(42, time + 0.15);

  gain.gain.setValueAtTime(volume, time);
  gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);

  osc.connect(gain);
  gain.connect(dest);

  osc.start(time);
  osc.stop(time + 0.36);
}

function scheduleSnare(
  ctx: BaseAudioContext,
  dest: AudioNode,
  time: number,
  volume: number
) {
  // Snare tone
  const toneOsc = ctx.createOscillator();
  const toneGain = ctx.createGain();
  toneOsc.type = 'triangle';
  toneOsc.frequency.setValueAtTime(180, time);
  toneOsc.frequency.exponentialRampToValueAtTime(80, time + 0.1);
  toneGain.gain.setValueAtTime(volume * 0.7, time);
  toneGain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);
  toneOsc.connect(toneGain);
  toneGain.connect(dest);
  toneOsc.start(time);
  toneOsc.stop(time + 0.13);

  // Snare noise
  const bufferSize = Math.floor(ctx.sampleRate * 0.2);
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const output = noiseBuffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    output[i] = Math.random() * 2 - 1;
  }

  const whiteNoise = ctx.createBufferSource();
  whiteNoise.buffer = noiseBuffer;

  const noiseFilter = ctx.createBiquadFilter();
  noiseFilter.type = 'highpass';
  noiseFilter.frequency.setValueAtTime(1000, time);

  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(volume, time);
  noiseGain.gain.exponentialRampToValueAtTime(0.001, time + 0.2);

  whiteNoise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(dest);

  whiteNoise.start(time);
  whiteNoise.stop(time + 0.21);
}

function scheduleHiHat(
  ctx: BaseAudioContext,
  dest: AudioNode,
  time: number,
  volume: number
) {
  const bufferSize = Math.floor(ctx.sampleRate * 0.05);
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const output = noiseBuffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    output[i] = Math.random() * 2 - 1;
  }

  const noise = ctx.createBufferSource();
  noise.buffer = noiseBuffer;

  const filter = ctx.createBiquadFilter();
  filter.type = 'highpass';
  filter.frequency.setValueAtTime(7000, time);

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(volume, time);
  gain.gain.exponentialRampToValueAtTime(0.001, time + 0.045);

  noise.connect(filter);
  filter.connect(gain);
  gain.connect(dest);

  noise.start(time);
  noise.stop(time + 0.05);
}

/**
 * Encodes an AudioBuffer into standard 16-bit PCM WAV Blob
 */
function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  let pos = 0;

  function writeString(str: string) {
    for (let i = 0; i < str.length; i++) {
      out.setUint8(pos++, str.charCodeAt(i));
    }
  }

  // RIFF identifier
  writeString('RIFF');
  out.setUint32(pos, length - 8, true);
  pos += 4;
  writeString('WAVE');
  // format chunk identifier
  writeString('fmt ');
  out.setUint32(pos, 16, true);
  pos += 4; // format chunk length
  out.setUint16(pos, 1, true);
  pos += 2; // sample format (raw)
  out.setUint16(pos, numOfChan, true);
  pos += 2; // channel count
  out.setUint32(pos, buffer.sampleRate, true);
  pos += 4; // sample rate
  out.setUint32(pos, buffer.sampleRate * 2 * numOfChan, true);
  pos += 4; // byte rate (sample rate * block align)
  out.setUint16(pos, numOfChan * 2, true);
  pos += 2; // block align (channel count * bytes per sample)
  out.setUint16(pos, 16, true);
  pos += 2; // bits per sample
  // data chunk identifier
  writeString('data');
  out.setUint32(pos, length - pos - 4, true);
  pos += 4;

  // Interleave channels
  const channels: Float32Array[] = [];
  for (let i = 0; i < numOfChan; i++) {
    channels.push(buffer.getChannelData(i));
  }

  for (let i = 0; i < buffer.length; i++) {
    for (let ch = 0; ch < numOfChan; ch++) {
      let sample = Math.max(-1, Math.min(1, channels[ch][i]));
      sample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      out.setInt16(pos, sample, true);
      pos += 2;
    }
  }

  return new Blob([out.buffer], { type: 'audio/wav' });
}
