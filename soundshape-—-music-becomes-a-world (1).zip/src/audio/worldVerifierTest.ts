import { WorldScene, AudioAnalysisResult } from '../types/world';
import { verifyWorldScene, repairWorldScene } from './worldVerifier';

export interface WorldVerifierTestCaseResult {
  id: string;
  name: string;
  description: string;
  passed: boolean;
  expectedResult: 'pass' | 'fail' | 'repaired';
  details: string;
  diagnostics?: string[];
}

export interface WorldVerifierTestSuiteReport {
  timestamp: string;
  allPassed: boolean;
  testsPassed: number;
  testsTotal: number;
  results: WorldVerifierTestCaseResult[];
  verdict: string;
}

/**
 * Creates a baseline valid WorldScene for testing.
 */
export function createMockValidScene(duration = 30.0): WorldScene {
  return {
    duration,
    worldTheme: 'crystal_canyon',
    spatialArrangement: 'linear_archipelago',
    overallMood: 'Atmospheric and progressive',
    globalPalette: ['#62D5E8', '#A58BFA', '#FFB66E', '#0B1020'],
    terrainRoughness: 0.65,
    lightingAtmosphere: 'Luminescent cavern bioluminescence',
    creativeRationale: 'Progression from introspective ambient passage to driving rhythmic apex.',
    sections: [
      {
        id: 'sec_1',
        label: 'Section 1 — Ambient Intro',
        start: 0.0,
        end: 15.0,
        energy: 0.3,
        mood: 'Calm and reflective',
        dominantColor: '#62D5E8',
        accentColor: '#A58BFA',
        landscapeType: 'glass_island',
        objects: [
          {
            id: 'rhythm_sec_1',
            type: 'rhythm_towers',
            editable: true,
            name: 'Intro Rhythm Crystals',
            description: 'Transient crystal spires',
            rhythmSteps: Array.from({ length: 8 }, (_, i) => ({
              index: i,
              timeRatio: i / 8,
              intensity: 0.5,
              active: true,
              type: i % 2 === 0 ? ('kick' as const) : ('hihat' as const),
            })),
          },
          {
            id: 'bass_sec_1',
            type: 'bass_river',
            editable: true,
            name: 'Intro Bass River',
            description: 'Sub-bass canal',
            bassIntensity: 0.4,
          },
          {
            id: 'core_sec_1',
            type: 'energy_core',
            editable: true,
            name: 'Intro Energy Core',
            description: 'Section energy sphere',
            energyLevel: 0.3,
          },
        ],
      },
      {
        id: 'sec_2',
        label: 'Section 2 — Dynamic Climax',
        start: 15.0,
        end: duration,
        energy: 0.8,
        mood: 'Intense and expansive',
        dominantColor: '#A58BFA',
        accentColor: '#FFB66E',
        landscapeType: 'crystal_peak',
        objects: [
          {
            id: 'rhythm_sec_2',
            type: 'rhythm_towers',
            editable: true,
            name: 'Climax Rhythm Crystals',
            description: 'Towering rhythm crystals',
            rhythmSteps: Array.from({ length: 8 }, (_, i) => ({
              index: i,
              timeRatio: i / 8,
              intensity: 0.85,
              active: true,
              type: i % 2 === 0 ? ('kick' as const) : ('snare' as const),
            })),
          },
          {
            id: 'bass_sec_2',
            type: 'bass_river',
            editable: true,
            name: 'Climax Bass River',
            description: 'Surging bass torrent',
            bassIntensity: 0.8,
          },
          {
            id: 'core_sec_2',
            type: 'energy_core',
            editable: true,
            name: 'Climax Energy Core',
            description: 'High-energy radiant core',
            energyLevel: 0.8,
          },
        ],
      },
    ],
  };
}

/**
 * Runs the deterministic Gemini 4 Argon World Generation Verification Test Suite (Requirement B6).
 */
export function runWorldVerifierTestSuite(): WorldVerifierTestSuiteReport {
  const results: WorldVerifierTestCaseResult[] = [];
  const standardAudioFeatures: AudioAnalysisResult = {
    duration: 30.0,
    sampleRate: 44100,
    tempoEstimate: 120,
    averageRms: 0.25,
    peakRms: 0.82,
    windows: [],
    detectedSections: [
      { start: 0, end: 15, label: 'Section 1', energy: 0.3, lowRatio: 0.4, midRatio: 0.4 },
      { start: 15, end: 30, label: 'Section 2', energy: 0.8, lowRatio: 0.8, midRatio: 0.6 },
    ],
  };

  // Test 1: Valid scene passes verification
  {
    const scene = createMockValidScene(30.0);
    const verification = verifyWorldScene(scene, standardAudioFeatures);
    results.push({
      id: 'test_1_valid_scene',
      name: 'Valid Scene Verification',
      description: 'A well-formed scene with valid duration, contiguous sections, and complete tri-layer sculptures must pass all checks.',
      passed: verification.passed && verification.report.allPassed,
      expectedResult: 'pass',
      details: verification.passed
        ? `Passed all ${verification.report.checks.length} architectural validation checks.`
        : `Unexpected failure: ${verification.diagnostics.join(', ')}`,
      diagnostics: verification.diagnostics,
    });
  }

  // Test 2: Scene with duration mismatch fails
  {
    const scene = createMockValidScene(25.0); // Diverges from 30.0s audio
    const verification = verifyWorldScene(scene, standardAudioFeatures);
    const durationFailed = verification.report.checks.some((c) => c.id === 'duration_fidelity' && !c.passed);
    const passed = !verification.passed && durationFailed;
    results.push({
      id: 'test_2_duration_mismatch',
      name: 'Duration Mismatch Detection',
      description: 'A scene whose duration diverges from measured audio duration must fail the duration fidelity check.',
      passed,
      expectedResult: 'fail',
      details: passed
        ? `Correctly identified duration discrepancy (scene=25.0s vs audio=30.0s).`
        : `Failed to detect duration mismatch.`,
      diagnostics: verification.diagnostics,
    });
  }

  // Test 3: Scene with overlapping sections fails
  {
    const scene = createMockValidScene(30.0);
    // Introduce an illegal overlap: Section 1 ends at 18.0s, Section 2 starts at 15.0s
    scene.sections[0].end = 18.0;
    scene.sections[1].start = 15.0;
    const verification = verifyWorldScene(scene, standardAudioFeatures);
    const continuityFailed = verification.report.checks.some((c) => c.id === 'section_continuity' && !c.passed);
    const passed = !verification.passed && continuityFailed;
    results.push({
      id: 'test_3_overlapping_sections',
      name: 'Overlapping Island Boundary Detection',
      description: 'A scene with temporal section overlaps or boundary gaps must fail continuity verification.',
      passed,
      expectedResult: 'fail',
      details: passed
        ? `Successfully caught boundary overlap/discontinuity between Section 1 and Section 2.`
        : `Failed to flag section boundary overlap.`,
      diagnostics: verification.diagnostics,
    });
  }

  // Test 4: Scene with missing sculptures fails
  {
    const scene = createMockValidScene(30.0);
    // Remove bass_river and energy_core from section 1
    scene.sections[0].objects = scene.sections[0].objects.filter((o) => o.type === 'rhythm_towers');
    const verification = verifyWorldScene(scene, standardAudioFeatures);
    const sculpturesFailed = verification.report.checks.some((c) => c.id === 'trilayer_sculptures' && !c.passed);
    const passed = !verification.passed && sculpturesFailed;
    results.push({
      id: 'test_4_missing_sculptures',
      name: 'Missing Tri-Layer Sculptures Detection',
      description: 'A section lacking any of the tri-layer controls (Rhythm Crystals, Bass River, Energy Core) must fail.',
      passed,
      expectedResult: 'fail',
      details: passed
        ? `Successfully detected missing Bass River and Energy Core in Section 1.`
        : `Failed to catch missing sculptural layers.`,
      diagnostics: verification.diagnostics,
    });
  }

  // Test 5: Repair logic fixes known errors
  {
    const brokenScene = createMockValidScene(26.0); // Wrong duration
    brokenScene.sections[0].end = 18.0;
    brokenScene.sections[1].start = 14.0; // Overlap
    brokenScene.sections[0].objects = []; // Missing sculptures completely

    const { repairedScene, repairsApplied, report } = repairWorldScene(brokenScene, standardAudioFeatures);
    const reVerification = verifyWorldScene(repairedScene, standardAudioFeatures);
    const hasRepairs = repairsApplied.length >= 3;
    const passed = report.allPassed && reVerification.passed && hasRepairs;

    results.push({
      id: 'test_5_repair_logic',
      name: 'Automated Repair Loop Integrity',
      description: 'Automated repair must fix duration divergence, bridge broken island boundaries, synthesize missing sculptures, and produce a 100% passing scene.',
      passed,
      expectedResult: 'repaired',
      details: passed
        ? `Applied ${repairsApplied.length} automated repairs; repaired scene passes all verification checks.`
        : `Repair failed to produce valid scene or missing repairs.`,
      diagnostics: repairsApplied,
    });
  }

  // Test 6: Fallback triggers when repair fails or invalid input given
  {
    // Test that when given an empty or totally corrupt scene structure, fallback mechanism safely engages
    const corruptScene: WorldScene = {
      duration: 0,
      worldTheme: 'crystal_canyon',
      spatialArrangement: 'linear_archipelago',
      overallMood: 'corrupt',
      globalPalette: [],
      terrainRoughness: 0,
      lightingAtmosphere: '',
      creativeRationale: 'corrupt fallback test',
      sections: [],
    };

    const { repairedScene } = repairWorldScene(corruptScene, standardAudioFeatures);
    // If sections were empty, repair gracefully handles or fallback is required
    const isProtected = repairedScene.duration === standardAudioFeatures.duration;

    results.push({
      id: 'test_6_fallback_triggers',
      name: 'Graceful Fallback & Resilience',
      description: 'When input data is fundamentally corrupt, the pipeline must guard against crashes and enforce safe audio bounds.',
      passed: isProtected,
      expectedResult: 'repaired',
      details: isProtected
        ? `Pipeline protected against unhandled exceptions and aligned duration to ${standardAudioFeatures.duration}s.`
        : `Fallback failed to protect audio duration bounds.`,
    });
  }

  // Test 7 (Regression Audit): Invalid scene cannot show 100% Passed and archetype check failure cannot display Passed
  {
    const scene = createMockValidScene(30.0);
    // Make all sections share the exact same landscape archetype despite differing energy
    scene.sections[0].landscapeType = 'glass_island';
    scene.sections[1].landscapeType = 'glass_island';

    const verification = verifyWorldScene(scene, standardAudioFeatures);
    const diversityCheck = verification.report.checks.find((c) => c.id === 'landscape_diversity');

    // Assertions:
    // 1. diversityCheck must have passed === false
    // 2. diversityCheck must contain the failure explanation
    // 3. overall allPassed must be false (cannot show 100% Passed)
    // 4. passedCount must be strictly less than totalCount
    const passedCount = verification.report.checks.filter((c) => c.passed).length;
    const totalCount = verification.report.checks.length;

    const diversityFailed = diversityCheck !== undefined && diversityCheck.passed === false;
    const explanationMatches =
      diversityCheck?.details.includes('exact same landscape archetype') === true;
    const overallNotPassed = verification.report.allPassed === false && verification.passed === false;
    const not100Percent = passedCount < totalCount;

    const testPassed = diversityFailed && explanationMatches && overallNotPassed && not100Percent;

    results.push({
      id: 'test_7_invalid_archetypes_cannot_show_100_percent_passed',
      name: 'Regression Audit: Invalid Archetypes Cannot Show 100% Passed',
      description: 'Proves an invalid scene with identical archetypes cannot display Passed or show 100% Passed.',
      passed: testPassed,
      expectedResult: 'fail',
      details: testPassed
        ? `Strict check verified: landscape_diversity is FALSE (${passedCount}/${totalCount} passed), explanation matches failure, and overall report cannot claim 100% Passed.`
        : `Regression failure: Invalid scene falsely claimed passed (${passedCount}/${totalCount}, allPassed=${verification.report.allPassed}).`,
      diagnostics: verification.diagnostics,
    });
  }

  const testsPassed = results.filter((r) => r.passed).length;
  const testsTotal = results.length;
  const allPassed = testsPassed === testsTotal;

  return {
    timestamp: new Date().toISOString(),
    allPassed,
    testsPassed,
    testsTotal,
    results,
    verdict: allPassed
      ? `All Gemini 4 Argon World Generation Verification & Repair Tests Passed (${testsPassed}/${testsTotal})`
      : `${testsTotal - testsPassed} test(s) failed in verification suite`,
  };
}

// Standalone runner for CLI / build step verification
if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].includes('worldVerifierTest')) {
  console.log('[SoundShape] Running Gemini 4 Argon World Generation Verification Test Suite...');
  const report = runWorldVerifierTestSuite();
  console.log(`[SoundShape] ${report.verdict}`);
  report.results.forEach((r) => {
    console.log(`  ${r.passed ? '✓' : '✗'} [${r.id}] ${r.name}: ${r.details}`);
  });
  if (!report.allPassed) {
    process.exit(1);
  } else {
    console.log('[SoundShape] All verification tests passed successfully.');
  }
}
