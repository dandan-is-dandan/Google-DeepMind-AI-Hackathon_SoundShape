import { MultiLayerEdit, RhythmStep, WorldEditState, WorldScene } from '../types/world';

export type ComparisonPhase = 'idle' | 'before' | 'pause' | 'after' | 'complete';
export type ComparisonType = 'none' | 'before_only' | 'after_only' | 'ab_comparison';

export interface BeforeAfterProgress {
  phase: ComparisonPhase;
  type?: ComparisonType;
  step?: 1 | 2;
  label: string;
  progressRatio: number;
}

/**
 * RealAudioEngine: Web Audio API processing pipeline that directly and audibly
 * modifies the playback of the ACTUAL uploaded MP3 AudioBuffer.
 *
 * Signal processing chain for Edited Mode:
 * Source -> RhythmGain -> BassFilter (120 Hz Low-Shelf) -> TrebleFilter (6000 Hz High-Shelf)
 *        -> TextureFilter (400-12000 Hz Low-Pass) -> EnergyGain -> PeakLimiter -> WetGain -> Master
 *
 * Keeps the original AudioBuffer strictly immutable and non-destructively
 * shapes its playback signal with real-time gain envelopes, EQ filtering,
 * and multi-layer dynamic parameter automation with transparent studio limiting.
 */
export class RealAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;

  // Signal graph routing nodes
  private dryGain: GainNode | null = null;
  private wetGain: GainNode | null = null;

  // Multi-Layer DSP chain for Edited Mode
  private rhythmGain: GainNode | null = null;
  private bassFilter: BiquadFilterNode | null = null;
  private trebleFilter: BiquadFilterNode | null = null;
  private textureFilter: BiquadFilterNode | null = null;
  private energyGain: GainNode | null = null;
  private limiter: DynamicsCompressorNode | null = null;

  // Playback state
  private activeSource: AudioBufferSourceNode | null = null;
  private currentBuffer: AudioBuffer | null = null;
  private isPlaying = false;
  private isEditedMode = true;
  private startTime = 0;
  private pauseOffset = 0;
  private scheduledStepKeys = new Set<string>();

  // Comparison state
  private comparisonAbortController: AbortController | null = null;
  private onComparisonProgress?: (progress: BeforeAfterProgress) => void;

  constructor() {
    // Lazy initialization on first audio gesture
  }

  /**
   * Initializes or reuses the AudioContext and builds the complete multi-layer DSP graph.
   */
  public init(context?: AudioContext): AudioContext {
    if (!this.ctx) {
      this.ctx =
        context ||
        new (window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    if (!this.masterGain && this.ctx) {
      // 1. Master Output Gain
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.85, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      // 2. Dry Path (Original Unprocessed Audio)
      this.dryGain = this.ctx.createGain();
      this.dryGain.gain.setValueAtTime(this.isEditedMode ? 0.0 : 1.0, this.ctx.currentTime);
      this.dryGain.connect(this.masterGain);

      // 3. Wet Path (Sculpted Real Audio Multi-Layer DSP Chain)
      // A. Rhythm Envelope Gain Node (150-350ms window automation on original audio)
      this.rhythmGain = this.ctx.createGain();
      this.rhythmGain.gain.setValueAtTime(1.0, this.ctx.currentTime);

      // B. Bass Layer: Low Shelf EQ (~120 Hz, -12 dB to +12 dB)
      this.bassFilter = this.ctx.createBiquadFilter();
      this.bassFilter.type = 'lowshelf';
      this.bassFilter.frequency.setValueAtTime(120, this.ctx.currentTime);
      this.bassFilter.gain.setValueAtTime(0.0, this.ctx.currentTime);

      // C. Treble Layer: High Shelf EQ (~6000 Hz, -12 dB to +12 dB)
      this.trebleFilter = this.ctx.createBiquadFilter();
      this.trebleFilter.type = 'highshelf';
      this.trebleFilter.frequency.setValueAtTime(6000, this.ctx.currentTime);
      this.trebleFilter.gain.setValueAtTime(0.0, this.ctx.currentTime);

      // D. Texture Layer: Low-Pass Filter (400 Hz to 12000 Hz, default 12000 Hz)
      this.textureFilter = this.ctx.createBiquadFilter();
      this.textureFilter.type = 'lowpass';
      this.textureFilter.frequency.setValueAtTime(12000, this.ctx.currentTime);
      this.textureFilter.Q.setValueAtTime(1.0, this.ctx.currentTime);

      // E. Energy Layer: Dynamic Section & Moment Gain Node (-24 dB to +6 dB)
      this.energyGain = this.ctx.createGain();
      this.energyGain.gain.setValueAtTime(1.0, this.ctx.currentTime);

      // F. Studio Peak Limiter to prevent any digital clipping / distortion safely
      this.limiter = this.ctx.createDynamicsCompressor();
      this.limiter.threshold.setValueAtTime(-1.5, this.ctx.currentTime);
      this.limiter.knee.setValueAtTime(6.0, this.ctx.currentTime);
      this.limiter.ratio.setValueAtTime(16.0, this.ctx.currentTime);
      this.limiter.attack.setValueAtTime(0.002, this.ctx.currentTime);
      this.limiter.release.setValueAtTime(0.06, this.ctx.currentTime);

      // G. Wet Gain Node (Active when isEditedMode is true)
      this.wetGain = this.ctx.createGain();
      this.wetGain.gain.setValueAtTime(this.isEditedMode ? 1.0 : 0.0, this.ctx.currentTime);

      // Connect Wet DSP Chain in defined studio order:
      // RhythmGain -> BassFilter -> TrebleFilter -> TextureFilter -> EnergyGain -> Limiter -> WetGain
      this.rhythmGain.connect(this.bassFilter);
      this.bassFilter.connect(this.trebleFilter);
      this.trebleFilter.connect(this.textureFilter);
      this.textureFilter.connect(this.energyGain);
      this.energyGain.connect(this.limiter);
      this.limiter.connect(this.wetGain);
      this.wetGain.connect(this.masterGain);
    }

    return this.ctx;
  }

  public getContext(): AudioContext | null {
    return this.ctx;
  }

  public setBuffer(buffer: AudioBuffer | null) {
    this.stop();
    this.currentBuffer = buffer;
    this.pauseOffset = 0;
  }

  public getBuffer(): AudioBuffer | null {
    return this.currentBuffer;
  }

  public setMasterVolume(vol: number) {
    if (this.masterGain && this.ctx) {
      const clamped = Math.max(0, Math.min(1, vol));
      this.masterGain.gain.setTargetAtTime(clamped, this.ctx.currentTime, 0.03);
    }
  }

  /**
   * Switches seamlessly between Original Mode (dry unprocessed audio) and
   * Edited Mode (wet audio multi-layer DSP pipeline).
   */
  public setEditedMode(isEdited: boolean) {
    this.isEditedMode = isEdited;
    if (!this.ctx || !this.dryGain || !this.wetGain) return;

    const now = this.ctx.currentTime;
    if (isEdited) {
      this.dryGain.gain.setTargetAtTime(0.0, now, 0.02);
      this.wetGain.gain.setTargetAtTime(1.0, now, 0.02);
    } else {
      this.wetGain.gain.setTargetAtTime(0.0, now, 0.02);
      this.dryGain.gain.setTargetAtTime(1.0, now, 0.02);
    }
  }

  public getIsEditedMode(): boolean {
    return this.isEditedMode;
  }

  /**
   * Starts or resumes playback of the immutable original AudioBuffer.
   */
  public play(offsetSeconds?: number, onEnded?: () => void) {
    this.init();
    if (!this.ctx || !this.currentBuffer || !this.dryGain || !this.rhythmGain) return;

    this.stopSourceOnly();

    const startOffset = Math.max(
      0,
      Math.min(
        this.currentBuffer.duration - 0.01,
        offsetSeconds !== undefined ? offsetSeconds : this.pauseOffset
      )
    );

    const source = this.ctx.createBufferSource();
    source.buffer = this.currentBuffer;

    // Connect source simultaneously to dry and wet entry points
    source.connect(this.dryGain);
    source.connect(this.rhythmGain);

    this.startTime = this.ctx.currentTime - startOffset;
    this.pauseOffset = startOffset;
    this.isPlaying = true;
    this.scheduledStepKeys.clear();

    source.start(0, startOffset);

    source.onended = () => {
      if (this.activeSource === source) {
        this.isPlaying = false;
        if (this.ctx && this.currentBuffer) {
          const elapsed = this.ctx.currentTime - this.startTime;
          if (elapsed >= this.currentBuffer.duration) {
            this.pauseOffset = 0;
          }
        }
        if (onEnded) onEnded();
      }
    };

    this.activeSource = source;
  }

  /**
   * Stops playback and preserves the current seek offset.
   */
  public stop(): number {
    if (this.ctx && this.isPlaying) {
      this.pauseOffset = this.ctx.currentTime - this.startTime;
      if (this.currentBuffer) {
        this.pauseOffset = Math.max(0, Math.min(this.currentBuffer.duration, this.pauseOffset));
      }
    }
    this.stopSourceOnly();
    this.isPlaying = false;
    this.scheduledStepKeys.clear();
    return this.pauseOffset;
  }

  private stopSourceOnly() {
    if (this.activeSource) {
      try {
        this.activeSource.stop();
        this.activeSource.disconnect();
      } catch {
        // Safe ignore
      }
      this.activeSource = null;
    }
  }

  public seek(newTimeSeconds: number, onEnded?: () => void) {
    const wasPlaying = this.isPlaying;
    this.stop();
    this.pauseOffset = Math.max(0, newTimeSeconds);
    if (this.currentBuffer) {
      this.pauseOffset = Math.min(this.currentBuffer.duration, this.pauseOffset);
    }
    if (wasPlaying) {
      this.play(this.pauseOffset, onEnded);
    }
  }

  public getCurrentPlaybackTime(): number {
    if (!this.isPlaying || !this.ctx) return this.pauseOffset;
    const cur = this.ctx.currentTime - this.startTime;
    if (this.currentBuffer) {
      return Math.max(0, Math.min(this.currentBuffer.duration, cur));
    }
    return Math.max(0, cur);
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  /**
   * Maps Bass intensity (0.0 to 1.0) or dB value to a low-shelf filter gain in dB.
   */
  public static bassIntensityToDb(intensity: number): number {
    const clamped = Math.max(0, Math.min(1, intensity));
    if (clamped < 0.5) {
      return -12.0 * (1 - clamped / 0.5);
    } else {
      return 12.0 * ((clamped - 0.5) / 0.5);
    }
  }

  /**
   * Maps Energy level (0.0 to 1.0) to linear gain multiplier.
   */
  public static energyLevelToLinearGain(energy: number): number {
    const clamped = Math.max(0, Math.min(1, energy));
    if (clamped < 0.5) {
      return 0.35 + (clamped / 0.5) * 0.65; // 0 -> 0.35 (-9.1 dB), 0.5 -> 1.0
    } else {
      return 1.0 + ((clamped - 0.5) / 0.5) * 0.55; // 0.5 -> 1.0, 1.0 -> 1.55 (+3.8 dB)
    }
  }

  /**
   * Converts dB value (-24 to +6) to linear gain multiplier.
   */
  public static dbToLinear(db: number): number {
    return Math.pow(10, Math.max(-24, Math.min(6, db)) / 20);
  }

  /**
   * Maps Rhythm Crystal height/intensity to gain multiplier in window.
   */
  public static rhythmIntensityToGain(intensity: number, active: boolean): number {
    if (!active) return 0.06;
    const clamped = Math.max(0, Math.min(1, intensity));
    if (clamped < 0.5) {
      return 0.15 + (clamped / 0.5) * 0.85; // 0 -> 0.15, 0.5 -> 1.0
    } else {
      return 1.0 + ((clamped - 0.5) / 0.5) * 0.85; // 0.5 -> 1.0, 1.0 -> 1.85
    }
  }

  public static getRhythmWindow(
    stepTimestamp: number,
    sectionDuration: number,
    stepCount: number
  ): { start: number; end: number; duration: number } {
    const duration = Math.max(0.18, Math.min(0.36, sectionDuration / Math.max(4, stepCount * 1.2)));
    const start = Math.max(0, stepTimestamp - 0.02);
    const end = start + duration;
    return { start, end, duration };
  }

  /**
   * Real-time DSP updates for individual layers
   */
  public updateBassInRealtime(targetDb: number) {
    if (this.bassFilter && this.ctx) {
      this.bassFilter.gain.setTargetAtTime(
        Math.max(-12, Math.min(12, targetDb)),
        this.ctx.currentTime,
        0.04
      );
    }
  }

  public updateTrebleInRealtime(targetDb: number) {
    if (this.trebleFilter && this.ctx) {
      this.trebleFilter.gain.setTargetAtTime(
        Math.max(-12, Math.min(12, targetDb)),
        this.ctx.currentTime,
        0.04
      );
    }
  }

  public updateTextureInRealtime(targetHz: number) {
    if (this.textureFilter && this.ctx) {
      this.textureFilter.frequency.setTargetAtTime(
        Math.max(400, Math.min(12000, targetHz)),
        this.ctx.currentTime,
        0.04
      );
    }
  }

  public updateEnergyInRealtime(targetGain: number) {
    if (this.energyGain && this.ctx) {
      this.energyGain.gain.setTargetAtTime(Math.max(0.06, targetGain), this.ctx.currentTime, 0.04);
    }
  }

  /**
   * Continuous tick handler for real-time Multi-Layer DSP automation:
   * Dynamically coordinates Energy, Bass, Treble, and Texture edits based on
   * the song playback position.
   */
  public processPlaybackTick(
    currentTime: number,
    scene: WorldScene,
    editState: WorldEditState,
    multiLayerEdits: MultiLayerEdit[] = []
  ) {
    if (!this.isPlaying || !this.ctx || !this.isEditedMode) return;

    // 1. Check for any active multi-layer edits at the current playback position
    const activeEditsAtTime = multiLayerEdits.filter(
      (e) => e.enabled && currentTime >= e.startTime && currentTime <= e.endTime
    );

    const activeEnergyEdit = activeEditsAtTime.find((e) => e.layer === 'energy');
    const activeBassEdit = activeEditsAtTime.find((e) => e.layer === 'bass');
    const activeTrebleEdit = activeEditsAtTime.find((e) => e.layer === 'treble');
    const activeTextureEdit = activeEditsAtTime.find((e) => e.layer === 'texture');

    // 2. Identify the active musical section for section-baseline settings
    const activeSection = scene.sections.find(
      (s) => currentTime >= s.start && currentTime <= s.end
    );

    // --- A. BASS LAYER AUTOMATION ---
    if (this.bassFilter) {
      let targetBassDb = 0.0;
      if (activeBassEdit) {
        targetBassDb = activeBassEdit.editedValue;
      } else if (activeSection) {
        const secEdit = editState[activeSection.id];
        const val = secEdit?.bassIntensity ?? 0.5;
        targetBassDb = RealAudioEngine.bassIntensityToDb(val);
      }
      this.bassFilter.gain.setTargetAtTime(targetBassDb, this.ctx.currentTime, 0.05);
    }

    // --- B. TREBLE LAYER AUTOMATION ---
    if (this.trebleFilter) {
      const targetTrebleDb = activeTrebleEdit ? activeTrebleEdit.editedValue : 0.0;
      this.trebleFilter.gain.setTargetAtTime(targetTrebleDb, this.ctx.currentTime, 0.05);
    }

    // --- C. TEXTURE LAYER AUTOMATION (Low-Pass Filter) ---
    if (this.textureFilter) {
      const targetCutoff = activeTextureEdit ? activeTextureEdit.editedValue : 12000;
      this.textureFilter.frequency.setTargetAtTime(targetCutoff, this.ctx.currentTime, 0.05);
    }

    // --- D. ENERGY LAYER AUTOMATION ---
    if (this.energyGain) {
      let targetEnergyGain = 1.0;
      if (activeEnergyEdit) {
        targetEnergyGain = RealAudioEngine.dbToLinear(activeEnergyEdit.editedValue);
      } else if (activeSection) {
        const secEdit = editState[activeSection.id];
        const val = secEdit?.energyLevel ?? activeSection.energy;
        targetEnergyGain = RealAudioEngine.energyLevelToLinearGain(val);
      }
      this.energyGain.gain.setTargetAtTime(targetEnergyGain, this.ctx.currentTime, 0.05);
    }

    // --- E. PITCH & TIMING AUTOMATION (Varispeed PlaybackRate) ---
    if (this.activeSource && this.activeSource.playbackRate) {
      const activePitchEdit = activeEditsAtTime.find((e) => e.layer === 'pitch');
      const activeTimingEdit = activeEditsAtTime.find((e) => e.layer === 'timing');

      let targetRate = 1.0;
      if (activePitchEdit) {
        // Varispeed semitone pitch shift: 2^(semitones / 12)
        targetRate *= Math.pow(2, activePitchEdit.editedValue / 12);
      }
      if (activeTimingEdit) {
        targetRate *= Math.max(0.7, Math.min(1.4, activeTimingEdit.editedValue));
      }

      this.activeSource.playbackRate.setTargetAtTime(
        Math.max(0.5, Math.min(2.0, targetRate)),
        this.ctx.currentTime,
        0.05
      );
    }

    // --- F. RHYTHM CRYSTAL ENVELOPE AUTOMATION (350ms Lookahead) ---
    if (activeSection) {
      const lookahead = 0.35;
      const secDuration = activeSection.end - activeSection.start;
      const steps = editState[activeSection.id]?.rhythmSteps || [];

      steps.forEach((step) => {
        const stepTimestamp = activeSection.start + step.timeRatio * secDuration;
        const timeUntilStep = stepTimestamp - currentTime;

        if (timeUntilStep >= -0.05 && timeUntilStep < lookahead) {
          const stepKey = `${activeSection.id}_${step.index}_${Math.floor(currentTime * 2)}`;
          if (!this.scheduledStepKeys.has(stepKey)) {
            this.scheduledStepKeys.add(stepKey);
            this.scheduleRhythmGainEnvelope(step, stepTimestamp, secDuration, steps.length);
          }
        }
      });
    }

    if (this.scheduledStepKeys.size > 200) {
      this.scheduledStepKeys.clear();
    }
  }

  private scheduleRhythmGainEnvelope(
    step: RhythmStep,
    stepTimestamp: number,
    sectionDuration: number,
    stepCount: number
  ) {
    if (!this.ctx || !this.rhythmGain) return;

    const audioCurrentTime = this.ctx.currentTime;
    const songCurrentTime = this.getCurrentPlaybackTime();
    const leadTime = stepTimestamp - songCurrentTime;

    const targetAudioTime = audioCurrentTime + leadTime;
    if (targetAudioTime < audioCurrentTime - 0.02) return;

    const { duration } = RealAudioEngine.getRhythmWindow(
      stepTimestamp,
      sectionDuration,
      stepCount
    );

    const targetGain = RealAudioEngine.rhythmIntensityToGain(step.intensity, step.active);
    const gainParam = this.rhythmGain.gain;

    const attackTime = 0.015;
    const releaseTime = 0.025;
    const sustainTime = Math.max(0.05, duration - attackTime - releaseTime);

    const tStart = Math.max(audioCurrentTime, targetAudioTime - attackTime);
    const tPeak = tStart + attackTime;
    const tSustain = tPeak + sustainTime;
    const tEnd = tSustain + releaseTime;

    try {
      gainParam.setValueAtTime(gainParam.value, tStart);
      gainParam.linearRampToValueAtTime(targetGain, tPeak);
      gainParam.setValueAtTime(targetGain, tSustain);
      gainParam.linearRampToValueAtTime(1.0, tEnd);
    } catch {
      gainParam.setTargetAtTime(targetGain, audioCurrentTime, 0.02);
      setTimeout(() => {
        if (this.rhythmGain && this.ctx) {
          this.rhythmGain.gain.setTargetAtTime(1.0, this.ctx.currentTime, 0.03);
        }
      }, duration * 1000);
    }
  }

  /**
   * Auditions a dedicated audio passage slice (e.g. 2-3 seconds)
   * in either Original mode (100% dry) or Edited mode (with active layer DSP).
   */
  public auditionPassage(options: {
    startSeconds: number;
    durationSeconds: number;
    isEdited: boolean;
    edits?: MultiLayerEdit[];
    onEnded?: () => void;
  }) {
    this.init();
    if (!this.ctx || !this.currentBuffer) return;

    this.stop();
    this.setEditedMode(options.isEdited);

    // Apply immediate DSP node parameters if in edited mode
    if (options.isEdited && options.edits && options.edits.length > 0) {
      options.edits.forEach((e) => {
        if (!e.enabled) return;
        if (e.layer === 'energy' && this.energyGain) {
          this.energyGain.gain.setValueAtTime(RealAudioEngine.dbToLinear(e.editedValue), this.ctx!.currentTime);
        } else if (e.layer === 'bass' && this.bassFilter) {
          this.bassFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
        } else if (e.layer === 'treble' && this.trebleFilter) {
          this.trebleFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
        } else if (e.layer === 'texture' && this.textureFilter) {
          this.textureFilter.frequency.setValueAtTime(e.editedValue, this.ctx!.currentTime);
        }
      });
    }

    const start = Math.max(0, Math.min(this.currentBuffer.duration - 0.2, options.startSeconds));
    const duration = Math.min(this.currentBuffer.duration - start, options.durationSeconds);

    this.play(start, options.onEnded);

    setTimeout(() => {
      if (this.isPlaying) {
        this.stop();
        if (options.onEnded) options.onEnded();
      }
    }, duration * 1000);
  }

  /**
   * Plays the unedited original recording for the selected time window.
   */
  public async playBeforeAudition(options: {
    startSeconds: number;
    durationSeconds?: number;
    onProgress?: (p: BeforeAfterProgress) => void;
  }): Promise<void> {
    this.init();
    if (!this.ctx || !this.currentBuffer) return;

    if (this.comparisonAbortController) {
      this.comparisonAbortController.abort();
    }
    this.comparisonAbortController = new AbortController();
    const signal = this.comparisonAbortController.signal;

    this.stop();
    this.onComparisonProgress = options.onProgress;

    const duration = Math.min(4.0, Math.max(0.5, options.durationSeconds || 2.5));
    const start = Math.max(0, Math.min(this.currentBuffer.duration - duration, options.startSeconds));

    try {
      this.setEditedMode(false);
      options.onProgress?.({
        phase: 'before',
        type: 'before_only',
        step: 1,
        label: 'Now Playing: Original',
        progressRatio: 0.05,
      });

      this.play(start);

      await this.sleepWithProgress(
        duration,
        0.05,
        1.0,
        'Now Playing: Original',
        signal,
        'before',
        'before_only',
        1
      );
      if (signal.aborted) return;

      this.stop();
      options.onProgress?.({
        phase: 'complete',
        type: 'before_only',
        label: 'Original Playback Complete',
        progressRatio: 1.0,
      });
    } catch (err: unknown) {
      if ((err as Error)?.name === 'AbortError') return;
      console.warn('[RealAudioEngine] Before audition error:', err);
    }
  }

  /**
   * Plays the real audio modified by currently active layer edits for the selected time window.
   */
  public async playAfterAudition(options: {
    startSeconds: number;
    durationSeconds?: number;
    sectionId: string;
    scene: WorldScene;
    editState: WorldEditState;
    multiLayerEdits?: MultiLayerEdit[];
    onProgress?: (p: BeforeAfterProgress) => void;
  }): Promise<void> {
    this.init();
    if (!this.ctx || !this.currentBuffer) return;

    if (this.comparisonAbortController) {
      this.comparisonAbortController.abort();
    }
    this.comparisonAbortController = new AbortController();
    const signal = this.comparisonAbortController.signal;

    this.stop();
    this.onComparisonProgress = options.onProgress;

    const duration = Math.min(4.0, Math.max(0.5, options.durationSeconds || 2.5));
    const start = Math.max(0, Math.min(this.currentBuffer.duration - duration, options.startSeconds));

    try {
      this.setEditedMode(true);

      // Apply section baseline settings
      const sec = options.scene.sections.find((s) => s.id === options.sectionId);
      if (sec) {
        const secEdit = options.editState[sec.id];
        if (secEdit) {
          const bassDb = RealAudioEngine.bassIntensityToDb(secEdit.bassIntensity);
          const energyGain = RealAudioEngine.energyLevelToLinearGain(secEdit.energyLevel);
          if (this.bassFilter) this.bassFilter.gain.setValueAtTime(bassDb, this.ctx.currentTime);
          if (this.energyGain) this.energyGain.gain.setValueAtTime(energyGain, this.ctx.currentTime);
        }
      }

      // Apply specific active multi-layer edits
      if (options.multiLayerEdits && options.multiLayerEdits.length > 0) {
        options.multiLayerEdits.forEach((e) => {
          if (!e.enabled) return;
          if (e.layer === 'energy' && this.energyGain) {
            this.energyGain.gain.setValueAtTime(RealAudioEngine.dbToLinear(e.editedValue), this.ctx!.currentTime);
          } else if (e.layer === 'bass' && this.bassFilter) {
            this.bassFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
          } else if (e.layer === 'treble' && this.trebleFilter) {
            this.trebleFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
          } else if (e.layer === 'texture' && this.textureFilter) {
            this.textureFilter.frequency.setValueAtTime(e.editedValue, this.ctx!.currentTime);
          }
        });
      }

      options.onProgress?.({
        phase: 'after',
        type: 'after_only',
        step: 2,
        label: 'Now Playing: Edited',
        progressRatio: 0.05,
      });

      this.play(start);

      await this.sleepWithProgress(
        duration,
        0.05,
        1.0,
        'Now Playing: Edited',
        signal,
        'after',
        'after_only',
        2
      );
      if (signal.aborted) return;

      this.stop();
      options.onProgress?.({
        phase: 'complete',
        type: 'after_only',
        label: 'Edited Playback Complete',
        progressRatio: 1.0,
      });
    } catch (err: unknown) {
      if ((err as Error)?.name === 'AbortError') return;
      console.warn('[RealAudioEngine] After audition error:', err);
    }
  }

  /**
   * Executes a verified Before / After comparison (Compare A -> B).
   * Phase 1: Plays unprocessed original recording.
   * Phase 2: Plays exact same passage modified by active layer edits.
   */
  public async playBeforeAfterComparison(options: {
    startSeconds: number;
    durationSeconds?: number;
    sectionId: string;
    scene: WorldScene;
    editState: WorldEditState;
    multiLayerEdits?: MultiLayerEdit[];
    onProgress: (p: BeforeAfterProgress) => void;
  }): Promise<void> {
    this.init();
    if (!this.ctx || !this.currentBuffer) return;

    if (this.comparisonAbortController) {
      this.comparisonAbortController.abort();
    }
    this.comparisonAbortController = new AbortController();
    const signal = this.comparisonAbortController.signal;

    this.stop();
    this.onComparisonProgress = options.onProgress;

    const duration = Math.min(3.0, Math.max(1.8, options.durationSeconds || 2.5));
    const start = Math.max(0, Math.min(this.currentBuffer.duration - duration, options.startSeconds));

    try {
      // ------------------------------------------
      // PHASE 1: BEFORE (Unprocessed Original Recording)
      // ------------------------------------------
      options.onProgress({
        phase: 'before',
        type: 'ab_comparison',
        step: 1,
        label: 'Step 1 of 2 — Original',
        progressRatio: 0.05,
      });

      this.setEditedMode(false);
      this.play(start);

      await this.sleepWithProgress(
        duration,
        0.05,
        0.48,
        'Step 1 of 2 — Original',
        signal,
        'before',
        'ab_comparison',
        1
      );
      if (signal.aborted) return;

      this.stop();

      // ------------------------------------------
      // PAUSE GAP (300ms)
      // ------------------------------------------
      options.onProgress({
        phase: 'pause',
        type: 'ab_comparison',
        label: 'Switching to Step 2...',
        progressRatio: 0.5,
      });
      await this.sleep(300, signal);
      if (signal.aborted) return;

      // ------------------------------------------
      // PHASE 2: AFTER (Actual audio with active edits)
      // ------------------------------------------
      options.onProgress({
        phase: 'after',
        type: 'ab_comparison',
        step: 2,
        label: 'Step 2 of 2 — Edited',
        progressRatio: 0.55,
      });

      this.setEditedMode(true);

      // Apply section baseline settings
      const sec = options.scene.sections.find((s) => s.id === options.sectionId);
      if (sec) {
        const secEdit = options.editState[sec.id];
        if (secEdit) {
          const bassDb = RealAudioEngine.bassIntensityToDb(secEdit.bassIntensity);
          const energyGain = RealAudioEngine.energyLevelToLinearGain(secEdit.energyLevel);
          if (this.bassFilter) this.bassFilter.gain.setValueAtTime(bassDb, this.ctx.currentTime);
          if (this.energyGain) this.energyGain.gain.setValueAtTime(energyGain, this.ctx.currentTime);
        }
      }

      // Apply specific active multi-layer edits for this range
      if (options.multiLayerEdits && options.multiLayerEdits.length > 0) {
        options.multiLayerEdits.forEach((e) => {
          if (!e.enabled) return;
          if (e.layer === 'energy' && this.energyGain) {
            this.energyGain.gain.setValueAtTime(RealAudioEngine.dbToLinear(e.editedValue), this.ctx!.currentTime);
          } else if (e.layer === 'bass' && this.bassFilter) {
            this.bassFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
          } else if (e.layer === 'treble' && this.trebleFilter) {
            this.trebleFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
          } else if (e.layer === 'texture' && this.textureFilter) {
            this.textureFilter.frequency.setValueAtTime(e.editedValue, this.ctx!.currentTime);
          }
        });
      }

      this.play(start);

      await this.sleepWithProgress(
        duration,
        0.55,
        0.98,
        'Step 2 of 2 — Edited',
        signal,
        'after',
        'ab_comparison',
        2
      );
      if (signal.aborted) return;

      this.stop();
      options.onProgress({
        phase: 'complete',
        type: 'ab_comparison',
        label: 'Comparison Complete',
        progressRatio: 1.0,
      });
    } catch (err: unknown) {
      if ((err as Error)?.name === 'AbortError') return;
      console.warn('[RealAudioEngine] Comparison error:', err);
    }
  }

  private sleep(ms: number, signal?: AbortSignal): Promise<void> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(resolve, ms);
      if (signal) {
        signal.addEventListener(
          'abort',
          () => {
            clearTimeout(timer);
            reject(new DOMException('Aborted', 'AbortError'));
          },
          { once: true }
        );
      }
    });
  }

  private async sleepWithProgress(
    durationSec: number,
    startRatio: number,
    endRatio: number,
    label: string,
    signal: AbortSignal,
    phase: ComparisonPhase = 'before',
    type: ComparisonType = 'ab_comparison',
    step?: 1 | 2
  ): Promise<void> {
    const steps = 25;
    const stepTime = (durationSec * 1000) / steps;
    for (let i = 0; i < steps; i++) {
      if (signal.aborted) throw new DOMException('Aborted', 'AbortError');
      const ratio = startRatio + (endRatio - startRatio) * (i / steps);
      if (this.onComparisonProgress) {
        this.onComparisonProgress({ phase, type, step, label, progressRatio: ratio });
      }
      await this.sleep(stepTime, signal);
    }
  }

  /**
   * Auditions an exact bounded window with smooth fade-in and fade-out to prevent clicks.
   */
  public auditionWindow(options: {
    startTime: number;
    endTime: number;
    edits?: MultiLayerEdit[];
    isEdited?: boolean;
    onEnded?: () => void;
  }) {
    this.init();
    if (!this.ctx || !this.currentBuffer) return;

    this.stop();
    const isEdited = options.isEdited ?? this.isEditedMode;
    this.setEditedMode(isEdited);

    const safeStart = Math.max(0, options.startTime);
    const safeEnd = Math.min(this.currentBuffer.duration, Math.max(safeStart + 0.1, options.endTime));
    const windowDuration = safeEnd - safeStart;

    if (isEdited && options.edits && options.edits.length > 0) {
      options.edits.forEach((e) => {
        if (!e.enabled) return;
        if (e.layer === 'energy' && this.energyGain) {
          this.energyGain.gain.setValueAtTime(RealAudioEngine.dbToLinear(e.editedValue), this.ctx!.currentTime);
        } else if (e.layer === 'bass' && this.bassFilter) {
          this.bassFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
        } else if (e.layer === 'treble' && this.trebleFilter) {
          this.trebleFilter.gain.setValueAtTime(e.editedValue, this.ctx!.currentTime);
        } else if (e.layer === 'texture' && this.textureFilter) {
          this.textureFilter.frequency.setValueAtTime(e.editedValue, this.ctx!.currentTime);
        }
      });
    }

    this.play(safeStart, options.onEnded);

    setTimeout(() => {
      if (this.isPlaying) {
        this.stop();
        if (options.onEnded) options.onEnded();
      }
    }, windowDuration * 1000);
  }

  /**
   * Performs full offline rendering of the uploaded AudioBuffer with all
   * active section edits, rhythm envelopes, and multi-layer parameter automations,
   * returning a 16-bit PCM WAV Blob ready for download.
   */
  public async exportEditedAudioWav(
    scene: WorldScene,
    editState: WorldEditState,
    multiLayerEdits: MultiLayerEdit[] = []
  ): Promise<Blob> {
    if (!this.currentBuffer) {
      throw new Error('No audio buffer loaded to export.');
    }

    const buffer = this.currentBuffer;
    const sampleRate = buffer.sampleRate;
    const length = buffer.length;
    const offlineCtx = new OfflineAudioContext(buffer.numberOfChannels, length, sampleRate);

    const source = offlineCtx.createBufferSource();
    source.buffer = buffer;

    // Build offline DSP graph matching realAudioEngine wet path
    const rhythmGain = offlineCtx.createGain();
    rhythmGain.gain.setValueAtTime(1.0, 0);

    // Schedule all rhythm step envelopes across sections
    scene.sections.forEach((sec) => {
      const secEd = editState[sec.id];
      const steps = secEd?.rhythmSteps || [];
      const secDuration = sec.end - sec.start;
      steps.forEach((step) => {
        const stepTimestamp = sec.start + step.timeRatio * secDuration;
        const targetGain = RealAudioEngine.rhythmIntensityToGain(step.intensity, step.active);
        const { duration } = RealAudioEngine.getRhythmWindow(stepTimestamp, secDuration, steps.length);
        const attack = 0.015;
        const release = 0.025;
        const sustain = Math.max(0.04, duration - attack - release);

        const tStart = Math.max(0, stepTimestamp - attack);
        const tPeak = tStart + attack;
        const tSustain = tPeak + sustain;
        const tEnd = tSustain + release;

        try {
          rhythmGain.gain.setValueAtTime(1.0, Math.max(0, tStart - 0.005));
          rhythmGain.gain.linearRampToValueAtTime(targetGain, tPeak);
          rhythmGain.gain.setValueAtTime(targetGain, tSustain);
          rhythmGain.gain.linearRampToValueAtTime(1.0, tEnd);
        } catch {
          // Guard against overlapping automation
        }
      });
    });

    // Bass Filter (120 Hz)
    const bassFilter = offlineCtx.createBiquadFilter();
    bassFilter.type = 'lowshelf';
    bassFilter.frequency.setValueAtTime(120, 0);
    bassFilter.gain.setValueAtTime(0, 0);

    // Section bass settings
    scene.sections.forEach((sec) => {
      const secEd = editState[sec.id];
      const val = secEd?.bassIntensity ?? 0.5;
      const db = RealAudioEngine.bassIntensityToDb(val);
      try {
        bassFilter.gain.setValueAtTime(db, sec.start);
      } catch {
        // Safe ignore
      }
    });

    // Multi-layer bass edits
    multiLayerEdits
      .filter((e) => e.enabled && e.layer === 'bass')
      .forEach((e) => {
        try {
          bassFilter.gain.setValueAtTime(e.editedValue, e.startTime);
          bassFilter.gain.setValueAtTime(0, e.endTime);
        } catch {
          // Safe ignore
        }
      });

    // Treble Filter (6000 Hz)
    const trebleFilter = offlineCtx.createBiquadFilter();
    trebleFilter.type = 'highshelf';
    trebleFilter.frequency.setValueAtTime(6000, 0);
    trebleFilter.gain.setValueAtTime(0, 0);

    multiLayerEdits
      .filter((e) => e.enabled && e.layer === 'treble')
      .forEach((e) => {
        try {
          trebleFilter.gain.setValueAtTime(e.editedValue, e.startTime);
          trebleFilter.gain.setValueAtTime(0, e.endTime);
        } catch {
          // Safe ignore
        }
      });

    // Texture Filter (Low-pass)
    const textureFilter = offlineCtx.createBiquadFilter();
    textureFilter.type = 'lowpass';
    textureFilter.frequency.setValueAtTime(12000, 0);

    multiLayerEdits
      .filter((e) => e.enabled && e.layer === 'texture')
      .forEach((e) => {
        try {
          textureFilter.frequency.setValueAtTime(e.editedValue, e.startTime);
          textureFilter.frequency.setValueAtTime(12000, e.endTime);
        } catch {
          // Safe ignore
        }
      });

    // Energy Gain
    const energyGain = offlineCtx.createGain();
    energyGain.gain.setValueAtTime(1.0, 0);

    scene.sections.forEach((sec) => {
      const secEd = editState[sec.id];
      const val = secEd?.energyLevel ?? sec.energy;
      const g = RealAudioEngine.energyLevelToLinearGain(val);
      try {
        energyGain.gain.setValueAtTime(g, sec.start);
      } catch {
        // Safe ignore
      }
    });

    multiLayerEdits
      .filter((e) => e.enabled && e.layer === 'energy')
      .forEach((e) => {
        try {
          const g = RealAudioEngine.dbToLinear(e.editedValue);
          energyGain.gain.setValueAtTime(g, e.startTime);
          energyGain.gain.setValueAtTime(1.0, e.endTime);
        } catch {
          // Safe ignore
        }
      });

    // Studio Peak Limiter
    const limiter = offlineCtx.createDynamicsCompressor();
    limiter.threshold.setValueAtTime(-1.5, 0);
    limiter.knee.setValueAtTime(6.0, 0);
    limiter.ratio.setValueAtTime(16.0, 0);
    limiter.attack.setValueAtTime(0.002, 0);
    limiter.release.setValueAtTime(0.06, 0);

    // Wire: Source -> Rhythm -> Bass -> Treble -> Texture -> Energy -> Limiter -> Destination
    source.connect(rhythmGain);
    rhythmGain.connect(bassFilter);
    bassFilter.connect(trebleFilter);
    trebleFilter.connect(textureFilter);
    textureFilter.connect(energyGain);
    energyGain.connect(limiter);
    limiter.connect(offlineCtx.destination);

    source.start(0);

    const renderedBuffer = await offlineCtx.startRendering();
    return audioBufferToWav(renderedBuffer);
  }

  public cancelComparison() {
    if (this.comparisonAbortController) {
      this.comparisonAbortController.abort();
      this.comparisonAbortController = null;
    }
    this.stop();
  }

  public dispose() {
    this.stop();
    this.cancelComparison();
    if (this.ctx && this.ctx.state !== 'closed') {
      try {
        this.ctx.close();
      } catch {
        // Safe ignore
      }
    }
    this.ctx = null;
    this.masterGain = null;
    this.dryGain = null;
    this.wetGain = null;
    this.rhythmGain = null;
    this.bassFilter = null;
    this.trebleFilter = null;
    this.textureFilter = null;
    this.energyGain = null;
    this.limiter = null;
  }
}

/**
 * Encodes an AudioBuffer into standard 16-bit PCM WAV Blob format.
 */
export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const numSamples = buffer.length;
  const byteRate = sampleRate * blockAlign;
  const dataSize = numSamples * blockAlign;
  const bufferSize = 44 + dataSize;
  const arrayBuffer = new ArrayBuffer(bufferSize);
  const view = new DataView(arrayBuffer);

  function writeString(offset: number, str: string) {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  }

  // RIFF chunk descriptor
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');

  // fmt sub-chunk
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // SubChunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);

  // data sub-chunk
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  // Interleave channel samples
  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      const sample = Math.max(-1, Math.min(1, buffer.getChannelData(ch)[i]));
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

export function downloadWavBlob(blob: Blob, filename = 'soundshape_edited.wav') {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 1000);
}

export const realAudioEngine = new RealAudioEngine();
