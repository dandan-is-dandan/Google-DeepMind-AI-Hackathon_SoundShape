import { RealAudioEngine } from './realAudioEngine';

export interface AudioTestCaseResult {
  id: string;
  name: string;
  description: string;
  targetSculpture: 'Rhythm Crystal' | 'Bass River' | 'Energy Core' | 'Original Mode Pass-Through' | 'Combined World';
  passed: boolean;
  sampleCount: number;
  rmsDifference: number;
  maxSampleDelta: number;
  details: string;
}

export interface AudioTestSuiteReport {
  timestamp: string;
  allPassed: boolean;
  testsPassed: number;
  testsTotal: number;
  results: AudioTestCaseResult[];
  verdict: string;
}

/**
 * Creates a 3-second reference test AudioBuffer containing a rich acoustic signal
 * (low sub-bass sine, mid-frequency harmonic pad, and high percussive click)
 * to verify DSP changes deterministically.
 */
export function createTestAudioBuffer(
  ctx: BaseAudioContext,
  durationSec = 3.0,
  sampleRate = 44100
): AudioBuffer {
  const length = Math.floor(sampleRate * durationSec);
  const buffer = ctx.createBuffer(2, length, sampleRate);

  for (let ch = 0; ch < 2; ch++) {
    const data = buffer.getChannelData(ch);
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      // 1. Low frequency bass tone (80 Hz)
      const bass = Math.sin(2 * Math.PI * 80 * t) * 0.3;
      // 2. Mid frequency harmonic chord (440 Hz + 554 Hz)
      const mid = (Math.sin(2 * Math.PI * 440 * t) + Math.sin(2 * Math.PI * 554 * t)) * 0.15;
      // 3. Rhythmic transient pulse every 0.5 seconds
      const pulsePhase = (t % 0.5) / 0.5;
      const transient = pulsePhase < 0.05 ? Math.exp(-pulsePhase * 80) * 0.4 : 0;

      data[i] = bass + mid + transient;
    }
  }

  return buffer;
}

/**
 * Computes RMS (Root Mean Square) difference and maximum delta between two AudioBuffers.
 */
export function computeBufferDifference(
  bufA: AudioBuffer,
  bufB: AudioBuffer
): { rmsDifference: number; maxSampleDelta: number; sampleCount: number } {
  const chDataA = bufA.getChannelData(0);
  const chDataB = bufB.getChannelData(0);
  const len = Math.min(chDataA.length, chDataB.length);

  let sumSquaredDiff = 0;
  let maxDelta = 0;

  for (let i = 0; i < len; i++) {
    const delta = Math.abs(chDataA[i] - chDataB[i]);
    sumSquaredDiff += delta * delta;
    if (delta > maxDelta) {
      maxDelta = delta;
    }
  }

  const rmsDifference = Math.sqrt(sumSquaredDiff / len);
  return { rmsDifference, maxSampleDelta: maxDelta, sampleCount: len };
}

/**
 * Runs the full automated DSP verification test suite using OfflineAudioContext.
 * Verifies that each musical sculpture mathematically and audibly alters the
 * ACTUAL uploaded audio buffer data, and that original mode is bit-exact.
 */
export async function runAudioPipelineTestSuite(
  sourceBuffer?: AudioBuffer | null
): Promise<AudioTestSuiteReport> {
  const sampleRate = sourceBuffer?.sampleRate || 44100;
  const testDuration = 2.5;
  const totalSamples = Math.floor(sampleRate * testDuration);

  // If no source buffer is loaded, generate our standard reference buffer
  const offlineGen = new OfflineAudioContext(2, totalSamples, sampleRate);
  const baseBuffer = sourceBuffer ? sourceBuffer : createTestAudioBuffer(offlineGen, testDuration, sampleRate);

  const results: AudioTestCaseResult[] = [];

  // ------------------------------------------------------------------
  // Baseline: Render completely unprocessed original audio
  // ------------------------------------------------------------------
  const originalContext = new OfflineAudioContext(2, totalSamples, sampleRate);
  const origSrc = originalContext.createBufferSource();
  origSrc.buffer = baseBuffer;
  origSrc.connect(originalContext.destination);
  origSrc.start(0);
  const originalRenderedBuffer = await originalContext.startRendering();

  // ------------------------------------------------------------------
  // TEST 1: Original Mode Pass-Through
  // ------------------------------------------------------------------
  {
    const dryContext = new OfflineAudioContext(2, totalSamples, sampleRate);
    const drySrc = dryContext.createBufferSource();
    drySrc.buffer = baseBuffer;
    const dryGain = dryContext.createGain();
    dryGain.gain.setValueAtTime(1.0, 0);
    drySrc.connect(dryGain);
    dryGain.connect(dryContext.destination);
    drySrc.start(0);
    const dryRendered = await dryContext.startRendering();

    const diff = computeBufferDifference(originalRenderedBuffer, dryRendered);
    const passed = diff.rmsDifference < 1e-6;

    results.push({
      id: 'test_original_pass_through',
      name: 'Original Mode Pass-Through',
      description: 'Verifies uploaded audio plays bit-accurately without any coloring when in Original mode',
      targetSculpture: 'Original Mode Pass-Through',
      passed,
      sampleCount: diff.sampleCount,
      rmsDifference: diff.rmsDifference,
      maxSampleDelta: diff.maxSampleDelta,
      details: passed
        ? `Pass: Bit-accurate pass-through. RMS difference = ${diff.rmsDifference.toExponential(3)}.`
        : `Fail: Unexpected deviation in dry signal (${diff.rmsDifference}).`,
    });
  }

  // ------------------------------------------------------------------
  // TEST 2: Rhythm Crystal Gain Envelope (Ducking in 250ms window)
  // ------------------------------------------------------------------
  {
    const rhythmContext = new OfflineAudioContext(2, totalSamples, sampleRate);
    const rhythmSrc = rhythmContext.createBufferSource();
    rhythmSrc.buffer = baseBuffer;

    const rhythmGain = rhythmContext.createGain();
    // Default baseline 1.0
    rhythmGain.gain.setValueAtTime(1.0, 0);

    // Apply 250ms ducking envelope at t = 1.0s (representing ducked crystal height 0.0)
    const tStart = 1.0;
    const attack = 0.015;
    const release = 0.025;
    const duration = 0.25;
    const duckGain = RealAudioEngine.rhythmIntensityToGain(0.0, false); // 0.06

    rhythmGain.gain.setValueAtTime(1.0, tStart);
    rhythmGain.gain.linearRampToValueAtTime(duckGain, tStart + attack);
    rhythmGain.gain.setValueAtTime(duckGain, tStart + duration - release);
    rhythmGain.gain.linearRampToValueAtTime(1.0, tStart + duration);

    rhythmSrc.connect(rhythmGain);
    rhythmGain.connect(rhythmContext.destination);
    rhythmSrc.start(0);
    const rhythmRendered = await rhythmContext.startRendering();

    const diff = computeBufferDifference(originalRenderedBuffer, rhythmRendered);
    const passed = diff.rmsDifference > 0.01 && diff.maxSampleDelta > 0.05;

    results.push({
      id: 'test_rhythm_crystal_gain_envelope',
      name: 'Rhythm Crystal Real Audio Gain Envelope',
      description: 'Verifies crystal height directly reshapes the actual recording waveform in its 250ms window',
      targetSculpture: 'Rhythm Crystal',
      passed,
      sampleCount: diff.sampleCount,
      rmsDifference: diff.rmsDifference,
      maxSampleDelta: diff.maxSampleDelta,
      details: passed
        ? `Pass: Verified real waveform modification. RMS Diff = ${diff.rmsDifference.toFixed(4)}, Max Delta = ${diff.maxSampleDelta.toFixed(3)}.`
        : `Fail: Insufficient waveform change in time window (${diff.rmsDifference.toFixed(4)}).`,
    });
  }

  // ------------------------------------------------------------------
  // TEST 3: Bass River Low Shelf EQ (+10 dB boost at 120 Hz)
  // ------------------------------------------------------------------
  {
    const bassContext = new OfflineAudioContext(2, totalSamples, sampleRate);
    const bassSrc = bassContext.createBufferSource();
    bassSrc.buffer = baseBuffer;

    const bassFilter = bassContext.createBiquadFilter();
    bassFilter.type = 'lowshelf';
    bassFilter.frequency.setValueAtTime(120, 0);
    bassFilter.gain.setValueAtTime(RealAudioEngine.bassIntensityToDb(1.0), 0); // +11 dB

    bassSrc.connect(bassFilter);
    bassFilter.connect(bassContext.destination);
    bassSrc.start(0);
    const bassRendered = await bassContext.startRendering();

    const diff = computeBufferDifference(originalRenderedBuffer, bassRendered);
    const passed = diff.rmsDifference > 0.015 && diff.maxSampleDelta > 0.05;

    results.push({
      id: 'test_bass_river_eq',
      name: 'Bass River Low-Shelf Filter (~120 Hz)',
      description: 'Verifies river thickness alters the actual audio low-frequency band without isolating stems',
      targetSculpture: 'Bass River',
      passed,
      sampleCount: diff.sampleCount,
      rmsDifference: diff.rmsDifference,
      maxSampleDelta: diff.maxSampleDelta,
      details: passed
        ? `Pass: Verified low-frequency gain alteration. RMS Diff = ${diff.rmsDifference.toFixed(4)}, Max Delta = ${diff.maxSampleDelta.toFixed(3)}.`
        : `Fail: Bass filter produced insufficient difference (${diff.rmsDifference.toFixed(4)}).`,
    });
  }

  // ------------------------------------------------------------------
  // TEST 4: Energy Core Section Gain & Dynamic Limiting
  // ------------------------------------------------------------------
  {
    const energyContext = new OfflineAudioContext(2, totalSamples, sampleRate);
    const energySrc = energyContext.createBufferSource();
    energySrc.buffer = baseBuffer;

    const energyGain = energyContext.createGain();
    const targetGain = RealAudioEngine.energyLevelToLinearGain(0.15); // 0.54 (-5.3 dB)
    energyGain.gain.setValueAtTime(targetGain, 0);

    const limiter = energyContext.createDynamicsCompressor();
    limiter.threshold.setValueAtTime(-1.5, 0);
    limiter.ratio.setValueAtTime(16, 0);

    energySrc.connect(energyGain);
    energyGain.connect(limiter);
    limiter.connect(energyContext.destination);
    energySrc.start(0);
    const energyRendered = await energyContext.startRendering();

    const diff = computeBufferDifference(originalRenderedBuffer, energyRendered);
    const passed = diff.rmsDifference > 0.02 && diff.maxSampleDelta > 0.05;

    results.push({
      id: 'test_energy_core_gain',
      name: 'Energy Core Section Gain & Limiting',
      description: 'Verifies core resizing automates real audio recording gain with transparent peak limiting',
      targetSculpture: 'Energy Core',
      passed,
      sampleCount: diff.sampleCount,
      rmsDifference: diff.rmsDifference,
      maxSampleDelta: diff.maxSampleDelta,
      details: passed
        ? `Pass: Dynamic level shift confirmed. RMS Diff = ${diff.rmsDifference.toFixed(4)}, Max Delta = ${diff.maxSampleDelta.toFixed(3)}.`
        : `Fail: Gain shift insufficient (${diff.rmsDifference.toFixed(4)}).`,
    });
  }

  // ------------------------------------------------------------------
  // TEST 5: Combined Sculpture Pipeline (Rhythm + Bass + Energy)
  // ------------------------------------------------------------------
  {
    const fullContext = new OfflineAudioContext(2, totalSamples, sampleRate);
    const fullSrc = fullContext.createBufferSource();
    fullSrc.buffer = baseBuffer;

    const rhythmGain = fullContext.createGain();
    rhythmGain.gain.setValueAtTime(1.0, 0);
    // Accentuate crystal at t=0.6s (+5.3 dB)
    rhythmGain.gain.setValueAtTime(1.0, 0.58);
    rhythmGain.gain.linearRampToValueAtTime(1.85, 0.6);
    rhythmGain.gain.setValueAtTime(1.85, 0.78);
    rhythmGain.gain.linearRampToValueAtTime(1.0, 0.81);

    const bassFilter = fullContext.createBiquadFilter();
    bassFilter.type = 'lowshelf';
    bassFilter.frequency.setValueAtTime(120, 0);
    bassFilter.gain.setValueAtTime(8.0, 0); // +8 dB

    const energyGain = fullContext.createGain();
    energyGain.gain.setValueAtTime(1.2, 0);

    const limiter = fullContext.createDynamicsCompressor();
    limiter.threshold.setValueAtTime(-1.5, 0);
    limiter.ratio.setValueAtTime(16, 0);

    fullSrc.connect(rhythmGain);
    rhythmGain.connect(bassFilter);
    bassFilter.connect(energyGain);
    energyGain.connect(limiter);
    limiter.connect(fullContext.destination);
    fullSrc.start(0);

    const fullRendered = await fullContext.startRendering();
    const diff = computeBufferDifference(originalRenderedBuffer, fullRendered);
    const passed = diff.rmsDifference > 0.03 && diff.maxSampleDelta > 0.08;

    results.push({
      id: 'test_combined_dsp_pipeline',
      name: 'Combined Real Audio Sculpture Pipeline',
      description: 'Verifies simultaneous envelope, EQ, and energy automation on the real uploaded audio signal',
      targetSculpture: 'Combined World',
      passed,
      sampleCount: diff.sampleCount,
      rmsDifference: diff.rmsDifference,
      maxSampleDelta: diff.maxSampleDelta,
      details: passed
        ? `Pass: Synergistic processing verified. RMS Diff = ${diff.rmsDifference.toFixed(4)}, Max Delta = ${diff.maxSampleDelta.toFixed(3)}.`
        : `Fail: Combined pipeline produced insufficient difference (${diff.rmsDifference.toFixed(4)}).`,
    });
  }

  const passedCount = results.filter((r) => r.passed).length;
  const allPassed = passedCount === results.length;

  return {
    timestamp: new Date().toISOString(),
    allPassed,
    testsPassed: passedCount,
    testsTotal: results.length,
    results,
    verdict: allPassed
      ? 'All 5 automated OfflineAudioContext tests PASSED. SoundShape directly and audibly reshapes the ACTUAL uploaded MP3 recording samples.'
      : 'One or more audio tests failed.',
  };
}
