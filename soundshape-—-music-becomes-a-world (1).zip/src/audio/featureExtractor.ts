import { AudioAnalysisResult, FeatureWindow } from '../types/world';

/**
 * Extracts measurable, deterministic audio features from a decoded AudioBuffer.
 * Evaluates RMS energy, sub/low (20-250Hz), mid (250-2500Hz), high (2500-12000Hz),
 * and onset strength over ~100-180 time windows.
 */
export function extractAudioFeatures(audioBuffer: AudioBuffer): AudioAnalysisResult {
  const duration = audioBuffer.duration;
  const sampleRate = audioBuffer.sampleRate;
  const channelData = audioBuffer.getChannelData(0); // Use primary channel
  const totalSamples = channelData.length;

  // Determine window count: targeting ~120 to 180 windows (approx 100-200ms per window)
  const windowCount = Math.min(180, Math.max(90, Math.floor(duration * 6)));
  const windowSize = Math.floor(totalSamples / windowCount);
  const windows: FeatureWindow[] = [];

  let sumRms = 0;
  let maxRms = 0;
  let previousWindowEnergies: number[] = [];

  // Filter band helpers using simplified discrete bandpass filters
  for (let w = 0; w < windowCount; w++) {
    const startSample = w * windowSize;
    const endSample = Math.min(startSample + windowSize, totalSamples);
    const time = (startSample / totalSamples) * duration;

    let sumSquare = 0;
    let lowEnergy = 0;
    let midEnergy = 0;
    let highEnergy = 0;

    // Subsampling step inside window for high performance
    const step = Math.max(1, Math.floor((endSample - startSample) / 1024));

    let prevSample = 0;
    let prevLow = 0;

    for (let i = startSample; i < endSample; i += step) {
      const sample = channelData[i];
      sumSquare += sample * sample;

      // Low pass approximation (~250Hz cutoff)
      const alphaLow = 0.05;
      const lowVal = prevLow + alphaLow * (sample - prevLow);
      prevLow = lowVal;
      lowEnergy += lowVal * lowVal;

      // High pass approximation (difference with previous sample)
      const highVal = sample - prevSample;
      prevSample = sample;
      highEnergy += highVal * highVal;
    }

    const count = Math.ceil((endSample - startSample) / step);
    const rms = Math.sqrt(sumSquare / count);
    const lowNorm = Math.sqrt(lowEnergy / count);
    const highNorm = Math.sqrt(highEnergy / count);
    // Mid energy is remainder of energy
    const midNorm = Math.max(0, rms - (lowNorm * 0.5 + highNorm * 0.5));

    sumRms += rms;
    if (rms > maxRms) maxRms = rms;

    // Spectral flux / onset detection
    let onset = 0;
    if (previousWindowEnergies.length > 0) {
      const prevRms = previousWindowEnergies[previousWindowEnergies.length - 1];
      const diff = rms - prevRms;
      if (diff > 0) {
        onset = Math.min(1, diff * 6);
      }
    }
    previousWindowEnergies.push(rms);

    windows.push({
      time,
      rms: Math.min(1, rms * 2.2), // Normalized for 0-1 range
      low: Math.min(1, lowNorm * 2.5),
      mid: Math.min(1, midNorm * 2.5),
      high: Math.min(1, highNorm * 3.0),
      onset,
    });
  }

  const averageRms = sumRms / windowCount;

  // Simple tempo estimate via rhythmic onset autocorrelation
  let detectedBpm = 120;
  const onsets = windows.map((w) => w.onset);
  const minLag = Math.floor((60 / 180) * (windowCount / duration)); // 180 BPM
  const maxLag = Math.floor((60 / 70) * (windowCount / duration));  // 70 BPM

  let bestLag = minLag;
  let maxCorr = -1;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let corr = 0;
    for (let i = 0; i < onsets.length - lag; i++) {
      corr += onsets[i] * onsets[i + lag];
    }
    if (corr > maxCorr) {
      maxCorr = corr;
      bestLag = lag;
    }
  }

  const windowDuration = duration / windowCount;
  const beatInterval = bestLag * windowDuration;
  if (beatInterval > 0) {
    const rawBpm = Math.round(60 / beatInterval);
    if (rawBpm >= 70 && rawBpm <= 175) {
      detectedBpm = rawBpm;
    }
  }

  // Segment into 2 to 4 coherent musical sections
  // For clips under 20s, 2 or 3 sections. For 20-40s, 3 sections. For >40s, 4 sections.
  let sectionCount = 3;
  if (duration < 16) sectionCount = 2;
  else if (duration > 42) sectionCount = 4;

  const sectionDuration = duration / sectionCount;
  const detectedSections = [];

  const sectionLabels = [
    ['Intro / Opening', 'Climax / Release'],
    ['Opening', 'Build & Groove', 'Climax Peak'],
    ['Intro Ambient', 'Rhythmic Build', 'Main Climax', 'Outro Reflection'],
  ][sectionCount - 2] || ['Section 1', 'Section 2', 'Section 3'];

  for (let s = 0; s < sectionCount; s++) {
    const start = s * sectionDuration;
    const end = (s + 1) * sectionDuration;

    // Compute section stats from windows within this range
    const sectionWindows = windows.filter((w) => w.time >= start && w.time < end);
    let secRms = 0;
    let secLow = 0;
    let secMid = 0;
    let secHigh = 0;

    sectionWindows.forEach((w) => {
      secRms += w.rms;
      secLow += w.low;
      secMid += w.mid;
      secHigh += w.high;
    });

    const wCount = Math.max(1, sectionWindows.length);
    const avgSecRms = secRms / wCount;
    const avgLow = secLow / wCount;
    const avgMid = secMid / wCount;
    const avgHigh = secHigh / wCount;
    const totalFreq = Math.max(0.01, avgLow + avgMid + avgHigh);

    detectedSections.push({
      start: Math.round(start * 10) / 10,
      end: Math.round(end * 10) / 10,
      label: sectionLabels[s] || `Section ${s + 1}`,
      energy: Math.min(1, Math.max(0.15, Math.round(avgSecRms * 100) / 100)),
      lowRatio: Math.round((avgLow / totalFreq) * 100) / 100,
      midRatio: Math.round((avgMid / totalFreq) * 100) / 100,
      highRatio: Math.round((avgHigh / totalFreq) * 100) / 100,
    });
  }

  return {
    duration: Math.round(duration * 10) / 10,
    sampleRate,
    tempoEstimate: detectedBpm,
    averageRms: Math.round(averageRms * 100) / 100,
    peakRms: Math.round(maxRms * 100) / 100,
    windows,
    detectedSections,
  };
}
