import { z } from 'zod';

export type WorldTheme =
  | 'dreamy_ocean'
  | 'crystal_canyon'
  | 'cyber_city'
  | 'emotional_lake'
  | 'floating_islands'
  | 'deep_abyss'
  | 'fractured_realm'
  | 'organic_forest';

export type ObjectType =
  | 'rhythm_towers'
  | 'bass_river'
  | 'energy_core'
  | 'melody_ribbon'
  | 'atmosphere_particles'
  | 'silence_gap';

export type DrumSoundType = 'kick' | 'snare' | 'hihat';

export interface RhythmStep {
  index: number;
  timeRatio: number; // 0 to 1 within section
  intensity: number; // 0 to 1 (velocity)
  active: boolean;
  type: DrumSoundType;
  // Musical-time mapping metadata
  objectId?: string;
  sectionId?: string;
  eventTimeSeconds?: number;
  timeRange?: string;
  instrumentType?: string;
  sourceFeatureType?: string;
  sourceFeatureValue?: number;
  originalParameter?: number;
  editedParameter?: number;
  isActive?: boolean;
}

export interface SceneObject {
  id: string;
  type: ObjectType;
  editable: boolean;
  name: string;
  description: string;
  rhythmSteps?: RhythmStep[];
  bassIntensity?: number; // 0 to 1
  energyLevel?: number; // 0 to 1
  color?: string;
}

export type SpatialArrangement =
  | 'linear_archipelago'
  | 'crescent_bay'
  | 'orbital_cluster'
  | 'fractured_spire';

export type FootprintShape =
  | 'organic_atoll'
  | 'terraced_hex'
  | 'fractured_polygon'
  | 'elongated_ridge'
  | 'crescent_bay';

export type ElevationProfile =
  | 'smooth_basin'
  | 'terraced_steps'
  | 'jagged_peaks'
  | 'chasm_canyon'
  | 'soaring_monolith';

export type LandmarkType =
  | 'suspended_crystals'
  | 'viaduct_colonnade'
  | 'geode_monoliths'
  | 'glass_pyramid'
  | 'orbital_rings'
  | 'crystalline_arch';

export type PathStyle =
  | 'flowing_curve'
  | 'geometric_bridge'
  | 'fractured_stepping_stones';

export type RiverStyle =
  | 'meandering_canal'
  | 'tiered_aqueduct'
  | 'braided_chasm';

export interface SectionGeometryParams {
  terrainArchetype: 'glass_sanctuary' | 'rhythm_city' | 'crystal_canyon';
  footprintShape: FootprintShape;
  footprintRadiusX: number; // 6.0 to 18.0
  footprintRadiusZ: number; // 5.0 to 16.0
  terrainRoughness: number; // 0.05 to 0.95
  elevationProfile: ElevationProfile;
  elevationAmplitude: number; // 1.0 to 12.0
  peakCount: number; // 0 to 9
  landmarkType: LandmarkType;
  landmarkScale: number; // 0.5 to 2.5
  structuralDensity: number; // 0.2 to 1.0
  pathStyle: PathStyle;
  riverStyle: RiverStyle;
}

export interface SceneSection {
  id: string;
  start: number; // in seconds
  end: number;   // in seconds
  label: string;
  energy: number; // 0 to 1
  mood: string;
  landscapeType:
    | 'glass_island'
    | 'rising_crystals'
    | 'crystal_peak'
    | 'cyber_grid'
    | 'floating_plateau'
    | 'neon_spires'
    | 'abyss_trench';
  dominantColor: string;
  accentColor: string;
  objects: SceneObject[];
  geometryParams?: SectionGeometryParams;
}

export interface VerificationCheck {
  id: string;
  name: string;
  category: 'continuity' | 'sculptures' | 'rhythm' | 'archetypes' | 'dsp';
  passed: boolean;
  details: string;
  repaired?: boolean;
}

export interface SceneVerificationReport {
  verifiedBy: string;
  allPassed: boolean;
  timestamp: string;
  checks: VerificationCheck[];
  repairsApplied: string[];
  geminiRepairCalled?: boolean;
  geminiRepairSucceeded?: boolean;
  localCorrectionsApplied?: string[];
  diagnostics?: string[];
}

export interface WorldScene {
  duration: number;
  worldTheme: WorldTheme;
  spatialArrangement: SpatialArrangement;
  overallMood: string;
  globalPalette: string[];
  terrainRoughness: number;
  lightingAtmosphere: string;
  sections: SceneSection[];
  creativeRationale: string;
  verificationReport?: SceneVerificationReport;
}

// Zod validation schemas
export const RhythmStepSchema = z.object({
  index: z.number().int().min(0).max(31),
  timeRatio: z.number().min(0).max(1),
  intensity: z.number().min(0).max(1),
  active: z.boolean(),
  type: z.enum(['kick', 'snare', 'hihat']),
  objectId: z.string().optional(),
  sectionId: z.string().optional(),
  eventTimeSeconds: z.number().optional(),
  timeRange: z.string().optional(),
  instrumentType: z.string().optional(),
  sourceFeatureType: z.string().optional(),
  sourceFeatureValue: z.number().optional(),
  originalParameter: z.number().optional(),
  editedParameter: z.number().optional(),
  isActive: z.boolean().optional(),
});

export const SceneObjectSchema = z.object({
  id: z.string(),
  type: z.enum([
    'rhythm_towers',
    'bass_river',
    'energy_core',
    'melody_ribbon',
    'atmosphere_particles',
    'silence_gap',
  ]),
  editable: z.boolean(),
  name: z.string(),
  description: z.string(),
  rhythmSteps: z.array(RhythmStepSchema).optional(),
  bassIntensity: z.number().min(0).max(1).optional(),
  energyLevel: z.number().min(0).max(1).optional(),
  color: z.string().optional(),
});

export const SectionGeometryParamsSchema = z.object({
  terrainArchetype: z.enum(['glass_sanctuary', 'rhythm_city', 'crystal_canyon']),
  footprintShape: z.enum([
    'organic_atoll',
    'terraced_hex',
    'fractured_polygon',
    'elongated_ridge',
    'crescent_bay',
  ]),
  footprintRadiusX: z.number().min(4).max(30),
  footprintRadiusZ: z.number().min(4).max(30),
  terrainRoughness: z.number().min(0).max(1),
  elevationProfile: z.enum([
    'smooth_basin',
    'terraced_steps',
    'jagged_peaks',
    'chasm_canyon',
    'soaring_monolith',
  ]),
  elevationAmplitude: z.number().min(0.5).max(20),
  peakCount: z.number().min(0).max(16),
  landmarkType: z.enum([
    'suspended_crystals',
    'viaduct_colonnade',
    'geode_monoliths',
    'glass_pyramid',
    'orbital_rings',
    'crystalline_arch',
  ]),
  landmarkScale: z.number().min(0.2).max(4),
  structuralDensity: z.number().min(0.1).max(1),
  pathStyle: z.enum(['flowing_curve', 'geometric_bridge', 'fractured_stepping_stones']),
  riverStyle: z.enum(['meandering_canal', 'tiered_aqueduct', 'braided_chasm']),
});

export const SceneSectionSchema = z.object({
  id: z.string(),
  start: z.number().min(0),
  end: z.number().min(0),
  label: z.string(),
  energy: z.number().min(0).max(1),
  mood: z.string(),
  landscapeType: z.enum([
    'glass_island',
    'rising_crystals',
    'crystal_peak',
    'cyber_grid',
    'floating_plateau',
    'neon_spires',
    'abyss_trench',
  ]),
  dominantColor: z.string(),
  accentColor: z.string(),
  objects: z.array(SceneObjectSchema),
  geometryParams: SectionGeometryParamsSchema.optional(),
});

export const VerificationCheckSchema = z.object({
  id: z.string(),
  name: z.string(),
  category: z.enum(['continuity', 'sculptures', 'rhythm', 'archetypes', 'dsp']),
  passed: z.boolean(),
  details: z.string(),
  repaired: z.boolean().optional(),
});

export const SceneVerificationReportSchema = z.object({
  verifiedBy: z.string(),
  allPassed: z.boolean(),
  timestamp: z.string(),
  checks: z.array(VerificationCheckSchema),
  repairsApplied: z.array(z.string()),
  geminiRepairCalled: z.boolean().optional(),
  geminiRepairSucceeded: z.boolean().optional(),
  localCorrectionsApplied: z.array(z.string()).optional(),
  diagnostics: z.array(z.string()).optional(),
});

export const WorldSceneSchema = z.object({
  duration: z.number().min(1).max(300),
  worldTheme: z.enum([
    'dreamy_ocean',
    'crystal_canyon',
    'cyber_city',
    'emotional_lake',
    'floating_islands',
    'deep_abyss',
    'fractured_realm',
    'organic_forest',
  ]),
  spatialArrangement: z
    .enum(['linear_archipelago', 'crescent_bay', 'orbital_cluster', 'fractured_spire'])
    .default('linear_archipelago'),
  overallMood: z.string(),
  globalPalette: z.array(z.string()).min(2),
  terrainRoughness: z.number().min(0).max(1),
  lightingAtmosphere: z.string(),
  sections: z.array(SceneSectionSchema).min(1).max(12),
  creativeRationale: z.string(),
  verificationReport: SceneVerificationReportSchema.optional(),
});

// Audio Analysis Types
export interface FeatureWindow {
  time: number;
  rms: number;
  low: number;
  mid: number;
  high: number;
  onset: number;
}

export interface AudioAnalysisResult {
  duration: number;
  sampleRate: number;
  tempoEstimate: number;
  averageRms: number;
  peakRms: number;
  windows: FeatureWindow[];
  detectedSections: {
    start: number;
    end: number;
    label: string;
    energy: number;
    lowRatio: number;
    midRatio: number;
  }[];
}

// User Edit State
export type MusicalLayerType = 'energy' | 'bass' | 'treble' | 'texture' | 'pitch' | 'timing';
export type EditScope = 'moment' | 'section';

export interface MultiLayerEdit {
  editId: string;
  sectionId: string;
  scope: EditScope;
  startTime: number;
  endTime: number;
  layer: MusicalLayerType;
  property: string;
  originalValue: number;
  editedValue: number;
  unit: string;
  enabled: boolean;
}

export interface LayerConfig {
  id: MusicalLayerType;
  label: string;
  color: string;
  description: string;
  property: string;
  unit: string;
  minValue: number;
  maxValue: number;
  defaultValue: number;
  step: number;
}

export const LAYER_CONFIGS: Record<MusicalLayerType, LayerConfig> = {
  energy: {
    id: 'energy',
    label: 'Energy',
    color: '#A58BFA',
    description: 'Overall loudness & section dynamic amplitude with transparent studio peak limiter',
    property: 'Loudness Gain',
    unit: 'dB',
    minValue: -18,
    maxValue: 6,
    defaultValue: 0,
    step: 0.5,
  },
  bass: {
    id: 'bass',
    label: 'Bass',
    color: '#FF9E40',
    description: 'Low-frequency sub and bass foundation filter (~120 Hz) on original recording',
    property: 'Low-Shelf EQ',
    unit: 'dB',
    minValue: -12,
    maxValue: 12,
    defaultValue: 0,
    step: 0.5,
  },
  treble: {
    id: 'treble',
    label: 'Treble',
    color: '#62D5E8',
    description: 'High-frequency air and brightness shelf filter (~6 kHz) on original recording',
    property: 'High-Shelf EQ',
    unit: 'dB',
    minValue: -12,
    maxValue: 12,
    defaultValue: 0,
    step: 0.5,
  },
  texture: {
    id: 'texture',
    label: 'Texture',
    color: '#34D399',
    description: 'Tonal coloration and warm filtering of the original audio spectrum',
    property: 'Filter Cutoff',
    unit: 'Hz',
    minValue: 400,
    maxValue: 12000,
    defaultValue: 12000,
    step: 100,
  },
  pitch: {
    id: 'pitch',
    label: 'Pitch',
    color: '#F472B6',
    description: 'Chromatic pitch alteration via smooth varispeed rate modulation',
    property: 'Pitch Shift',
    unit: 'st',
    minValue: -6,
    maxValue: 6,
    defaultValue: 0,
    step: 1,
  },
  timing: {
    id: 'timing',
    label: 'Timing',
    color: '#FBBF24',
    description: 'Local playback rate and tempo speed modification of the original recording',
    property: 'Playback Speed',
    unit: 'x',
    minValue: 0.75,
    maxValue: 1.25,
    defaultValue: 1.0,
    step: 0.05,
  },
};

export interface SectionEditState {
  rhythmSteps: RhythmStep[];
  rhythmDensity: number; // 0 to 1
  bassIntensity: number; // 0 to 1
  energyLevel: number; // 0 to 1
  layerEdits?: MultiLayerEdit[];
}

export type WorldEditState = Record<string, SectionEditState>;

export type ViewMode = 'world' | 'section' | 'element';

export type AIAnalysisStatus =
  | 'idle'
  | 'decoding'
  | 'extracting_features'
  | 'requesting_gemini'
  | 'validating_scene'
  | 'building_world'
  | 'gemini_complete'
  | 'local_only'
  | 'gemini_failed';
