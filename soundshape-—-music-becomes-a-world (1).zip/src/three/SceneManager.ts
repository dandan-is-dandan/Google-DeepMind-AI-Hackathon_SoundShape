import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { LAYER_CONFIGS, MusicalLayerType, ViewMode, WorldEditState, WorldScene } from '../types/world';
import { buildWorldLandscape, GeneratedWorld } from './islandGenerator';
import {
  RhythmTowerMeshGroup,
  setTowerPlaybackGlow,
  updateBassRiverThickness,
  updateEnergyCoreScale,
  updateRhythmTowerHeight,
} from './sculptures';
import { formatTimestamp } from '../audio/metadataEnricher';

export type SelectedSculptureType = 'rhythm_tower' | 'bass_river' | 'energy_core';

export interface SculptureHoverInfo {
  title: string;
  sectionName?: string;
  timestamp?: string;
  role?: string;
  editEffect?: string;
  subtitle?: string;
  sound?: string;
  actionHint: string;
  screenX: number;
  screenY: number;
  type: 'rhythm_crystal' | 'bass_river' | 'energy_core' | 'island' | 'decorative';
  sectionId?: string;
  stepIndex?: number;
}

export interface IslandScreenPosition {
  sectionId: string;
  label: string;
  start: number;
  end: number;
  energy: number;
  mood: string;
  archetype?: string;
  screenX: number;
  screenY: number;
  visible: boolean;
}

export interface SceneManagerCallbacks {
  onSelectSection: (sectionId: string) => void;
  onSelectElement: (sectionId: string, stepIndex: number) => void;
  onSelectSculpture?: (sectionId: string, type: SelectedSculptureType) => void;
  onTowerIntensityChange: (sectionId: string, stepIndex: number, intensity: number) => void;
  onBassIntensityChange?: (sectionId: string, intensity: number) => void;
  onEnergyLevelChange?: (sectionId: string, energy: number) => void;
  onHoverSculpture?: (hoverInfo: SculptureHoverInfo | null) => void;
  onViewModeChange?: (mode: ViewMode) => void;
}

export class SoundShapeSceneManager {
  private container: HTMLElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private controls: OrbitControls;
  private generatedWorld: GeneratedWorld | null = null;
  private currentSceneData: WorldScene | null = null;

  // View state tracking to prevent repeated or conflicting transitions
  private viewMode: ViewMode = 'world';
  private selectedSectionId: string | null = null;
  private selectedStepIndex: number | null = null;
  private interactionMode: 'explore' | 'edit' = 'explore';
  private activeLayer: MusicalLayerType = 'energy';
  private timeBeacon: THREE.Group | null = null;

  // Camera transition state
  private isTransitioning = false;
  private targetCamPos = new THREE.Vector3(0, 28, 48);
  private targetCamLookAt = new THREE.Vector3(0, 1.5, 0);

  // User interaction flags
  private isUserInteracting = false;
  private isDraggingHandle = false;
  private dragHandleType: 'rhythm' | 'bass' | 'energy' | null = null;
  private draggedTower: RhythmTowerMeshGroup | null = null;
  private draggedRiverGroup: THREE.Group | null = null;
  private draggedCoreGroup: THREE.Group | null = null;
  private draggedSectionId: string | null = null;
  private dragStartY = 0;
  private dragStartVal = 0;
  private pointerDownPos = { x: 0, y: 0 };

  // Playback sync
  private playbackTime = 0;
  private playbackDuration = 24;
  private isPlaying = false;
  private isEditedMode = true;
  private followMusicMode = false;

  // Raycasting
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2(-999, -999);
  private lastClientPos = { x: 0, y: 0 };

  // Animation frame
  private animId = 0;
  private clock = new THREE.Clock();
  private callbacks: SceneManagerCallbacks;

  constructor(container: HTMLElement, callbacks: SceneManagerCallbacks) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0B1020');
    this.scene.fog = new THREE.FogExp2('#0B1020', 0.009);

    // 2. Camera setup
    const aspect = container.clientWidth / container.clientHeight || 1;
    this.camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 800);
    this.camera.position.set(0, 28, 48);

    // 3. Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 4. Lighting & Environment
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    const hemiLight = new THREE.HemisphereLight('#62D5E8', '#0B1020', 0.8);
    this.scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight('#FFFFFF', 2.0);
    dirLight.position.set(25, 45, 25);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 160;
    const shadowD = 45;
    dirLight.shadow.camera.left = -shadowD;
    dirLight.shadow.camera.right = shadowD;
    dirLight.shadow.camera.top = shadowD;
    dirLight.shadow.camera.bottom = -shadowD;
    dirLight.shadow.bias = -0.0005;
    this.scene.add(dirLight);

    const ambientLight = new THREE.AmbientLight('#1E293B', 0.9);
    this.scene.add(ambientLight);

    // 5. Orbit Controls setup
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.03; // Prevent dipping beneath floor
    this.controls.minDistance = 6;
    this.controls.maxDistance = 350;

    // Detect user manual interaction: immediately cancel any active transition
    this.controls.addEventListener('start', () => {
      this.isUserInteracting = true;
      this.isTransitioning = false; // User took manual control
    });
    this.controls.addEventListener('end', () => {
      this.isUserInteracting = false;
    });

    // Cancel transition when user wheels/zooms
    this.renderer.domElement.addEventListener(
      'wheel',
      () => {
        this.isTransitioning = false;
      },
      { passive: true }
    );

    // Bind event listeners
    this.bindEvents();

    // Start render loop
    this.animate = this.animate.bind(this);
    this.animId = requestAnimationFrame(this.animate);
  }

  private bindEvents() {
    const dom = this.renderer.domElement;
    dom.addEventListener('pointermove', this.onPointerMove);
    dom.addEventListener('pointerdown', this.onPointerDown);
    dom.addEventListener('pointerup', this.onPointerUp);
    dom.addEventListener('pointercancel', this.onPointerUp);
    dom.addEventListener('pointerleave', this.onPointerLeave);
    window.addEventListener('resize', this.onWindowResize);
  }

  public setWorldScene(scene: WorldScene, editState?: WorldEditState) {
    this.currentSceneData = scene;
    this.playbackDuration = scene.duration;

    // Remove previous world if exists
    if (this.generatedWorld) {
      this.scene.remove(this.generatedWorld.rootGroup);
    }

    // Build new procedural landscape
    this.generatedWorld = buildWorldLandscape(scene);
    this.scene.add(this.generatedWorld.rootGroup);

    // Apply any initial edit state
    if (editState) {
      this.syncEditState(editState);
    }

    // Apply interaction mode handle visibility
    this.applyInteractionMode();

    // Warm up shaders
    this.renderer.compile(this.scene, this.camera);

    // Set initial camera view to frame entire world
    this.setViewMode('world', undefined, undefined, true);
  }

  public syncEditState(editState: WorldEditState) {
    if (!this.generatedWorld) return;

    this.generatedWorld.islands.forEach((island) => {
      const secEdit = editState[island.sectionId];
      if (!secEdit) return;

      // Sync rhythm towers with visual edited aura markers
      island.rhythmTowers.forEach((tower) => {
        const step = secEdit.rhythmSteps.find((s) => s.index === tower.userData.stepIndex);
        if (step) {
          const isEdited =
            Math.abs(step.intensity - tower.userData.originalParameter) > 0.02 ||
            !step.active;
          updateRhythmTowerHeight(tower, step.intensity, step.active, isEdited);
        }
      });

      // Sync bass river
      if (island.bassRiverGroup && secEdit.bassIntensity !== undefined) {
        updateBassRiverThickness(island.bassRiverGroup, secEdit.bassIntensity);
      }

      // Sync energy core
      if (island.energyCoreGroup && secEdit.energyLevel !== undefined) {
        updateEnergyCoreScale(island.energyCoreGroup, secEdit.energyLevel);
      }
    });
  }

  public setInteractionMode(mode: 'explore' | 'edit') {
    this.interactionMode = mode;
    this.applyInteractionMode();
  }

  public setActiveLayer(layer: MusicalLayerType) {
    this.activeLayer = layer;
    this.applyInteractionMode();
    this.applyLayerVisualFocus();
  }

  public setSelectedTimestamp(timeSeconds: number | null, layer: MusicalLayerType = 'energy') {
    if (!this.generatedWorld) return;

    if (timeSeconds === null || timeSeconds < 0) {
      if (this.timeBeacon) {
        this.timeBeacon.visible = false;
      }
      return;
    }

    if (!this.timeBeacon) {
      this.timeBeacon = new THREE.Group();
      this.timeBeacon.name = 'timeBeacon';

      // Vertical holographic light beam
      const beamGeo = new THREE.CylinderGeometry(0.08, 0.2, 7, 8);
      beamGeo.translate(0, 3.5, 0);
      const beamMat = new THREE.MeshBasicMaterial({
        color: '#62D5E8',
        transparent: true,
        opacity: 0.65,
        blending: THREE.AdditiveBlending,
      });
      const beamMesh = new THREE.Mesh(beamGeo, beamMat);
      beamMesh.name = 'beaconBeam';
      this.timeBeacon.add(beamMesh);

      // Floating diamond apex
      const apexGeo = new THREE.OctahedronGeometry(0.35, 0);
      const apexMat = new THREE.MeshStandardMaterial({
        color: '#FFFFFF',
        emissive: new THREE.Color('#62D5E8'),
        roughness: 0.1,
        metalness: 0.8,
      });
      const apexMesh = new THREE.Mesh(apexGeo, apexMat);
      apexMesh.position.y = 7.2;
      apexMesh.name = 'beaconApex';
      this.timeBeacon.add(apexMesh);

      this.scene.add(this.timeBeacon);
    }

    // Determine spatial position along chronological island layout
    const duration = this.playbackDuration || 30;
    const progress = Math.max(0, Math.min(1, timeSeconds / duration));
    const targetPos = this.generatedWorld.islandPathCurve.getPoint(progress);

    this.timeBeacon.position.set(targetPos.x, targetPos.y + 0.5, targetPos.z);
    this.timeBeacon.visible = true;

    // Update color to match active layer
    const beam = this.timeBeacon.getObjectByName('beaconBeam') as THREE.Mesh;
    const apex = this.timeBeacon.getObjectByName('beaconApex') as THREE.Mesh;
    const colorHex = LAYER_CONFIGS[layer]?.color || '#62D5E8';

    if (beam && beam.material instanceof THREE.MeshBasicMaterial) {
      beam.material.color.set(colorHex);
    }
    if (apex && apex.material instanceof THREE.MeshStandardMaterial) {
      apex.material.emissive.set(colorHex);
    }
  }

  private applyInteractionMode() {
    if (!this.generatedWorld) return;

    const isEdit = this.interactionMode === 'edit';

    this.generatedWorld.rootGroup.traverse((child) => {
      if (child.userData?.isDragHandle) {
        if (!isEdit) {
          child.visible = false;
        } else {
          // Display ONLY the currently selected layer's editable handles (Prompt 4, Req 2)
          if (this.activeLayer === 'energy') {
            child.visible = !!child.userData.isEnergyHandle;
          } else if (this.activeLayer === 'bass') {
            child.visible = !!child.userData.isBassHandle;
          } else if (this.activeLayer === 'treble') {
            child.visible = !!child.userData.isRhythmHandle;
          } else {
            child.visible = true;
          }
        }
      }
      if (child.userData?.isDecorative) {
        const mesh = child as THREE.Mesh;
        if (mesh.material && 'opacity' in mesh.material) {
          (mesh.material as THREE.Material).opacity = isEdit ? 0.35 : 0.85;
          mesh.material.transparent = true;
        }
      }
    });
  }

  private applyLayerVisualFocus() {
    if (!this.generatedWorld) return;

    this.generatedWorld.islands.forEach((island) => {
      // 1. Energy Core highlight when energy layer is selected
      if (island.energyCoreGroup) {
        const coreBody = island.energyCoreGroup.getObjectByName('coreBody') as THREE.Mesh;
        if (coreBody && coreBody.material instanceof THREE.MeshPhysicalMaterial) {
          if (this.activeLayer === 'energy') {
            coreBody.material.emissive.set(new THREE.Color('#A58BFA').multiplyScalar(1.2));
            island.energyCoreGroup.scale.set(1.15, 1.15, 1.15);
          } else {
            coreBody.material.emissive.set(new THREE.Color('#A58BFA').multiplyScalar(0.5));
            island.energyCoreGroup.scale.set(1.0, 1.0, 1.0);
          }
        }
      }

      // 2. Bass River highlight when bass layer is selected
      if (island.bassRiverGroup) {
        const tubeMesh = island.bassRiverGroup.getObjectByName('riverTube') as THREE.Mesh;
        if (tubeMesh && tubeMesh.material instanceof THREE.MeshPhysicalMaterial) {
          if (this.activeLayer === 'bass') {
            tubeMesh.material.emissive.set(new THREE.Color('#FF9E40').multiplyScalar(1.1));
          } else {
            tubeMesh.material.emissive.set(new THREE.Color('#FF9E40').multiplyScalar(0.4));
          }
        }
      }

      // 3. Rhythm Crystal highlight when treble layer is selected
      island.rhythmTowers.forEach((tower) => {
        const cap = tower.getObjectByName('capMesh') as THREE.Mesh;
        if (cap && cap.material instanceof THREE.MeshBasicMaterial) {
          if (this.activeLayer === 'treble') {
            cap.material.color.set('#62D5E8');
          }
        }
      });
    });
  }

  /**
   * Sets View Mode (world, section, element) and initiates a one-time camera transition.
   */
  public setViewMode(
    mode: ViewMode,
    sectionId?: string,
    stepIndex?: number,
    force = false
  ) {
    const isSame =
      this.viewMode === mode &&
      this.selectedSectionId === (sectionId ?? null) &&
      this.selectedStepIndex === (stepIndex ?? null);

    if (isSame && !force) {
      return; // Do not interrupt user's manual camera zoom/orbit!
    }

    this.viewMode = mode;
    this.selectedSectionId = sectionId ?? null;
    this.selectedStepIndex = stepIndex ?? null;

    if (!this.generatedWorld || this.generatedWorld.islands.length === 0) {
      return;
    }

    if (mode === 'world') {
      // Calculate bounding center of all islands
      const center = new THREE.Vector3();
      this.generatedWorld.islands.forEach((isl) => center.add(isl.center));
      center.divideScalar(this.generatedWorld.islands.length);

      const span = this.generatedWorld.islands.length * 28.0;
      const camDist = Math.max(54, span * 0.92);

      this.targetCamLookAt.set(center.x, center.y + 1.2, center.z);
      this.targetCamPos.set(center.x, center.y + camDist * 0.52, center.z + camDist * 0.88);

      this.controls.minDistance = 14;
      this.controls.maxDistance = 400;
      this.isTransitioning = true;
    } else if (mode === 'section' && sectionId) {
      const island = this.generatedWorld.islands.find((isl) => isl.sectionId === sectionId);
      if (island) {
        const c = island.center;
        const rad = island.radius || 9.0;
        this.targetCamLookAt.set(c.x, c.y + 1.4, c.z);
        this.targetCamPos.set(c.x, c.y + rad * 0.95 + 4.5, c.z + rad * 1.5 + 5.0);

        this.controls.minDistance = 6;
        this.controls.maxDistance = 120;
        this.isTransitioning = true;
      }
    } else if (mode === 'element' && sectionId && stepIndex !== undefined && stepIndex !== null) {
      const island = this.generatedWorld.islands.find((isl) => isl.sectionId === sectionId);
      const tower = island?.rhythmTowers.find((t) => t.userData.stepIndex === stepIndex);
      if (tower) {
        const wp = new THREE.Vector3();
        tower.getWorldPosition(wp);
        const towerHeight = tower.userData.targetHeight || 2.0;

        this.targetCamLookAt.set(wp.x, wp.y + towerHeight * 0.5, wp.z);
        this.targetCamPos.set(wp.x + 2.8, wp.y + towerHeight * 0.6 + 2.2, wp.z + 5.2);

        this.controls.minDistance = 2.5;
        this.controls.maxDistance = 45;
        this.isTransitioning = true;
      }
    }
  }

  public fitWorld() {
    this.setViewMode('world', undefined, undefined, true);
  }

  public fitSection() {
    if (this.selectedSectionId) {
      this.setViewMode('section', this.selectedSectionId, undefined, true);
    } else {
      this.fitWorld();
    }
  }

  public fitElement() {
    if (this.selectedSectionId && this.selectedStepIndex !== null) {
      this.setViewMode('element', this.selectedSectionId, this.selectedStepIndex, true);
    } else {
      this.fitSection();
    }
  }

  public fitView() {
    if (this.viewMode === 'element' && this.selectedSectionId && this.selectedStepIndex !== null) {
      this.fitElement();
    } else if (this.viewMode === 'section' && this.selectedSectionId) {
      this.fitSection();
    } else {
      this.fitWorld();
    }
  }

  public resetCamera() {
    this.setViewMode(
      this.viewMode,
      this.selectedSectionId || undefined,
      this.selectedStepIndex ?? undefined,
      true
    );
  }

  public setFollowMusicMode(enabled: boolean) {
    this.followMusicMode = enabled;
  }

  public updatePlayback(
    currentTime: number,
    isPlaying: boolean,
    isEditedMode: boolean,
    followMusicMode = false
  ) {
    this.playbackTime = currentTime;
    this.isPlaying = isPlaying;
    this.isEditedMode = isEditedMode;
    this.followMusicMode = followMusicMode;

    if (!this.generatedWorld || this.playbackDuration <= 0) return;

    const progress = Math.max(0, Math.min(1, currentTime / this.playbackDuration));
    const orbPos = this.generatedWorld.islandPathCurve.getPoint(progress);
    orbPos.y += 1.4 + Math.sin(progress * Math.PI * 8) * 0.3;
    this.generatedWorld.playheadOrb.position.copy(orbPos);

    // Timed highlighting of rhythm towers and active island aura as playhead passes them
    this.generatedWorld.islands.forEach((island) => {
      const secData = island.group.userData.sectionData;
      const isSecActive = secData && currentTime >= secData.start && currentTime <= secData.end;

      const auraMesh = island.group.getObjectByName('activeAura') as THREE.Mesh;
      if (auraMesh && auraMesh.material instanceof THREE.MeshBasicMaterial) {
        auraMesh.material.opacity = isSecActive && isPlaying ? 0.75 : 0.15;
      }

      island.rhythmTowers.forEach((tower) => {
        const timeDiff = Math.abs(currentTime - tower.userData.eventTimeSeconds);
        // Pulse glow when playhead is within 220ms of event timestamp
        const isHit = isPlaying && timeDiff < 0.22;
        setTowerPlaybackGlow(tower, isHit);
      });

      // Animate Bass River using low-frequency energy (Requirement 5)
      if (island.bassRiverGroup) {
        const tubeMesh = island.bassRiverGroup.getObjectByName('riverTube') as THREE.Mesh;
        if (tubeMesh && tubeMesh.material instanceof THREE.MeshPhysicalMaterial) {
          if (isSecActive && isPlaying) {
            const lowPulse = 0.65 + Math.sin(currentTime * 8.0) * 0.28;
            tubeMesh.material.emissive.set(new THREE.Color('#FF9E40').multiplyScalar(lowPulse));
          } else {
            tubeMesh.material.emissive.set(new THREE.Color('#FF9E40').multiplyScalar(0.4));
          }
        }
      }

      // Animate Energy Core using section energy (Requirement 5)
      if (island.energyCoreGroup) {
        const coreBody = island.energyCoreGroup.getObjectByName('coreBody') as THREE.Mesh;
        const r1 = island.energyCoreGroup.getObjectByName('ring1');
        const r2 = island.energyCoreGroup.getObjectByName('ring2');

        if (isSecActive && isPlaying) {
          if (r1) r1.rotation.z += 0.035 * (secData ? secData.energy + 0.5 : 1);
          if (r2) r2.rotation.x += 0.045 * (secData ? secData.energy + 0.5 : 1);
          if (coreBody && coreBody.material instanceof THREE.MeshPhysicalMaterial) {
            const energyPulse = 0.8 + Math.sin(currentTime * 6.0) * 0.3 * (secData ? secData.energy : 0.7);
            coreBody.material.emissive.set(new THREE.Color('#A58BFA').multiplyScalar(energyPulse));
          }
        }
      }
    });

    // Follow-the-music camera behavior (if explicitly enabled)
    if (this.followMusicMode && isPlaying && !this.isUserInteracting && !this.isTransitioning) {
      const activeIsland = this.generatedWorld.islands.find((isl) => {
        const sec = isl.group.userData.sectionData;
        return sec && currentTime >= sec.start && currentTime <= sec.end;
      });

      if (activeIsland && this.viewMode === 'world') {
        const target = new THREE.Vector3(
          activeIsland.center.x,
          activeIsland.center.y + 1.5,
          activeIsland.center.z
        );
        this.controls.target.lerp(target, 0.04);
      }
    }
  }

  public getIslandScreenPositions(): IslandScreenPosition[] {
    if (!this.generatedWorld || !this.container) return [];

    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    const positions: IslandScreenPosition[] = [];

    this.generatedWorld.islands.forEach((island) => {
      const secData = island.group.userData.sectionData;
      if (!secData) return;

      const wp = island.center.clone();
      wp.y += 4.2; // Position label nicely floating above island

      const projected = wp.project(this.camera);

      // Check if in front of camera
      const visible = projected.z < 1.0;
      const screenX = (projected.x * 0.5 + 0.5) * width;
      const screenY = (-(projected.y * 0.5) + 0.5) * height;

      positions.push({
        sectionId: island.sectionId,
        label: secData.label,
        start: secData.start,
        end: secData.end,
        energy: secData.energy,
        mood: secData.mood,
        archetype: island.archetype,
        screenX,
        screenY,
        visible,
      });
    });

    return positions;
  }

  private onPointerMove = (e: PointerEvent) => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    this.lastClientPos = { x: e.clientX, y: e.clientY };

    // Handle 3D vertical dragging on Handles
    if (this.isDraggingHandle) {
      const deltaY = (this.dragStartY - e.clientY) * 0.007;

      if (this.dragHandleType === 'rhythm' && this.draggedTower) {
        const newIntensity = Math.max(0.05, Math.min(1.0, this.dragStartVal + deltaY));
        updateRhythmTowerHeight(this.draggedTower, newIntensity);
        this.callbacks.onTowerIntensityChange(
          this.draggedTower.userData.sectionId,
          this.draggedTower.userData.stepIndex,
          newIntensity
        );
      } else if (this.dragHandleType === 'bass' && this.draggedRiverGroup && this.draggedSectionId) {
        const newIntensity = Math.max(0.05, Math.min(1.0, this.dragStartVal + deltaY));
        updateBassRiverThickness(this.draggedRiverGroup, newIntensity);
        this.callbacks.onBassIntensityChange?.(this.draggedSectionId, newIntensity);
      } else if (this.dragHandleType === 'energy' && this.draggedCoreGroup && this.draggedSectionId) {
        const newEnergy = Math.max(0.05, Math.min(1.0, this.dragStartVal + deltaY));
        updateEnergyCoreScale(this.draggedCoreGroup, newEnergy);
        this.callbacks.onEnergyLevelChange?.(this.draggedSectionId, newEnergy);
      }
      return;
    }

    // Raycast for hover feedback (Requirement 6)
    if (!this.generatedWorld) return;
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const hits = this.raycaster.intersectObjects(this.generatedWorld.rootGroup.children, true);

    if (hits.length === 0) {
      this.callbacks.onHoverSculpture?.(null);
      return;
    }

    for (const hit of hits) {
      let obj: THREE.Object3D | null = hit.object;

      // 1. Check if hovering Rhythm Tower
      while (obj && !obj.userData?.isRhythmTower && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && obj.userData?.isRhythmTower) {
        const tower = obj as RhythmTowerMeshGroup;
        const timeStr = formatTimestamp(tower.userData.eventTimeSeconds);
        const sec = this.currentSceneData?.sections.find((s) => s.id === tower.userData.sectionId);
        const voiceLabel =
          tower.userData.soundType === 'kick'
            ? 'Synth Kick Event'
            : tower.userData.soundType === 'snare'
            ? 'Synth Snare Event'
            : 'Synth Hi-Hat Event';

        this.callbacks.onHoverSculpture?.({
          title: `Rhythm Crystal #${tower.userData.stepIndex + 1}`,
          sectionName: sec?.label,
          timestamp: `Time: ${timeStr} (250ms Window)`,
          role: 'Role: Audio Rhythm Envelope (250ms Window)',
          editEffect: 'Edit effect: Reshapes actual recording gain envelope (+4.5 dB accent to -16 dB duck)',
          actionHint: 'Drag vertically to scale original audio gain in this 250ms slice',
          screenX: e.clientX,
          screenY: e.clientY,
          type: 'rhythm_crystal',
          sectionId: tower.userData.sectionId,
          stepIndex: tower.userData.stepIndex,
        });
        return;
      }

      // 2. Check if hovering Bass River
      obj = hit.object;
      while (obj && !obj.userData?.isBassRiver && !obj.userData?.isBassRiverMesh && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && (obj.userData?.isBassRiver || obj.userData?.isBassRiverMesh)) {
        const secId = obj.userData.sectionId;
        const sec = this.currentSceneData?.sections.find((s) => s.id === secId);
        const timeRangeStr = sec
          ? `Time Range: ${formatTimestamp(sec.start)}–${formatTimestamp(sec.end)}`
          : 'Time Range: 00:00.0–00:10.0';

        this.callbacks.onHoverSculpture?.({
          title: 'Bass River',
          sectionName: sec?.label,
          timestamp: timeRangeStr,
          role: 'Role: Low-Frequency Filter (~120 Hz Low Shelf EQ)',
          editEffect: 'Edit effect: Modifies actual audio bass spectrum (+11 dB boost to -14 dB scoop)',
          actionHint: 'Adjust thickness to boost or cut original audio bass band',
          screenX: e.clientX,
          screenY: e.clientY,
          type: 'bass_river',
          sectionId: secId,
        });
        return;
      }

      // 3. Check if hovering Energy Core
      obj = hit.object;
      while (obj && !obj.userData?.isEnergyCore && !obj.userData?.isEnergyCoreMesh && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && (obj.userData?.isEnergyCore || obj.userData?.isEnergyCoreMesh)) {
        const secId = obj.userData.sectionId;
        const sec = this.currentSceneData?.sections.find((s) => s.id === secId);
        const timeRangeStr = sec
          ? `Time Range: ${formatTimestamp(sec.start)}–${formatTimestamp(sec.end)}`
          : 'Time Range: 00:10.0–00:20.0';

        this.callbacks.onHoverSculpture?.({
          title: 'Energy Core',
          sectionName: sec?.label,
          timestamp: timeRangeStr,
          role: 'Role: Section Dynamic Gain & Transparent Peak Limiter',
          editEffect: 'Edit effect: Automates original recording section volume (+3.8 dB to -9.1 dB)',
          actionHint: 'Resize core to scale recording playback volume with safe limiting',
          screenX: e.clientX,
          screenY: e.clientY,
          type: 'energy_core',
          sectionId: secId,
        });
        return;
      }

      // 4. Check if hovering Decorative element
      obj = hit.object;
      while (obj && !obj.userData?.isDecorative && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && obj.userData?.isDecorative) {
        this.callbacks.onHoverSculpture?.({
          title: obj.userData.name || 'Decorative Metaphor',
          subtitle: obj.userData.role || 'Flowing musical contour',
          actionHint: 'Visual Metaphor (Non-editable)',
          screenX: e.clientX,
          screenY: e.clientY,
          type: 'decorative',
        });
        return;
      }

      // 5. Check if hovering Island
      obj = hit.object;
      while (obj && !obj.userData?.isIsland && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && obj.userData?.isIsland) {
        const sec = obj.userData.sectionData;
        if (sec) {
          this.callbacks.onHoverSculpture?.({
            title: sec.label,
            subtitle: `Interval: ${sec.start.toFixed(1)}s – ${sec.end.toFixed(1)}s (Energy: ${Math.round(sec.energy * 100)}%)`,
            actionHint: 'Click to explore this section',
            screenX: e.clientX,
            screenY: e.clientY,
            type: 'island',
            sectionId: obj.userData.sectionId,
          });
          return;
        }
      }
    }

    this.callbacks.onHoverSculpture?.(null);
  };

  private onPointerLeave = () => {
    this.callbacks.onHoverSculpture?.(null);
  };

  private onPointerDown = (e: PointerEvent) => {
    if (e.button !== 0) return; // Primary left click only

    this.pointerDownPos = { x: e.clientX, y: e.clientY };

    // Stop any active automatic camera transition when clicking anywhere on canvas
    this.isTransitioning = false;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    if (!this.generatedWorld) return;

    // Check if clicked directly on a 3D drag handle
    const hits = this.raycaster.intersectObjects(this.generatedWorld.rootGroup.children, true);
    for (const hit of hits) {
      const obj = hit.object;
      if (obj.userData?.isDragHandle) {
        this.isDraggingHandle = true;
        this.dragStartY = e.clientY;
        this.controls.enabled = false; // Disable orbit during handle drag

        if (obj.userData.isRhythmHandle && obj.userData.parentTower) {
          this.dragHandleType = 'rhythm';
          this.draggedTower = obj.userData.parentTower;
          this.dragStartVal = this.draggedTower?.userData.intensity || 0.5;
          return;
        } else if (obj.userData.isBassHandle && obj.userData.parentRiver) {
          this.dragHandleType = 'bass';
          this.draggedRiverGroup = obj.userData.parentRiver;
          this.draggedSectionId = obj.userData.sectionId;
          this.dragStartVal = this.draggedRiverGroup?.userData.intensity || 0.5;
          return;
        } else if (obj.userData.isEnergyHandle && obj.userData.parentCore) {
          this.dragHandleType = 'energy';
          this.draggedCoreGroup = obj.userData.parentCore;
          this.draggedSectionId = obj.userData.sectionId;
          this.dragStartVal = this.draggedCoreGroup?.userData.energy || 0.5;
          return;
        }
      }
    }
  };

  private onPointerUp = (e: PointerEvent) => {
    if (this.isDraggingHandle) {
      this.isDraggingHandle = false;
      this.dragHandleType = null;
      this.draggedTower = null;
      this.draggedRiverGroup = null;
      this.draggedCoreGroup = null;
      this.draggedSectionId = null;
      this.controls.enabled = true; // Re-enable orbit
      return;
    }

    // Only treat pointerup as a selection CLICK if pointer did not drag/orbit (movement < 5px)
    const moveDist = Math.hypot(
      e.clientX - this.pointerDownPos.x,
      e.clientY - this.pointerDownPos.y
    );
    if (moveDist >= 5) {
      return; // User was orbiting/panning the camera, NOT selecting
    }

    this.raycaster.setFromCamera(this.mouse, this.camera);
    if (!this.generatedWorld) return;

    const hits = this.raycaster.intersectObjects(this.generatedWorld.rootGroup.children, true);
    for (const hit of hits) {
      let obj: THREE.Object3D | null = hit.object;

      // 1. Check if clicked on a Rhythm Tower
      while (obj && !obj.userData?.isRhythmTower && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && obj.userData?.isRhythmTower) {
        const tower = obj as RhythmTowerMeshGroup;
        this.callbacks.onSelectElement(tower.userData.sectionId, tower.userData.stepIndex);
        return;
      }

      // 2. Check if clicked on Bass River
      obj = hit.object;
      while (obj && !obj.userData?.isBassRiver && !obj.userData?.isBassRiverMesh && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && (obj.userData?.isBassRiver || obj.userData?.isBassRiverMesh)) {
        const secId = obj.userData.sectionId;
        if (secId) {
          this.callbacks.onSelectSculpture?.(secId, 'bass_river');
          return;
        }
      }

      // 3. Check if clicked on Energy Core
      obj = hit.object;
      while (obj && !obj.userData?.isEnergyCore && !obj.userData?.isEnergyCoreMesh && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && (obj.userData?.isEnergyCore || obj.userData?.isEnergyCoreMesh)) {
        const secId = obj.userData.sectionId;
        if (secId) {
          this.callbacks.onSelectSculpture?.(secId, 'energy_core');
          return;
        }
      }

      // 4. Check if clicked on an island
      obj = hit.object;
      while (obj && !obj.userData?.isIsland && obj.parent && obj !== this.scene) {
        obj = obj.parent;
      }
      if (obj && obj.userData?.isIsland) {
        this.callbacks.onSelectSection(obj.userData.sectionId);
        return;
      }
    }
  };

  private onWindowResize = () => {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private animate() {
    this.animId = requestAnimationFrame(this.animate);

    const delta = Math.min(0.08, this.clock.getDelta());
    const time = this.clock.getElapsedTime();

    // ONE-TIME Camera transition interpolation (only runs until destination is reached)
    if (this.isTransitioning && !this.isUserInteracting) {
      this.camera.position.lerp(this.targetCamPos, 7.0 * delta);
      this.controls.target.lerp(this.targetCamLookAt, 7.0 * delta);

      const posDist = this.camera.position.distanceTo(this.targetCamPos);
      const lookDist = this.controls.target.distanceTo(this.targetCamLookAt);

      if (posDist < 0.08 && lookDist < 0.08) {
        this.camera.position.copy(this.targetCamPos);
        this.controls.target.copy(this.targetCamLookAt);
        this.isTransitioning = false; // Transition complete: hands off completely to OrbitControls!
      }
    }

    // Gentle ambient animation for non-interactive elements
    if (this.generatedWorld) {
      // Gentle floating of islands
      this.generatedWorld.islands.forEach((isl, idx) => {
        const floatOffset = Math.sin(time * 0.8 + idx * 1.5) * 0.06;
        isl.group.position.y = isl.center.y + floatOffset;

        // Animate suspended crystals & floating fragments
        isl.group.traverse((child) => {
          if (child.userData?.floatSpeed) {
            child.rotation.y += 0.008;
            child.position.y += Math.sin(time * child.userData.floatSpeed + idx) * 0.002;
          }
        });

        // Rotate energy core rings
        if (isl.energyCoreGroup) {
          const r1 = isl.energyCoreGroup.getObjectByName('ring1');
          const r2 = isl.energyCoreGroup.getObjectByName('ring2');
          if (r1) r1.rotation.z += 0.015;
          if (r2) r2.rotation.x += 0.02;
        }
      });

      // Flowing melody ribbon shimmer
      if (this.generatedWorld.melodyRibbon.material instanceof THREE.MeshPhysicalMaterial) {
        this.generatedWorld.melodyRibbon.rotation.x = Math.sin(time * 0.25) * 0.03;
      }
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  public dispose() {
    cancelAnimationFrame(this.animId);
    const dom = this.renderer.domElement;
    dom.removeEventListener('pointermove', this.onPointerMove);
    dom.removeEventListener('pointerdown', this.onPointerDown);
    dom.removeEventListener('pointerup', this.onPointerUp);
    dom.removeEventListener('pointercancel', this.onPointerUp);
    dom.removeEventListener('pointerleave', this.onPointerLeave);
    window.removeEventListener('resize', this.onWindowResize);

    this.controls.dispose();
    this.renderer.dispose();
    if (dom.parentElement) {
      dom.parentElement.removeChild(dom);
    }
  }
}
