import * as THREE from 'three';
import { WorldTheme } from '../types/world';

export function safeColor(color: string | number | undefined, defaultColor = '#62D5E8'): THREE.Color {
  if (!color) return new THREE.Color(defaultColor);
  if (typeof color === 'number') return new THREE.Color(color);
  let trimmed = color.trim().replace(/^https?:\/\//i, '');
  if (trimmed.startsWith('#')) return new THREE.Color(trimmed);
  if (/^[0-9a-fA-F]{3,8}$/.test(trimmed)) return new THREE.Color('#' + trimmed);
  try {
    return new THREE.Color(trimmed);
  } catch {
    return new THREE.Color(defaultColor);
  }
}

export class MaterialPalette {
  public static createGlassMaterial(color: string | number, opacity = 0.85): THREE.MeshPhysicalMaterial {
    const c = safeColor(color);
    return new THREE.MeshPhysicalMaterial({
      color: c,
      emissive: c.clone().multiplyScalar(0.15),
      roughness: 0.12,
      metalness: 0.1,
      transmission: 0.8,
      ior: 1.5,
      thickness: 1.2,
      transparent: true,
      opacity,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
    });
  }

  public static createCrystalMaterial(color: string | number): THREE.MeshPhysicalMaterial {
    const c = safeColor(color);
    return new THREE.MeshPhysicalMaterial({
      color: c,
      emissive: c.clone().multiplyScalar(0.4),
      roughness: 0.15,
      metalness: 0.35,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
      reflectivity: 0.9,
    });
  }

  public static createGlowMaterial(color: string | number, intensity = 1.0): THREE.MeshBasicMaterial {
    const c = safeColor(color);
    return new THREE.MeshBasicMaterial({
      color: c,
      transparent: true,
      opacity: 0.85 * intensity,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
  }

  public static createIslandBaseMaterial(theme: WorldTheme): THREE.MeshStandardMaterial {
    switch (theme) {
      case 'crystal_canyon':
        return new THREE.MeshStandardMaterial({
          color: new THREE.Color('#2A1B3D'),
          roughness: 0.7,
          metalness: 0.25,
          flatShading: true,
        });
      case 'cyber_city':
        return new THREE.MeshStandardMaterial({
          color: new THREE.Color('#0F172A'),
          roughness: 0.3,
          metalness: 0.8,
          wireframe: false,
          flatShading: true,
        });
      case 'dreamy_ocean':
      default:
        return new THREE.MeshStandardMaterial({
          color: new THREE.Color('#132347'),
          roughness: 0.45,
          metalness: 0.3,
          flatShading: true,
        });
    }
  }

  public static createRimMaterial(color: string | number): THREE.MeshStandardMaterial {
    const c = safeColor(color);
    return new THREE.MeshStandardMaterial({
      color: c,
      emissive: c.clone().multiplyScalar(0.8),
      roughness: 0.2,
      metalness: 0.5,
    });
  }
}
