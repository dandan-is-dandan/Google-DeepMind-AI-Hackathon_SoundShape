import * as THREE from 'three';
import { DrumSoundType, RhythmStep } from '../types/world';
import { MaterialPalette } from './materials';

export interface RhythmTowerMeshGroup extends THREE.Group {
  userData: {
    isRhythmTower: boolean;
    objectId: string;
    sectionId: string;
    stepIndex: number;
    soundType: DrumSoundType;
    eventTimeSeconds: number;
    intensity: number;
    active: boolean;
    baseY: number;
    targetHeight: number;
    currentHeight: number;
    instrumentType: string;
    sourceFeatureType: string;
    sourceFeatureValue: number;
    originalParameter: number;
  };
}

/**
 * Builds an interactive 3D Rhythm Crystal (Requirement 3 & 4.A).
 * Created as a distinct mineral crystal formation:
 * (1) Faceted hexagonal pedestal
 * (2) Tapered multifaceted crystal spire (height scales with event intensity)
 * (3) Flanking companion crystal shards at natural mineral angles
 * (4) Luminous diamond/gem cap (pulses during playback event)
 * (5) Visual Edited State Marker Aura (turns visible when edited)
 * (6) Top direct manipulation 3D drag handle
 */
export function createRhythmTower(
  sectionId: string,
  step: RhythmStep,
  position: THREE.Vector3,
  themeColor: string
): RhythmTowerMeshGroup {
  const group = new THREE.Group() as RhythmTowerMeshGroup;
  group.position.copy(position);

  const height = Math.max(0.5, step.intensity * 4.2);
  const spireColor =
    step.type === 'kick' ? '#62D5E8' : step.type === 'snare' ? '#FFB66E' : '#A58BFA';

  // 1. Base pedestal (faceted obsidian hexagonal block)
  const baseGeo = new THREE.CylinderGeometry(0.34, 0.46, 0.22, 6);
  const baseMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#141D30'),
    roughness: 0.45,
    metalness: 0.65,
  });
  const baseMesh = new THREE.Mesh(baseGeo, baseMat);
  baseMesh.position.y = 0.11;
  group.add(baseMesh);

  // 2. Main crystalline faceted spire (6-sided prism tapering to pointed gem apex)
  const spireGeo = new THREE.CylinderGeometry(0.1, 0.32, 1, 6);
  spireGeo.translate(0, 0.5, 0); // Bottom pivot

  const spireMat = MaterialPalette.createCrystalMaterial(step.active ? spireColor : '#2A344A');
  const spireMesh = new THREE.Mesh(spireGeo, spireMat);
  spireMesh.position.y = 0.22;
  spireMesh.scale.set(1, height, 1);
  spireMesh.name = 'spireMesh';
  group.add(spireMesh);

  // 3. Flanking companion crystal shards (giving true mineral crystal cluster silhouette)
  const shard1Geo = new THREE.ConeGeometry(0.11, 0.75, 5);
  const shard1Mat = MaterialPalette.createCrystalMaterial(step.active ? spireColor : '#2A344A');
  const shard1Mesh = new THREE.Mesh(shard1Geo, shard1Mat);
  shard1Mesh.name = 'shard1';
  shard1Mesh.position.set(-0.26, 0.38, 0.12);
  shard1Mesh.rotation.z = 0.28;
  shard1Mesh.rotation.x = -0.15;
  group.add(shard1Mesh);

  const shard2Geo = new THREE.ConeGeometry(0.09, 0.58, 5);
  const shard2Mat = MaterialPalette.createCrystalMaterial(step.active ? spireColor : '#2A344A');
  const shard2Mesh = new THREE.Mesh(shard2Geo, shard2Mat);
  shard2Mesh.name = 'shard2';
  shard2Mesh.position.set(0.24, 0.3, -0.1);
  shard2Mesh.rotation.z = -0.26;
  shard2Mesh.rotation.y = 0.35;
  group.add(shard2Mesh);

  // 4. Luminous diamond / gem cap
  const capGeo = new THREE.OctahedronGeometry(0.24, 0);
  const capMat = MaterialPalette.createGlowMaterial(spireColor, step.active ? 0.95 : 0.2);
  const capMesh = new THREE.Mesh(capGeo, capMat);
  capMesh.position.y = 0.22 + height;
  capMesh.name = 'capMesh';
  group.add(capMesh);

  // 5. Visual Edited State Marker Aura Ring (Requirement 8)
  const editedRingGeo = new THREE.TorusGeometry(0.48, 0.045, 6, 20);
  editedRingGeo.rotateX(Math.PI / 2);
  const editedRingMat = MaterialPalette.createGlowMaterial('#C084FC', 0.95);
  const editedAura = new THREE.Mesh(editedRingGeo, editedRingMat);
  editedAura.position.y = 0.26;
  editedAura.name = 'editedAura';
  editedAura.visible = false;
  group.add(editedAura);

  // 6. Interactive 3D Drag Handle (Torus + Sphere)
  const handleGeo = new THREE.TorusGeometry(0.35, 0.05, 8, 16);
  handleGeo.rotateX(Math.PI / 2);
  const handleMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#FFFFFF'),
    emissive: new THREE.Color(spireColor).multiplyScalar(0.7),
    roughness: 0.1,
    metalness: 0.9,
  });
  const handleMesh = new THREE.Mesh(handleGeo, handleMat);
  handleMesh.position.y = 0.22 + height;
  handleMesh.name = 'dragHandle';
  handleMesh.userData = {
    isDragHandle: true,
    isRhythmHandle: true,
    sectionId,
    parentTower: group,
  };
  group.add(handleMesh);

  // Store metadata
  group.userData = {
    isRhythmTower: true,
    objectId: step.objectId || `crystal_${sectionId}_step${step.index}`,
    sectionId,
    stepIndex: step.index,
    soundType: step.type,
    eventTimeSeconds: step.eventTimeSeconds ?? 0,
    intensity: step.intensity,
    active: step.active,
    baseY: position.y,
    targetHeight: height,
    currentHeight: height,
    instrumentType:
      step.instrumentType ||
      (step.type === 'kick'
        ? 'Synthesized Kick Drum'
        : step.type === 'snare'
        ? 'Synthesized Snare Drum'
        : 'Synthesized Hi-Hat'),
    sourceFeatureType: step.sourceFeatureType || 'Percussive Onset & Spectral Transient',
    sourceFeatureValue: step.sourceFeatureValue ?? step.intensity,
    originalParameter: step.originalParameter ?? step.intensity,
  };

  return group;
}

/**
 * Triggers a temporary rhythmic pulse glow when playback passes this tower (Requirement 5)
 */
export function setTowerPlaybackGlow(tower: RhythmTowerMeshGroup, isHit: boolean) {
  const capMesh = tower.getObjectByName('capMesh') as THREE.Mesh;
  const spireMesh = tower.getObjectByName('spireMesh') as THREE.Mesh;
  const shard1 = tower.getObjectByName('shard1') as THREE.Mesh;
  const shard2 = tower.getObjectByName('shard2') as THREE.Mesh;

  if (capMesh && capMesh.material instanceof THREE.MeshBasicMaterial) {
    if (isHit && tower.userData.active) {
      capMesh.scale.set(1.65, 1.65, 1.65);
      capMesh.material.opacity = 1.0;
    } else {
      capMesh.scale.set(1.0, 1.0, 1.0);
      capMesh.material.opacity = tower.userData.active ? 0.9 : 0.2;
    }
  }

  const spireColor =
    tower.userData.soundType === 'kick'
      ? '#62D5E8'
      : tower.userData.soundType === 'snare'
      ? '#FFB66E'
      : '#A58BFA';

  if (spireMesh && spireMesh.material instanceof THREE.MeshPhysicalMaterial) {
    if (isHit && tower.userData.active) {
      spireMesh.material.emissive.set(new THREE.Color('#FFFFFF').multiplyScalar(0.9));
    } else {
      spireMesh.material.emissive.set(
        new THREE.Color(tower.userData.active ? spireColor : '#1E293B').multiplyScalar(0.4)
      );
    }
  }

  if (shard1 && shard1.material instanceof THREE.MeshPhysicalMaterial) {
    shard1.material.emissive.set(
      isHit && tower.userData.active
        ? new THREE.Color('#FFFFFF').multiplyScalar(0.65)
        : new THREE.Color(tower.userData.active ? spireColor : '#1E293B').multiplyScalar(0.3)
    );
  }
  if (shard2 && shard2.material instanceof THREE.MeshPhysicalMaterial) {
    shard2.material.emissive.set(
      isHit && tower.userData.active
        ? new THREE.Color('#FFFFFF').multiplyScalar(0.65)
        : new THREE.Color(tower.userData.active ? spireColor : '#1E293B').multiplyScalar(0.3)
    );
  }
}

/**
 * Updates a Rhythm Crystal's 3D geometry and edited state in response to user edits.
 */
export function updateRhythmTowerHeight(
  tower: RhythmTowerMeshGroup,
  newIntensity: number,
  active?: boolean,
  isEdited?: boolean
) {
  const intensity = Math.max(0, Math.min(1, newIntensity));
  tower.userData.intensity = intensity;
  if (active !== undefined) {
    tower.userData.active = active;
  }

  const height = Math.max(0.5, intensity * 4.2);
  tower.userData.targetHeight = height;

  const spireMesh = tower.getObjectByName('spireMesh') as THREE.Mesh;
  const capMesh = tower.getObjectByName('capMesh') as THREE.Mesh;
  const handleMesh = tower.getObjectByName('dragHandle') as THREE.Mesh;
  const editedAura = tower.getObjectByName('editedAura') as THREE.Mesh;

  if (spireMesh) {
    spireMesh.scale.y = height;
    const spireColor =
      tower.userData.soundType === 'kick'
        ? '#62D5E8'
        : tower.userData.soundType === 'snare'
        ? '#FFB66E'
        : '#A58BFA';
    const mat = spireMesh.material as THREE.MeshPhysicalMaterial;
    mat.color.set(tower.userData.active ? spireColor : '#2A344A');
    mat.emissive.set(
      new THREE.Color(tower.userData.active ? spireColor : '#141D30').multiplyScalar(0.4)
    );
  }

  if (capMesh) {
    capMesh.position.y = 0.22 + height;
    const capMat = capMesh.material as THREE.MeshBasicMaterial;
    capMat.opacity = tower.userData.active ? 0.9 : 0.2;
  }

  if (handleMesh) {
    handleMesh.position.y = 0.22 + height;
  }

  // Toggle visible edited state aura ring
  if (editedAura) {
    const hasChanged =
      isEdited !== undefined
        ? isEdited
        : Math.abs(intensity - tower.userData.originalParameter) > 0.02 ||
          (active !== undefined && active !== tower.userData.active);
    editedAura.visible = hasChanged;
  }
}

/**
 * Creates the glowing Bass River sculpture winding around the island (Requirement 4.B).
 */
export function createBassRiver(
  sectionId: string,
  islandCenter: THREE.Vector3,
  radius: number,
  intensity: number,
  color: string
): THREE.Group {
  const group = new THREE.Group();
  group.userData = {
    isBassRiver: true,
    sectionId,
    intensity,
    originalIntensity: intensity,
    radius,
    color,
    name: 'Bass River',
  };

  // Create curved serpentine spline points
  const points: THREE.Vector3[] = [];
  const segments = 28;
  for (let i = 0; i <= segments; i++) {
    const angle = (i / segments) * Math.PI * 1.5 - Math.PI * 0.2;
    const r = radius * (0.68 + Math.sin(i * 1.3) * 0.22);
    const x = islandCenter.x + Math.cos(angle) * r;
    const z = islandCenter.z + Math.sin(angle) * r;
    const y = islandCenter.y + 0.35 + Math.sin(i * 0.8) * 0.15;
    points.push(new THREE.Vector3(x, y, z));
  }

  const curve = new THREE.CatmullRomCurve3(points);
  const tubeRadius = Math.max(0.14, intensity * 0.42);
  const tubeGeo = new THREE.TubeGeometry(curve, 54, tubeRadius, 8, false);

  // Warm orange/amber luminous river material
  const riverColor = '#FF9E40';
  const riverMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(riverColor),
    emissive: new THREE.Color(riverColor).multiplyScalar(0.65),
    roughness: 0.12,
    metalness: 0.2,
    transmission: 0.55,
    transparent: true,
    opacity: 0.9,
    clearcoat: 1.0,
  });

  const tubeMesh = new THREE.Mesh(tubeGeo, riverMat);
  tubeMesh.name = 'riverTube';
  tubeMesh.userData = { isBassRiverMesh: true, parentRiver: group, sectionId };
  group.add(tubeMesh);

  // Visible 3D Editing Handle along prominent bend of the river
  const handlePt = curve.getPoint(0.5);
  const handleGeo = new THREE.TorusGeometry(0.42, 0.06, 8, 16);
  handleGeo.rotateX(Math.PI / 2);
  const handleMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#FFFFFF'),
    emissive: new THREE.Color('#FF9E40').multiplyScalar(0.8),
    roughness: 0.1,
    metalness: 0.85,
  });
  const handleMesh = new THREE.Mesh(handleGeo, handleMat);
  handleMesh.position.copy(handlePt);
  handleMesh.position.y += 0.3;
  handleMesh.name = 'bassHandle';
  handleMesh.userData = {
    isDragHandle: true,
    isBassHandle: true,
    sectionId,
    parentRiver: group,
  };
  group.add(handleMesh);

  return group;
}

/**
 * Updates Bass River thickness in response to user edits or slider changes
 */
export function updateBassRiverThickness(riverGroup: THREE.Group, newIntensity: number) {
  const intensity = Math.max(0.05, Math.min(1.0, newIntensity));
  riverGroup.userData.intensity = intensity;

  const tubeMesh = riverGroup.getObjectByName('riverTube') as THREE.Mesh;
  if (tubeMesh) {
    const scale = Math.max(0.4, intensity * 1.8);
    tubeMesh.scale.set(1, scale, scale);
  }
}

/**
 * Creates the Energy Core sculpture (Requirement 4.C).
 */
export function createEnergyCore(
  sectionId: string,
  position: THREE.Vector3,
  energy: number,
  color: string
): THREE.Group {
  const group = new THREE.Group();
  group.position.copy(position);
  group.position.y += 3.6;
  group.userData = {
    isEnergyCore: true,
    sectionId,
    energy,
    originalEnergy: energy,
    name: 'Energy Core',
  };

  // Central polyhedral crystal (Icosahedron) in vivid violet/purple
  const coreColor = '#A58BFA';
  const coreScale = 0.9 * Math.max(0.5, energy);
  const coreGeo = new THREE.IcosahedronGeometry(coreScale, 0);
  const coreMat = MaterialPalette.createCrystalMaterial(coreColor);
  const coreMesh = new THREE.Mesh(coreGeo, coreMat);
  coreMesh.name = 'coreBody';
  coreMesh.userData = { isEnergyCoreMesh: true, parentCore: group, sectionId };
  group.add(coreMesh);

  // Outer orbital rings in violet glow
  const ringGeo1 = new THREE.TorusGeometry(1.35 * Math.max(0.6, energy), 0.045, 8, 24);
  const ringMat = MaterialPalette.createGlowMaterial(coreColor, 0.85);
  const ringMesh1 = new THREE.Mesh(ringGeo1, ringMat);
  ringMesh1.name = 'ring1';
  ringMesh1.rotation.x = Math.PI / 3;
  group.add(ringMesh1);

  const ringGeo2 = new THREE.TorusGeometry(1.6 * Math.max(0.6, energy), 0.038, 8, 24);
  const ringMesh2 = new THREE.Mesh(ringGeo2, ringMat);
  ringMesh2.name = 'ring2';
  ringMesh2.rotation.y = Math.PI / 4;
  group.add(ringMesh2);

  // 3D Direct Manipulation Scale Handle (Glowing orbital diamond ring)
  const handleGeo = new THREE.TorusGeometry(1.9 * Math.max(0.6, energy), 0.065, 8, 24);
  handleGeo.rotateX(Math.PI / 2);
  const handleMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#FFFFFF'),
    emissive: new THREE.Color('#C084FC').multiplyScalar(0.75),
    roughness: 0.1,
    metalness: 0.9,
  });
  const handleMesh = new THREE.Mesh(handleGeo, handleMat);
  handleMesh.name = 'energyHandle';
  handleMesh.userData = {
    isDragHandle: true,
    isEnergyHandle: true,
    sectionId,
    parentCore: group,
  };
  group.add(handleMesh);

  return group;
}

/**
 * Updates Energy Core scale in response to user edits
 */
export function updateEnergyCoreScale(coreGroup: THREE.Group, newEnergy: number) {
  const energy = Math.max(0.1, Math.min(1.0, newEnergy));
  coreGroup.userData.energy = energy;

  const coreBody = coreGroup.getObjectByName('coreBody') as THREE.Mesh;
  const ring1 = coreGroup.getObjectByName('ring1') as THREE.Mesh;
  const ring2 = coreGroup.getObjectByName('ring2') as THREE.Mesh;
  const handle = coreGroup.getObjectByName('energyHandle') as THREE.Mesh;

  const scale = Math.max(0.4, energy * 1.5);
  if (coreBody) coreBody.scale.set(scale, scale, scale);
  if (ring1) ring1.scale.set(scale, scale, scale);
  if (ring2) ring2.scale.set(scale, scale, scale);
  if (handle) handle.scale.set(scale, scale, scale);
}
