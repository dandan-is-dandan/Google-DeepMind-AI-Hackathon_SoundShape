import React, { useEffect, useRef, useState } from 'react';
import { EditScope, LAYER_CONFIGS, MusicalLayerType, ViewMode, WorldEditState, WorldScene } from '../types/world';
import {
  IslandScreenPosition,
  SculptureHoverInfo,
  SelectedSculptureType,
  SoundShapeSceneManager,
} from './SceneManager';
import {
  Globe,
  Layers,
  Crosshair,
  RotateCcw,
  Compass,
  Sliders,
  Sparkles,
  Zap,
  Waves,
  Info,
  MapPin,
  Clock,
  Music,
} from 'lucide-react';

interface MusicWorldCanvasProps {
  scene: WorldScene | null;
  editState: WorldEditState;
  viewMode: ViewMode;
  selectedSectionId: string | null;
  selectedStepIndex: number | null;
  selectedSculptureType?: SelectedSculptureType | null;
  activeLayer?: MusicalLayerType;
  selectedTimestamp?: number | null;
  editScope?: EditScope;
  playbackTime: number;
  isPlaying: boolean;
  isEditedMode: boolean;
  followMusicMode?: boolean;
  interactionMode: 'explore' | 'edit';
  onInteractionModeChange: (mode: 'explore' | 'edit') => void;
  onSelectSection: (sectionId: string) => void;
  onSelectElement: (sectionId: string, stepIndex: number) => void;
  onSelectSculpture?: (sectionId: string, type: SelectedSculptureType) => void;
  onSelectLayer?: (layer: MusicalLayerType) => void;
  onScopeChange?: (scope: EditScope) => void;
  onTowerIntensityChange: (sectionId: string, stepIndex: number, intensity: number) => void;
  onBassIntensityChange?: (sectionId: string, intensity: number) => void;
  onEnergyLevelChange?: (sectionId: string, energy: number) => void;
  onViewModeChange?: (mode: ViewMode) => void;
}

export const MusicWorldCanvas: React.FC<MusicWorldCanvasProps> = ({
  scene,
  editState,
  viewMode,
  selectedSectionId,
  selectedStepIndex,
  selectedSculptureType,
  activeLayer = 'energy',
  selectedTimestamp = null,
  editScope = 'moment',
  playbackTime,
  isPlaying,
  isEditedMode,
  followMusicMode = false,
  interactionMode,
  onInteractionModeChange,
  onSelectSection,
  onSelectElement,
  onSelectSculpture,
  onSelectLayer,
  onScopeChange,
  onTowerIntensityChange,
  onBassIntensityChange,
  onEnergyLevelChange,
  onViewModeChange,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const managerRef = useRef<SoundShapeSceneManager | null>(null);

  // Screen positions for 3D floating island labels
  const [islandLabels, setIslandLabels] = useState<IslandScreenPosition[]>([]);
  const [hoveredSculpture, setHoveredSculpture] = useState<SculptureHoverInfo | null>(null);
  const [hoveredIslandId, setHoveredIslandId] = useState<string | null>(null);

  // Initialize SceneManager once on mount
  useEffect(() => {
    if (!mountRef.current) return;

    const manager = new SoundShapeSceneManager(mountRef.current, {
      onSelectSection,
      onSelectElement,
      onSelectSculpture,
      onTowerIntensityChange,
      onBassIntensityChange,
      onEnergyLevelChange,
      onHoverSculpture: (info) => setHoveredSculpture(info),
      onViewModeChange,
    });
    managerRef.current = manager;

    return () => {
      manager.dispose();
      managerRef.current = null;
    };
  }, []);

  // Update scene when scene object changes
  useEffect(() => {
    if (managerRef.current && scene) {
      managerRef.current.setWorldScene(scene, editState);
    }
  }, [scene]);

  // Sync edits
  useEffect(() => {
    if (managerRef.current) {
      managerRef.current.syncEditState(editState);
    }
  }, [editState]);

  // Sync interaction mode (explore vs edit)
  useEffect(() => {
    if (managerRef.current) {
      managerRef.current.setInteractionMode(interactionMode);
    }
  }, [interactionMode]);

  // Update camera view mode
  useEffect(() => {
    if (managerRef.current) {
      managerRef.current.setViewMode(
        viewMode,
        selectedSectionId || undefined,
        selectedStepIndex ?? undefined
      );
    }
  }, [viewMode, selectedSectionId, selectedStepIndex]);

  // Update playback time & synchronizations
  useEffect(() => {
    if (managerRef.current) {
      managerRef.current.updatePlayback(playbackTime, isPlaying, isEditedMode, followMusicMode);
    }
  }, [playbackTime, isPlaying, isEditedMode, followMusicMode]);

  // Sync activeLayer to SceneManager (displays only the selected layer handles & geometry)
  useEffect(() => {
    if (managerRef.current) {
      managerRef.current.setActiveLayer(activeLayer);
    }
  }, [activeLayer]);

  // Sync selectedTimestamp to SceneManager (renders holographic time beacon in 3D)
  useEffect(() => {
    if (managerRef.current) {
      managerRef.current.setSelectedTimestamp(selectedTimestamp, activeLayer);
    }
  }, [selectedTimestamp, activeLayer]);

  // Update screen-projected island labels on every animation frame in World View
  useEffect(() => {
    let animId = 0;
    const updateLabels = () => {
      if (managerRef.current && viewMode === 'world') {
        const positions = managerRef.current.getIslandScreenPositions();
        setIslandLabels(positions);
      } else {
        setIslandLabels([]);
      }
      animId = requestAnimationFrame(updateLabels);
    };

    animId = requestAnimationFrame(updateLabels);
    return () => cancelAnimationFrame(animId);
  }, [viewMode, scene]);

  const layersList: MusicalLayerType[] = ['energy', 'bass', 'treble', 'texture', 'pitch', 'timing'];

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#0B1020] select-none">
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* TOP BAR: World Journey / Section Map + Explore/Edit Mode Switcher */}
      <div className="absolute top-3 left-4 right-4 flex items-center justify-between pointer-events-none z-20">
        {/* World Map / Chronological Journey Strip (Requirement 3) */}
        {scene && (
          <div className="pointer-events-auto flex items-center gap-1.5 p-1 rounded-xl bg-[#111A30]/85 border border-white/10 shadow-lg backdrop-blur-md">
            <div className="flex items-center gap-1.5 px-2 text-[11px] font-semibold text-[#93A4BE] tracking-wider uppercase border-r border-white/10">
              <MapPin className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span className="hidden sm:inline">World Map</span>
            </div>
            {scene.sections.map((sec, idx) => {
              const isCurrentPlaying = playbackTime >= sec.start && playbackTime <= sec.end;
              const isSelected = selectedSectionId === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => onSelectSection(sec.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-white/15 text-white border border-[#62D5E8]/60 shadow-sm'
                      : isCurrentPlaying
                      ? 'bg-[#62D5E8]/20 text-[#62D5E8] border border-[#62D5E8]/40 animate-pulse'
                      : 'text-[#93A4BE] hover:text-white hover:bg-white/5'
                  }`}
                  title={`${sec.label} (${sec.start.toFixed(1)}s - ${sec.end.toFixed(1)}s)`}
                >
                  <span className="font-mono text-[10px] opacity-60">#{idx + 1}</span>
                  <span className="truncate max-w-[90px]">{sec.label}</span>
                  <span className="font-mono text-[10px] opacity-75">
                    {sec.start.toFixed(0)}–{sec.end.toFixed(0)}s
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Explore vs Edit Mode Switcher (Requirement 5) */}
        <div className="pointer-events-auto flex items-center p-1 rounded-xl bg-[#111A30]/90 border border-white/10 shadow-lg backdrop-blur-md">
          <button
            onClick={() => onInteractionModeChange('explore')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              interactionMode === 'explore'
                ? 'bg-[#62D5E8] text-[#0B1020] shadow-sm'
                : 'text-[#93A4BE] hover:text-white hover:bg-white/5'
            }`}
            title="Explore Mode: Orbit, zoom, inspect, and understand the 3D musical landscape"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Explore Mode</span>
          </button>
          <button
            onClick={() => onInteractionModeChange('edit')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              interactionMode === 'edit'
                ? 'bg-[#FFB66E] text-[#0B1020] shadow-sm'
                : 'text-[#93A4BE] hover:text-white hover:bg-white/5'
            }`}
            title="Edit Mode: Highlight editable sculptures and reveal 3D manipulation handles"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Edit Mode</span>
          </button>
        </div>
      </div>

      {/* FLOATING CONTEXTUAL MUSICAL LAYER SELECTOR (Prompt 4, Req 2) */}
      {onSelectLayer && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 pointer-events-auto flex items-center gap-1 p-1 rounded-2xl bg-[#0B1020]/95 border border-white/15 shadow-2xl backdrop-blur-md animate-fade-in">
          <div className="flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-mono font-bold tracking-wider uppercase text-[#93A4BE] border-r border-white/10">
            <Layers className="w-3 h-3 text-[#62D5E8]" />
            <span className="hidden sm:inline">Layer</span>
          </div>

          <div className="flex items-center gap-1">
            {layersList.map((layerKey) => {
              const cfg = LAYER_CONFIGS[layerKey];
              const isCurrent = activeLayer === layerKey;
              return (
                <button
                  key={layerKey}
                  onClick={() => onSelectLayer(layerKey)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent
                      ? 'shadow-md scale-105 ring-1'
                      : 'text-[#93A4BE] hover:text-white hover:bg-white/5 opacity-80 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: isCurrent ? `${cfg.color}25` : undefined,
                    color: isCurrent ? '#FFFFFF' : undefined,
                    borderColor: isCurrent ? cfg.color : undefined,
                    boxShadow: isCurrent ? `0 0 14px ${cfg.color}40` : undefined,
                  }}
                  title={`${cfg.label}: ${cfg.property} — ${cfg.description}`}
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: cfg.color }}
                  />
                  <span>{cfg.label}</span>
                </button>
              );
            })}
          </div>

          {/* Optional Scope Selector Switcher */}
          {onScopeChange && (
            <div className="flex items-center gap-1 pl-1.5 ml-1 border-l border-white/10">
              <button
                onClick={() => onScopeChange('moment')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-mono uppercase font-bold transition-all ${
                  editScope === 'moment'
                    ? 'bg-white/20 text-white'
                    : 'text-[#93A4BE] hover:text-white hover:bg-white/5'
                }`}
                title="Moment Scope: Edits apply to short adjustable window around timestamp (500ms)"
              >
                Moment
              </button>
              <button
                onClick={() => onScopeChange('section')}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-mono uppercase font-bold transition-all ${
                  editScope === 'section'
                    ? 'bg-white/20 text-white'
                    : 'text-[#93A4BE] hover:text-white hover:bg-white/5'
                }`}
                title="Section Scope: Edits apply to whole containing section"
              >
                Section
              </button>
            </div>
          )}
        </div>
      )}

      {/* FLOATING 3D SECTION LABELS (World View Requirement 3) */}
      {viewMode === 'world' &&
        scene &&
        islandLabels.map((lbl) => {
          if (!lbl.visible) return null;
          const isSelected = selectedSectionId === lbl.sectionId;
          const isCurrentPlaying = playbackTime >= lbl.start && playbackTime <= lbl.end;
          const sec = scene.sections.find((s) => s.id === lbl.sectionId);

          return (
            <div
              key={lbl.sectionId}
              style={{
                position: 'absolute',
                left: `${lbl.screenX}px`,
                top: `${lbl.screenY}px`,
                transform: 'translate(-50%, -100%)',
              }}
              className="z-10 pointer-events-auto group"
              onMouseEnter={() => setHoveredIslandId(lbl.sectionId)}
              onMouseLeave={() => setHoveredIslandId(null)}
              onClick={() => onSelectSection(lbl.sectionId)}
            >
              <div
                className={`p-2.5 rounded-xl border backdrop-blur-md cursor-pointer transition-all duration-200 shadow-xl min-w-[190px] max-w-[240px] ${
                  isSelected
                    ? 'bg-[#111A30]/95 border-[#62D5E8] ring-2 ring-[#62D5E8]/40 scale-105'
                    : isCurrentPlaying
                    ? 'bg-[#111A30]/95 border-[#FFB66E] ring-1 ring-[#FFB66E]/50'
                    : 'bg-[#111A30]/85 border-white/10 hover:border-white/30 hover:bg-[#16223E]/95'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-xs font-bold text-white tracking-wide font-['Space_Grotesk'] truncate">
                    #{scene.sections.findIndex((s) => s.id === lbl.sectionId) + 1} {lbl.label}
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-[#62D5E8]/15 text-[#62D5E8]">
                    ⚡ {Math.round(lbl.energy * 100)}%
                  </span>
                </div>

                {/* Landscape Archetype & Time Window */}
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-semibold uppercase border ${
                      lbl.archetype === 'fractured_peak'
                        ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                        : lbl.archetype === 'rhythm_city'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                    }`}
                  >
                    {lbl.archetype === 'fractured_peak'
                      ? 'Fractured Peak'
                      : lbl.archetype === 'rhythm_city'
                      ? 'Rhythm City'
                      : 'Glass Sanctuary'}
                  </span>
                  <span className="text-[10px] font-mono text-[#93A4BE]">
                    {lbl.start.toFixed(1)}s – {lbl.end.toFixed(1)}s
                  </span>
                </div>

                <p className="text-[11px] text-[#93A4BE] line-clamp-2 leading-tight">
                  {lbl.mood}
                </p>

                {/* Hover Callout with Spatial Rationale */}
                <div className="mt-2 pt-1.5 border-t border-white/10 flex items-center justify-between text-[10px] text-[#62D5E8] opacity-80 group-hover:opacity-100 transition-opacity">
                  <span className="font-semibold">Click to explore section →</span>
                </div>
              </div>

              {/* Pin indicator dot */}
              <div className="w-2 h-2 rounded-full bg-[#62D5E8] mx-auto mt-1 shadow-md shadow-[#62D5E8]/50" />
            </div>
          );
        })}

      {/* FLOATING SCULPTURE HOVER TOOLTIP (Requirement 6) */}
      {hoveredSculpture && (
        <div
          style={{
            position: 'fixed',
            left: `${hoveredSculpture.screenX + 16}px`,
            top: `${hoveredSculpture.screenY - 12}px`,
          }}
          className="pointer-events-none z-50 px-3.5 py-2.5 rounded-xl bg-[#0B1020]/95 border border-[#62D5E8]/50 shadow-2xl backdrop-blur-md max-w-[260px] animate-fade-in space-y-1"
        >
          {/* Object Name with Type Icon */}
          <div className="flex items-center gap-1.5 pb-1 border-b border-white/10">
            {hoveredSculpture.type === 'rhythm_crystal' && (
              <Zap className="w-3.5 h-3.5 text-[#62D5E8]" />
            )}
            {hoveredSculpture.type === 'bass_river' && (
              <Waves className="w-3.5 h-3.5 text-[#FF9E40]" />
            )}
            {hoveredSculpture.type === 'energy_core' && (
              <Sparkles className="w-3.5 h-3.5 text-[#A58BFA]" />
            )}
            {hoveredSculpture.type === 'decorative' && (
              <Info className="w-3.5 h-3.5 text-[#93A4BE]" />
            )}
            <span className="text-xs font-bold text-white tracking-wide">
              {hoveredSculpture.title}
            </span>
          </div>

          {/* Timestamp / Time Range */}
          {hoveredSculpture.timestamp && (
            <p className="text-[11px] font-mono text-[#62D5E8] font-medium">
              {hoveredSculpture.timestamp}
            </p>
          )}

          {/* Section Name */}
          {hoveredSculpture.sectionName && (
            <p className="text-[11px] text-[#EAF2FF]">
              <strong className="text-white/60">Section: </strong>
              <span>{hoveredSculpture.sectionName}</span>
            </p>
          )}

          {/* Musical Role */}
          {hoveredSculpture.role && (
            <p className="text-[11px] text-[#EAF2FF]">
              <strong className="text-white/60">{hoveredSculpture.role.startsWith('Role:') ? '' : 'Role: '}</strong>
              <span>{hoveredSculpture.role}</span>
            </p>
          )}

          {hoveredSculpture.subtitle && !hoveredSculpture.role && (
            <p className="text-[11px] text-[#93A4BE]">{hoveredSculpture.subtitle}</p>
          )}

          {/* Edit Effect */}
          <div className="pt-1 border-t border-white/10 text-[10px] text-[#FFB66E] font-medium leading-tight">
            {hoveredSculpture.editEffect || hoveredSculpture.actionHint}
          </div>
        </div>
      )}

      {/* EDIT MODE SCULPTURE LEGEND (Requirement 5) */}
      {interactionMode === 'edit' && (
        <div className="absolute bottom-4 left-4 p-3 rounded-xl bg-[#111A30]/90 border border-white/10 shadow-xl backdrop-blur-md z-20 pointer-events-auto max-w-[260px]">
          <span className="text-[10px] font-semibold text-[#93A4BE] uppercase tracking-wider block mb-2">
            Editable Sculpture Types
          </span>
          <div className="space-y-1.5 text-xs text-white">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-sm bg-[#62D5E8]" />
              <span className="font-semibold text-[#62D5E8]">Rhythm Crystals:</span>
              <span className="text-[11px] text-[#93A4BE]">Percussion velocity</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-sm bg-[#FF9E40]" />
              <span className="font-semibold text-[#FF9E40]">Bass River:</span>
              <span className="text-[11px] text-[#93A4BE]">Low-frequency sub-bass</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-sm bg-[#A58BFA]" />
              <span className="font-semibold text-[#A58BFA]">Energy Core:</span>
              <span className="text-[11px] text-[#93A4BE]">Section accompaniment</span>
            </div>
          </div>
        </div>
      )}

      {/* Floating Camera Actions Overlay */}
      <div className="absolute bottom-4 right-4 flex items-center gap-1.5 bg-[#111A30]/85 border border-white/10 p-1 rounded-xl shadow-xl z-20">
        <button
          onClick={() => managerRef.current?.fitView()}
          className="px-2.5 py-1 rounded-lg text-xs font-medium text-white bg-[#111A30] hover:bg-white/10 border border-white/10 transition-colors flex items-center gap-1.5 shadow-sm"
          title="Fit current view framing (World, Section, or Element)"
        >
          <Crosshair className="w-3.5 h-3.5 text-[#62D5E8]" />
          <span>Fit View</span>
        </button>

        <button
          onClick={() => managerRef.current?.fitWorld()}
          className="px-2 py-1 rounded-lg text-xs font-medium text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1"
          title="Fit entire world in camera view"
        >
          <Globe className="w-3.5 h-3.5 text-[#62D5E8]" />
          <span>World</span>
        </button>

        {selectedSectionId && (
          <button
            onClick={() => managerRef.current?.fitSection()}
            className="px-2 py-1 rounded-lg text-xs font-medium text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1"
            title="Fit selected island in camera view"
          >
            <Layers className="w-3.5 h-3.5 text-[#A58BFA]" />
            <span>Section</span>
          </button>
        )}

        {viewMode === 'element' && selectedStepIndex !== null && (
          <button
            onClick={() => managerRef.current?.fitElement()}
            className="px-2 py-1 rounded-lg text-xs font-medium text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1"
            title="Frame selected sculpture and surroundings"
          >
            <Crosshair className="w-3.5 h-3.5 text-[#FFB66E]" />
            <span>Element</span>
          </button>
        )}

        <button
          onClick={() => managerRef.current?.resetCamera()}
          className="p-1.5 rounded-lg text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors"
          title="Reset Camera Framing"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
