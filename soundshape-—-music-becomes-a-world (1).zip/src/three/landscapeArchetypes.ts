import * as THREE from 'three';
import { SceneSection, WorldTheme } from '../types/world';
import { MaterialPalette, safeColor } from './materials';

export type LandscapeArchetype = 'glass_sanctuary' | 'rhythm_city' | 'fractured_peak';

/**
 * Determines the procedural landscape archetype based on Gemini's landscapeType,
 * section energy, mood, and overall world theme.
 */
export function determineLandscapeArchetype(
  section: SceneSection,
  worldTheme: WorldTheme
): LandscapeArchetype {
  const lType = section.landscapeType;

  // Explicit mappings from Gemini blueprint
  if (lType === 'crystal_peak' || lType === 'abyss_trench') {
    return 'fractured_peak';
  }
  if (lType === 'cyber_grid' || lType === 'neon_spires' || lType === 'floating_plateau') {
    return 'rhythm_city';
  }
  if (lType === 'glass_island') {
    return 'glass_sanctuary';
  }

  // Deterministic mapping from audio energy and section mood
  if (section.energy >= 0.65) {
    return 'fractured_peak';
  } else if (section.energy >= 0.4) {
    return 'rhythm_city';
  } else {
    return 'glass_sanctuary';
  }
}

/**
 * ARCHETYPE A: DREAMY OCEAN / GLASS SANCTUARY
 *
 * Visual properties:
 * - Smooth organic floating terrain with curved atoll geometry
 * - Translucent glass-like surfaces
 * - Wide, gently curved platforms with a shallow lagoon basin
 * - Suspended glass crystal polyhedra floating gently in the air
 * - Flowing luminous ribbons
 * - Soft cyan and lavender lighting
 * - Minimal visual clutter: serene, open atmosphere
 */
export function buildGlassSanctuaryTerrain(
  section: SceneSection,
  radius: number
): {
  terrainGroup: THREE.Group;
  surfaceY: number;
  rhythmY: number;
} {
  const group = new THREE.Group();
  group.name = 'archetype_glass_sanctuary';

  // 1. Organic Undulating Floating Hull (Lathe/Cylinder with parametric curve)
  const segments = 24;
  const baseGeo = new THREE.CylinderGeometry(radius, radius * 0.22, 4.5, segments, 2);
  const posAttr = baseGeo.attributes.position;

  // Displace perimeter slightly to give a natural, non-circular organic atoll silhouette
  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const y = posAttr.getY(i);
    const z = posAttr.getZ(i);
    const angle = Math.atan2(z, x);
    const dist = Math.sqrt(x * x + z * z);

    // Apply gentle tri-lobe organic wave to perimeter
    const displacement = 1.0 + Math.sin(angle * 3) * 0.08 + Math.cos(angle * 2) * 0.06;
    posAttr.setX(i, x * displacement);
    posAttr.setZ(i, z * displacement);

    // Soft downward droplet contour
    if (y < 0) {
      const taper = 1.0 - Math.pow(Math.abs(y) / 4.5, 1.4) * 0.65;
      posAttr.setX(i, posAttr.getX(i) * taper);
      posAttr.setZ(i, posAttr.getZ(i) * taper);
    }
  }
  baseGeo.computeVertexNormals();

  const baseMat = MaterialPalette.createIslandBaseMaterial('dreamy_ocean');
  const baseMesh = new THREE.Mesh(baseGeo, baseMat);
  baseMesh.position.y = -2.25;
  baseMesh.castShadow = true;
  baseMesh.receiveShadow = true;
  baseMesh.userData = { isIslandTerrain: true };
  group.add(baseMesh);

  // 2. Translucent Glass Basin / Sanctuary Lagoon Surface
  // Custom basin geometry where center dips into a serene pool
  const basinGeo = new THREE.CylinderGeometry(radius * 0.98, radius, 0.5, segments, 4);
  const basinPos = basinGeo.attributes.position;
  for (let i = 0; i < basinPos.count; i++) {
    const x = basinPos.getX(i);
    const y = basinPos.getY(i);
    const z = basinPos.getZ(i);
    const rDist = Math.sqrt(x * x + z * z) / radius;

    // Displace center downwards to form a shallow glass lagoon basin
    if (y >= 0) {
      const basinDip = Math.cos(rDist * Math.PI * 0.5) * 0.25;
      basinPos.setY(i, y - basinDip);
    }
  }
  basinGeo.computeVertexNormals();

  const glassMat = MaterialPalette.createGlassMaterial(section.dominantColor, 0.88);
  const basinMesh = new THREE.Mesh(basinGeo, glassMat);
  basinMesh.position.y = 0.25;
  basinMesh.userData = { isIslandSurface: true, sectionId: section.id };
  group.add(basinMesh);

  // 3. Delicate Luminous Water-Caustic Perimeter Ring
  const rimGeo = new THREE.TorusGeometry(radius * 0.97, 0.12, 8, 36);
  rimGeo.rotateX(Math.PI / 2);
  const rimMat = MaterialPalette.createRimMaterial(section.accentColor);
  const rimMesh = new THREE.Mesh(rimGeo, rimMat);
  rimMesh.position.y = 0.35;
  rimMesh.userData = { isDecorative: true };
  group.add(rimMesh);

  // 4. Suspended Floating Glass Formations (Hanging gently in the air above)
  const floatingGroup = new THREE.Group();
  floatingGroup.name = 'suspended_glass_crystals';
  const crystalCount = 4;
  for (let i = 0; i < crystalCount; i++) {
    const angle = (i / crystalCount) * Math.PI * 2 + 0.4;
    const dist = radius * 0.65;
    const size = 0.5 + (i % 2) * 0.25;

    const cGeo = new THREE.OctahedronGeometry(size, 0);
    const cMat = MaterialPalette.createGlassMaterial(section.accentColor, 0.8);
    const cMesh = new THREE.Mesh(cGeo, cMat);

    cMesh.position.set(
      Math.cos(angle) * dist,
      2.8 + Math.sin(i * 1.5) * 0.6,
      Math.sin(angle) * dist
    );
    cMesh.rotation.set(0.3 * i, 0.4 * i, 0.2 * i);
    cMesh.userData = { isDecorative: true, floatSpeed: 0.8 + i * 0.2 };
    floatingGroup.add(cMesh);
  }
  group.add(floatingGroup);

  // 5. Flowing Luminous Aurora Ribbon
  const ribbonCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-radius * 0.85, 0.8, -radius * 0.3),
    new THREE.Vector3(-radius * 0.3, 1.6, -radius * 0.6),
    new THREE.Vector3(radius * 0.2, 1.2, -radius * 0.5),
    new THREE.Vector3(radius * 0.8, 0.7, -radius * 0.2),
  ]);
  const ribbonGeo = new THREE.TubeGeometry(ribbonCurve, 28, 0.09, 6, false);
  const ribbonMat = MaterialPalette.createGlowMaterial(section.accentColor, 0.75);
  const ribbonMesh = new THREE.Mesh(ribbonGeo, ribbonMat);
  ribbonMesh.userData = { isDecorative: true };
  group.add(ribbonMesh);

  return {
    terrainGroup: group,
    surfaceY: 0.25,
    rhythmY: 0.35,
  };
}

/**
 * ARCHETYPE B: RISING ARCHITECTURE / RHYTHM CITY
 *
 * Visual properties:
 * - Layered ascending terraces matching chronological timeline
 * - Rising geometric architecture that ascends from left (earlier) to right (later)
 * - Repeating architectural arches and viaduct bridges
 * - Rhythm-driven modular column formations
 * - Warm-orange and cyan accents
 * - Strong visual direction
 */
export function buildRhythmCityTerrain(
  section: SceneSection,
  radius: number
): {
  terrainGroup: THREE.Group;
  surfaceY: number;
  rhythmY: number;
  getTerraceYForRatio: (ratio: number) => number;
} {
  const group = new THREE.Group();
  group.name = 'archetype_rhythm_city';

  // 1. Massive Beveled Monolithic Foundation Block
  const baseWidth = radius * 1.9;
  const baseDepth = radius * 1.6;
  const baseHeight = 3.6;

  const foundationGeo = new THREE.BoxGeometry(baseWidth, baseHeight, baseDepth);
  const foundationMat = MaterialPalette.createIslandBaseMaterial('cyber_city');
  const foundationMesh = new THREE.Mesh(foundationGeo, foundationMat);
  foundationMesh.position.y = -baseHeight / 2;
  foundationMesh.castShadow = true;
  foundationMesh.receiveShadow = true;
  foundationMesh.userData = { isIslandTerrain: true };
  group.add(foundationMesh);

  // Glowing circuit edges on base
  const wireGeo = new THREE.EdgesGeometry(foundationGeo);
  const wireMat = new THREE.LineBasicMaterial({
    color: safeColor(section.accentColor),
    linewidth: 2,
    transparent: true,
    opacity: 0.45,
  });
  const wireframe = new THREE.LineSegments(wireGeo, wireMat);
  wireframe.position.y = -baseHeight / 2;
  wireframe.userData = { isDecorative: true };
  group.add(wireframe);

  // 2. Three Ascending Stepped Terraces (Left-to-Right Chronological Rise)
  // Terrace 1: West / Early time (y = 0.25)
  // Terrace 2: Center / Mid time (y = 1.35)
  // Terrace 3: East / Peak time (y = 2.45)
  const terraceWidth = baseWidth / 3.1;
  const terraceDepth = baseDepth * 0.88;

  const terraceHeights = [0.4, 1.4, 2.4];
  const terraceOffsetsX = [-baseWidth * 0.32, 0, baseWidth * 0.32];

  terraceHeights.forEach((h, idx) => {
    const tGeo = new THREE.BoxGeometry(terraceWidth, h, terraceDepth);
    const tMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(idx === 2 ? '#1E293B' : idx === 1 ? '#0F172A' : '#090D1A'),
      roughness: 0.22,
      metalness: 0.75,
    });
    const tMesh = new THREE.Mesh(tGeo, tMat);
    tMesh.position.set(terraceOffsetsX[idx], h / 2, 0);
    tMesh.castShadow = true;
    tMesh.receiveShadow = true;
    tMesh.userData = { isIslandSurface: true, sectionId: section.id, terraceIndex: idx };
    group.add(tMesh);

    // Luminous terrace step boundary rim
    const edgeGeo = new THREE.BoxGeometry(terraceWidth * 1.01, 0.08, terraceDepth * 1.01);
    const edgeMat = MaterialPalette.createGlowMaterial(
      idx === 2 ? '#FFB66E' : section.accentColor,
      0.65
    );
    const edgeMesh = new THREE.Mesh(edgeGeo, edgeMat);
    edgeMesh.position.set(terraceOffsetsX[idx], h + 0.04, 0);
    edgeMesh.userData = { isDecorative: true };
    group.add(edgeMesh);
  });

  // 3. Repeating Architectural Arches & Skybridges
  const archRadius = terraceWidth * 0.45;
  for (let a = 0; a < 2; a++) {
    const archGeo = new THREE.TorusGeometry(archRadius, 0.14, 6, 18, Math.PI);
    const archMat = new THREE.MeshStandardMaterial({
      color: safeColor(section.accentColor),
      emissive: safeColor(section.accentColor).multiplyScalar(0.4),
      roughness: 0.3,
      metalness: 0.8,
    });
    const archMesh = new THREE.Mesh(archGeo, archMat);
    // Spanning between terraces
    const archX = (terraceOffsetsX[a] + terraceOffsetsX[a + 1]) / 2;
    const archY = (terraceHeights[a] + terraceHeights[a + 1]) / 2 + archRadius;
    archMesh.position.set(archX, archY, -terraceDepth * 0.35);
    archMesh.userData = { isDecorative: true };
    group.add(archMesh);
  }

  // 4. Rhythm-Driven Colonnades (Flanking background pylons)
  const colCount = 6;
  for (let c = 0; c < colCount; c++) {
    const colRatio = c / (colCount - 1);
    const colHeight = 2.0 + colRatio * 3.8;
    const colX = -baseWidth * 0.42 + colRatio * (baseWidth * 0.84);
    const colZ = -terraceDepth * 0.45;

    const colGeo = new THREE.BoxGeometry(0.45, colHeight, 0.45);
    const colMat = MaterialPalette.createGlowMaterial(section.dominantColor, 0.7);
    const colMesh = new THREE.Mesh(colGeo, colMat);
    colMesh.position.set(colX, colHeight / 2, colZ);
    colMesh.userData = { isDecorative: true };
    group.add(colMesh);
  }

  // Helper function to calculate Y position on the ascending terraces based on time ratio (0.0 to 1.0)
  const getTerraceYForRatio = (ratio: number): number => {
    if (ratio < 0.33) return terraceHeights[0] + 0.05;
    if (ratio < 0.66) return terraceHeights[1] + 0.05;
    return terraceHeights[2] + 0.05;
  };

  return {
    terrainGroup: group,
    surfaceY: 0.4,
    rhythmY: 0.45,
    getTerraceYForRatio,
  };
}

/**
 * ARCHETYPE C: CRYSTAL CANYON / FRACTURED PEAK
 *
 * Visual properties:
 * - Dramatic jagged mountainous terrain
 * - Large faceted crystal formations
 * - Angular cliffs, sheer fractures, and canyon cleft
 * - Elevated soaring peaks
 * - Clustered quartz monoliths
 * - Floating shattered crystal fragments
 * - Violet and magenta highlights
 */
export function buildFracturedPeakTerrain(
  section: SceneSection,
  radius: number
): {
  terrainGroup: THREE.Group;
  surfaceY: number;
  rhythmY: number;
} {
  const group = new THREE.Group();
  group.name = 'archetype_fractured_peak';

  // 1. High-amplitude Jagged Mountain Peak Base
  // Subdivided cone/cylinder with high-amplitude vertex displacement
  const radialSegments = 16;
  const heightSegments = 6;
  const baseHeight = 6.2;
  const mountainGeo = new THREE.CylinderGeometry(
    radius * 0.95,
    radius * 0.2,
    baseHeight,
    radialSegments,
    heightSegments
  );

  const mPos = mountainGeo.attributes.position;
  for (let i = 0; i < mPos.count; i++) {
    const x = mPos.getX(i);
    const y = mPos.getY(i);
    const z = mPos.getZ(i);
    const angle = Math.atan2(z, x);
    const dist = Math.sqrt(x * x + z * z);

    // Jagged procedural noise
    const jaggedFactor = Math.sin(angle * 5) * 0.18 + Math.cos(angle * 3) * 0.14;
    mPos.setX(i, x * (1.0 + jaggedFactor));
    mPos.setZ(i, z * (1.0 + jaggedFactor));

    // Sheer cliff drops and twin mountain peaks
    if (y > 0) {
      // Create twin peaks on left and right, with central canyon cleft
      const peakDisplacement = (Math.abs(x) / radius) * 2.2 - (Math.abs(z) / radius) * 0.5;
      mPos.setY(i, y + peakDisplacement);
    }
  }
  mountainGeo.computeVertexNormals();

  const mountainMat = MaterialPalette.createIslandBaseMaterial('crystal_canyon');
  const mountainMesh = new THREE.Mesh(mountainGeo, mountainMat);
  mountainMesh.position.y = -baseHeight / 2 + 0.2;
  mountainMesh.castShadow = true;
  mountainMesh.receiveShadow = true;
  mountainMesh.userData = { isIslandTerrain: true };
  group.add(mountainMesh);

  // 2. Multi-faceted Crystalline Canyon Surface
  const canyonCapGeo = new THREE.CylinderGeometry(radius * 0.92, radius * 0.98, 0.7, 12);
  const canyonMat = MaterialPalette.createCrystalMaterial(section.dominantColor);
  const canyonMesh = new THREE.Mesh(canyonCapGeo, canyonMat);
  canyonMesh.position.y = 0.35;
  canyonMesh.userData = { isIslandSurface: true, sectionId: section.id };
  group.add(canyonMesh);

  // 3. Monumental Jagged Geode Monoliths (Angular crystal clusters)
  const monolithCount = 7;
  for (let m = 0; m < monolithCount; m++) {
    const mAngle = (m / monolithCount) * Math.PI * 2;
    const mDist = radius * 0.72 + (m % 2) * (radius * 0.1);
    const mHeight = 4.2 + (m % 3) * 2.4;

    // 4-faceted sharp quartz obelisk
    const mGeo = new THREE.ConeGeometry(0.85 + (m % 2) * 0.3, mHeight, 4);
    const mMat = MaterialPalette.createCrystalMaterial(
      m % 2 === 0 ? section.accentColor : '#C084FC'
    );
    const mMesh = new THREE.Mesh(mGeo, mMat);

    mMesh.position.set(
      Math.cos(mAngle) * mDist,
      mHeight / 2 - 0.2,
      Math.sin(mAngle) * mDist
    );
    // Dynamic tilt angle
    mMesh.rotation.z = Math.cos(m * 1.8) * 0.35;
    mMesh.rotation.x = Math.sin(m * 1.8) * 0.25;
    mMesh.castShadow = true;
    mMesh.userData = { isDecorative: true };
    group.add(mMesh);
  }

  // 4. Floating Shattered Crystal Fragments (Drifting in updraft)
  const fragmentGroup = new THREE.Group();
  fragmentGroup.name = 'floating_crystal_shards';
  const fragCount = 8;
  for (let f = 0; f < fragCount; f++) {
    const angle = (f / fragCount) * Math.PI * 2;
    const fDist = radius * 0.85;
    const fSize = 0.35 + (f % 3) * 0.2;

    const fGeo = new THREE.DodecahedronGeometry(fSize, 0);
    const fMat = MaterialPalette.createCrystalMaterial(section.accentColor);
    const fMesh = new THREE.Mesh(fGeo, fMat);

    fMesh.position.set(
      Math.cos(angle) * fDist,
      3.2 + Math.sin(f * 2.1) * 1.2,
      Math.sin(angle) * fDist
    );
    fMesh.rotation.set(f * 0.5, f * 0.8, f * 0.3);
    fMesh.userData = { isDecorative: true, floatSpeed: 1.2 + f * 0.3 };
    fragmentGroup.add(fMesh);
  }
  group.add(fragmentGroup);

  return {
    terrainGroup: group,
    surfaceY: 0.35,
    rhythmY: 0.5,
  };
}
