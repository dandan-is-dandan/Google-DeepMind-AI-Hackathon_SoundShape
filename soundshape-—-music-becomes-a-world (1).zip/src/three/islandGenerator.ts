import * as THREE from 'three';
import { SceneSection, WorldScene } from '../types/world';
import { MaterialPalette, safeColor } from './materials';
import {
  createBassRiver,
  createEnergyCore,
  createRhythmTower,
  RhythmTowerMeshGroup,
} from './sculptures';
import {
  buildFracturedPeakTerrain,
  buildGlassSanctuaryTerrain,
  buildRhythmCityTerrain,
  determineLandscapeArchetype,
  LandscapeArchetype,
} from './landscapeArchetypes';

export interface GeneratedIsland {
  sectionId: string;
  center: THREE.Vector3;
  radius: number;
  archetype: LandscapeArchetype;
  group: THREE.Group;
  rhythmTowers: RhythmTowerMeshGroup[];
  bassRiverGroup?: THREE.Group;
  energyCoreGroup?: THREE.Group;
}

export interface GeneratedWorld {
  rootGroup: THREE.Group;
  islands: GeneratedIsland[];
  melodyRibbon: THREE.Mesh;
  particles: THREE.Points;
  playheadOrb: THREE.Mesh;
  islandPathCurve: THREE.CatmullRomCurve3;
}

/**
 * Builds the complete 3D musical landscape from the Scene specification.
 * Creates distinct procedural silhouettes, archetypes, and spatial compositions
 * based on analyzed musical features and Gemini's creative blueprint.
 */
export function buildWorldLandscape(scene: WorldScene): GeneratedWorld {
  const rootGroup = new THREE.Group();
  const islands: GeneratedIsland[] = [];
  const islandCenters: THREE.Vector3[] = [];

  const sectionCount = scene.sections.length;
  const worldTheme = scene.worldTheme || 'dreamy_ocean';

  // Calculate island positions along musical progression (Strict Left-to-Right Chronology)
  scene.sections.forEach((section, idx) => {
    const archetype = determineLandscapeArchetype(section, worldTheme);

    // 1. CHRONOLOGICAL SPATIAL LAYOUT (Requirement 5)
    // Opening is guaranteed on the far left, middle sections in center, finale on far right.
    const spacing = 28.0;
    const x = (idx - (sectionCount - 1) / 2) * spacing;

    // Deterministic regional elevation based on energy and archetype (Requirement 3 & 4)
    // Low-energy sanctuaries sit lower; rising cities step up; fractured peaks soar high.
    const baseElevation = (section.energy - 0.5) * 5.5;
    const archetypeElevationOffset =
      archetype === 'fractured_peak' ? 2.8 : archetype === 'glass_sanctuary' ? -1.5 : 0.8;
    const y = baseElevation + archetypeElevationOffset;

    // Subtle gentle depth wave that preserves left-to-right reading
    const t = sectionCount > 1 ? idx / (sectionCount - 1) : 0;
    const z = Math.sin(t * Math.PI) * 4.5 + (idx % 2 === 1 ? 1.2 : -1.2);

    const center = new THREE.Vector3(x, y, z);
    islandCenters.push(center);

    const islandGroup = new THREE.Group();
    islandGroup.position.copy(center);
    islandGroup.userData = {
      isIsland: true,
      sectionId: section.id,
      sectionIndex: idx,
      sectionData: section,
      archetype,
    };

    // Substantial island radius for strong viewport presence (7 to 11.5 units)
    const radius = 7.2 + section.energy * 3.8;

    // 2. BUILD DISTINCT PROCEDURAL TERRAIN ARCHETYPE (Requirement 2 & 4)
    let terrainSurfaceY = 0.3;
    let rhythmPlacementY = 0.4;
    let getTerraceYForRatio: ((ratio: number) => number) | undefined;

    if (archetype === 'glass_sanctuary') {
      const terrain = buildGlassSanctuaryTerrain(section, radius);
      islandGroup.add(terrain.terrainGroup);
      terrainSurfaceY = terrain.surfaceY;
      rhythmPlacementY = terrain.rhythmY;
    } else if (archetype === 'rhythm_city') {
      const terrain = buildRhythmCityTerrain(section, radius);
      islandGroup.add(terrain.terrainGroup);
      terrainSurfaceY = terrain.surfaceY;
      rhythmPlacementY = terrain.rhythmY;
      getTerraceYForRatio = terrain.getTerraceYForRatio;
    } else {
      const terrain = buildFracturedPeakTerrain(section, radius);
      islandGroup.add(terrain.terrainGroup);
      terrainSurfaceY = terrain.surfaceY;
      rhythmPlacementY = terrain.rhythmY;
    }

    // 3. Ground Playback Aura Ring (Pulses when this section is active)
    const auraGeo = new THREE.RingGeometry(radius * 0.96, radius * 1.18, 36);
    auraGeo.rotateX(-Math.PI / 2);
    const auraMat = new THREE.MeshBasicMaterial({
      color: safeColor(section.accentColor),
      transparent: true,
      opacity: 0.18,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const auraMesh = new THREE.Mesh(auraGeo, auraMat);
    auraMesh.name = 'activeAura';
    auraMesh.position.y = 0.08;
    auraMesh.userData = { isDecorative: true };
    islandGroup.add(auraMesh);

    // 4. EDITABLE MUSICAL SCULPTURES (Separated from environmental geometry - Requirement 6)
    const rhythmTowers: RhythmTowerMeshGroup[] = [];
    let bassRiverGroup: THREE.Group | undefined;
    let energyCoreGroup: THREE.Group | undefined;

    section.objects.forEach((obj) => {
      if (obj.type === 'rhythm_towers' && obj.rhythmSteps) {
        const stepCount = obj.rhythmSteps.length;
        const timelineTrackPoints: THREE.Vector3[] = [];

        obj.rhythmSteps.forEach((step, sIdx) => {
          // STRICT LEFT-TO-RIGHT TIME AXIS INSIDE ISLAND (Requirement 5)
          const stepRatio = stepCount > 1 ? sIdx / (stepCount - 1) : 0.5;
          const tx = (stepRatio - 0.5) * (radius * 1.55);

          // In Rhythm City, Y position steps up with the physical terraces
          const ty = getTerraceYForRatio
            ? getTerraceYForRatio(stepRatio) + 0.1
            : rhythmPlacementY;

          // Shallow forward arc so crystals remain fully visible and face the camera
          const tz = radius * 0.32 - Math.sin(stepRatio * Math.PI) * (radius * 0.22);
          const towerPos = new THREE.Vector3(tx, ty, tz);
          timelineTrackPoints.push(new THREE.Vector3(tx, ty + 0.02, tz));

          const tower = createRhythmTower(section.id, step, towerPos, section.accentColor);
          islandGroup.add(tower);
          rhythmTowers.push(tower);

          // Glowing tick marker disc at base
          const tickGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.04, 14);
          const tickMat = new THREE.MeshBasicMaterial({
            color: safeColor(section.accentColor),
            transparent: true,
            opacity: 0.45,
          });
          const tickMesh = new THREE.Mesh(tickGeo, tickMat);
          tickMesh.position.set(tx, ty + 0.02, tz);
          tickMesh.userData = { isDecorative: true };
          islandGroup.add(tickMesh);
        });

        // Luminous timeline conduit connecting the bases of all rhythm crystals
        if (timelineTrackPoints.length >= 2) {
          const trackCurve = new THREE.CatmullRomCurve3(timelineTrackPoints);
          const trackGeo = new THREE.TubeGeometry(trackCurve, 40, 0.06, 6, false);
          const trackMat = new THREE.MeshBasicMaterial({
            color: safeColor(section.accentColor),
            transparent: true,
            opacity: 0.55,
          });
          const trackMesh = new THREE.Mesh(trackGeo, trackMat);
          trackMesh.userData = { isDecorative: true };
          islandGroup.add(trackMesh);
        }
      } else if (obj.type === 'bass_river') {
        const riverIntensity = obj.bassIntensity !== undefined ? obj.bassIntensity : 0.6;
        bassRiverGroup = createBassRiver(
          section.id,
          new THREE.Vector3(0, terrainSurfaceY * 0.8, 0),
          radius * 0.88,
          riverIntensity,
          section.dominantColor
        );
        islandGroup.add(bassRiverGroup);
      } else if (obj.type === 'energy_core') {
        const coreEnergy = obj.energyLevel !== undefined ? obj.energyLevel : section.energy;
        // Positioned at rear-center so it never blocks rhythm crystals
        const coreElevation =
          archetype === 'fractured_peak' ? 2.5 : archetype === 'rhythm_city' ? 2.0 : 1.2;
        energyCoreGroup = createEnergyCore(
          section.id,
          new THREE.Vector3(0, terrainSurfaceY + coreElevation, -radius * 0.42),
          coreEnergy,
          section.accentColor
        );
        islandGroup.add(energyCoreGroup);
      }
    });

    rootGroup.add(islandGroup);

    islands.push({
      sectionId: section.id,
      center,
      radius,
      archetype,
      group: islandGroup,
      rhythmTowers,
      bassRiverGroup,
      energyCoreGroup,
    });
  });

  // Construct continuous pathway curve between islands
  const islandPathCurve = new THREE.CatmullRomCurve3(islandCenters);

  // 5. Luminous Energy Bridges connecting consecutive islands
  for (let i = 0; i < islandCenters.length - 1; i++) {
    const startP = islandCenters[i].clone();
    const endP = islandCenters[i + 1].clone();
    startP.y += 0.4;
    endP.y += 0.4;

    const midP = startP.clone().lerp(endP, 0.5);
    midP.y += 2.5; // High arch viaduct between regions

    const bridgeCurve = new THREE.CatmullRomCurve3([startP, midP, endP]);
    const bridgeGeo = new THREE.TubeGeometry(bridgeCurve, 28, 0.16, 8, false);
    const bridgeMat = MaterialPalette.createGlowMaterial('#62D5E8', 0.65);
    const bridgeMesh = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridgeMesh.userData = { isDecorative: true };
    rootGroup.add(bridgeMesh);
  }

  // 6. Melody Ribbon (Smooth sweeping curve traversing the entire world)
  const ribbonPoints: THREE.Vector3[] = [];
  const ribbonSteps = 80;
  for (let i = 0; i <= ribbonSteps; i++) {
    const u = i / ribbonSteps;
    const basePt = islandPathCurve.getPoint(u);
    basePt.y += 3.2 + Math.sin(u * Math.PI * 6) * 1.8;
    basePt.z += Math.cos(u * Math.PI * 4) * 3.2;
    ribbonPoints.push(basePt);
  }

  const ribbonCurve = new THREE.CatmullRomCurve3(ribbonPoints);
  const ribbonGeo = new THREE.TubeGeometry(ribbonCurve, 90, 0.16, 8, false);
  const ribbonMat = MaterialPalette.createGlassMaterial('#A58BFA', 0.85);
  const melodyRibbon = new THREE.Mesh(ribbonGeo, ribbonMat);
  melodyRibbon.userData = {
    isDecorative: true,
    name: 'Melody Ribbon',
    role: 'Melodic contour across sections (Decorative)',
  };
  rootGroup.add(melodyRibbon);

  // 7. Ambient Atmospheric Starlight Particles
  const particleCount = 280;
  const particleGeo = new THREE.BufferGeometry();
  const particlePositions = new Float32Array(particleCount * 3);

  const span = Math.max(60, sectionCount * 28.0);
  for (let i = 0; i < particleCount; i++) {
    particlePositions[i * 3] = (Math.random() - 0.5) * span * 1.3;
    particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 32.0;
    particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 45.0;
  }
  particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

  const particleMat = new THREE.PointsMaterial({
    color: new THREE.Color('#A58BFA'),
    size: 0.28,
    transparent: true,
    opacity: 0.65,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const particles = new THREE.Points(particleGeo, particleMat);
  particles.userData = {
    isDecorative: true,
    name: 'Cosmic Stardust',
    role: 'Atmospheric depth and acoustic energy particles (Decorative)',
  };
  rootGroup.add(particles);

  // 8. Glowing Playhead Orb
  const playheadGeo = new THREE.SphereGeometry(0.7, 16, 16);
  const playheadMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#FFFFFF'),
    transparent: true,
    opacity: 0.95,
  });
  const playheadOrb = new THREE.Mesh(playheadGeo, playheadMat);
  const playheadGlowGeo = new THREE.SphereGeometry(1.2, 16, 16);
  const playheadGlowMat = MaterialPalette.createGlowMaterial('#62D5E8', 0.85);
  const playheadGlow = new THREE.Mesh(playheadGlowGeo, playheadGlowMat);
  playheadOrb.add(playheadGlow);

  playheadOrb.position.copy(islandCenters[0] || new THREE.Vector3(0, 0, 0));
  rootGroup.add(playheadOrb);

  return {
    rootGroup,
    islands,
    melodyRibbon,
    particles,
    playheadOrb,
    islandPathCurve,
  };
}
