import React, { useState } from 'react';
import { Upload, Sparkles, Compass, Sliders, Volume2, X, ArrowRight, Check, Play } from 'lucide-react';

interface DifferentiationDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadCosmic: () => void;
  onLoadCyber: () => void;
  onSelectSampleTower: () => void;
  onCompareCurrentMoment: () => void;
}

export const DifferentiationDemoModal: React.FC<DifferentiationDemoModalProps> = ({
  isOpen,
  onClose,
  onLoadCosmic,
  onLoadCyber,
  onSelectSampleTower,
  onCompareCurrentMoment,
}) => {
  const [currentStep, setCurrentStep] = useState(1);

  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      title: 'Step 1 — Upload or Choose Track',
      badge: 'Music Input',
      icon: Upload,
      description:
        'Upload any 15–30s MP3/WAV song, or pick from two contrasting tracks to immediately see two completely different 3D worlds generated.',
      actionLabel: 'Load Cosmic Aurora (Dreamy)',
      altActionLabel: 'Load Cyber Pulse Apex (Aggressive)',
      action: () => {
        onLoadCosmic();
        setCurrentStep(2);
      },
      altAction: () => {
        onLoadCyber();
        setCurrentStep(2);
      },
    },
    {
      step: 2,
      title: 'Step 2 — Gemini Scene Generation',
      badge: 'Multimodal AI',
      icon: Sparkles,
      description:
        'Gemini analyzes tempo, spectral transients, and energy curvature to determine the world theme, regional island shapes, and procedural arrangements.',
      actionLabel: 'Inspect 3D World Landscape',
      action: () => {
        setCurrentStep(3);
      },
    },
    {
      step: 3,
      title: 'Step 3 — Explain Musical Meaning',
      badge: 'Acoustic Mapping',
      icon: Compass,
      description:
        'Click an island to enter Section View, then click a Rhythm Tower. The Object Inspector reveals the exact audio timestamp, measured energy, and acoustic rationale.',
      actionLabel: 'Select Rhythm Tower in Section 1',
      action: () => {
        onSelectSampleTower();
        setCurrentStep(4);
      },
    },
    {
      step: 4,
      title: 'Step 4 — Direct 3D Sculptural Music Editing',
      badge: 'Interactive Synthesis',
      icon: Sliders,
      description:
        'Drag the crystalline handle vertically in 3D or adjust the slider. Dragging directly modulates synthesized drum hit velocity and punch without fake visual-only mockups.',
      actionLabel: 'Hear Edited Sound Change',
      action: () => {
        setCurrentStep(5);
      },
    },
    {
      step: 5,
      title: 'Step 5 — Compare Original vs Edited',
      badge: 'A/B Listening',
      icon: Volume2,
      description:
        'Listen to the original uploaded recording alone, then switch to Edited SoundShape to hear the synthesized accompaniment layers perfectly aligned.',
      actionLabel: 'Compare This Moment (Original vs Edited)',
      action: () => {
        onCompareCurrentMoment();
      },
    },
  ];

  const active = steps[currentStep - 1];
  const IconComponent = active.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl rounded-2xl bg-[#0B1020] border border-white/10 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-white/5 bg-[#111A30]/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#62D5E8] to-[#FFB66E] p-0.5 shadow-md flex items-center justify-center">
              <div className="w-full h-full bg-[#0B1020] rounded-[10px] flex items-center justify-center">
                <Play className="w-4 h-4 text-[#62D5E8]" />
              </div>
            </div>
            <div>
              <h2 className="text-sm font-bold text-white font-['Space_Grotesk']">
                30-Second Differentiation Journey
              </h2>
              <p className="text-[11px] text-[#93A4BE]">
                Understand how SoundShape transforms music into an editable 3D world
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator Pills */}
        <div className="px-5 pt-4 pb-2 border-b border-white/5 flex items-center justify-between gap-1 bg-[#0E1527]">
          {steps.map((s) => (
            <button
              key={s.step}
              onClick={() => setCurrentStep(s.step)}
              className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] font-mono font-medium transition-all flex items-center justify-center gap-1.5 ${
                currentStep === s.step
                  ? 'bg-[#62D5E8]/20 text-[#62D5E8] border border-[#62D5E8]/40'
                  : currentStep > s.step
                  ? 'bg-white/5 text-white/80'
                  : 'text-[#93A4BE]/50'
              }`}
            >
              <span>{s.step}</span>
              {currentStep > s.step && <Check className="w-3 h-3 text-[#62D5E8]" />}
            </button>
          ))}
        </div>

        {/* Step Content */}
        <div className="p-6 space-y-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#111A30] border border-white/10 flex items-center justify-center shrink-0 text-[#62D5E8]">
              <IconComponent className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wide bg-[#62D5E8]/10 text-[#62D5E8] border border-[#62D5E8]/20 inline-block">
                {active.badge}
              </span>
              <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                {active.title}
              </h3>
              <p className="text-xs text-[#93A4BE] leading-relaxed">
                {active.description}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-white/5 flex flex-col sm:flex-row gap-2">
            <button
              onClick={active.action}
              className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#62D5E8] to-[#A58BFA] text-[#0B1020] font-semibold text-xs flex items-center justify-center gap-2 hover:opacity-95 transition-opacity shadow-lg shadow-[#62D5E8]/20"
            >
              <span>{active.actionLabel}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {active.altAction && active.altActionLabel && (
              <button
                onClick={active.altAction}
                className="py-2.5 px-3 rounded-xl bg-[#111A30] border border-white/10 text-white font-medium text-xs hover:bg-white/5 transition-colors"
              >
                {active.altActionLabel}
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/5 bg-[#111A30]/40 flex items-center justify-between text-xs text-[#93A4BE]">
          <span>Step {currentStep} of 5</span>
          <button
            onClick={onClose}
            className="hover:text-white transition-colors"
          >
            Explore Manually
          </button>
        </div>
      </div>
    </div>
  );
};
