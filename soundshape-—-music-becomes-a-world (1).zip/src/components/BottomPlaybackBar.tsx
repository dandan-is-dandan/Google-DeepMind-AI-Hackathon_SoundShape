import React from 'react';
import { EditScope, LAYER_CONFIGS, MultiLayerEdit, MusicalLayerType, WorldEditState, WorldScene } from '../types/world';
import { Play, Pause, RotateCcw, Volume2, Sparkles, Headphones, Compass, Layers } from 'lucide-react';
import { formatTimestamp } from '../audio/metadataEnricher';

interface BottomPlaybackBarProps {
  scene: WorldScene | null;
  editState?: WorldEditState;
  playbackTime: number;
  duration: number;
  isPlaying: boolean;
  isEditedMode: boolean;
  volume: number;
  selectedTimestamp: number | null;
  selectedSectionId: string | null;
  activeLayer?: MusicalLayerType;
  editScope?: EditScope;
  momentDuration?: number;
  multiLayerEdits?: MultiLayerEdit[];
  followMusicMode: boolean;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onToggleEditedMode: () => void;
  onVolumeChange: (vol: number) => void;
  onRestart: () => void;
  onToggleFollowMusic: () => void;
  onListenToMoment: (timestamp: number) => void;
  onSelectElement?: (sectionId: string, stepIndex: number) => void;
  onSelectTime?: (time: number) => void;
}

export const BottomPlaybackBar: React.FC<BottomPlaybackBarProps> = ({
  scene,
  editState,
  playbackTime,
  duration,
  isPlaying,
  isEditedMode,
  volume,
  selectedTimestamp,
  selectedSectionId,
  activeLayer = 'energy',
  editScope = 'moment',
  momentDuration = 0.5,
  multiLayerEdits = [],
  followMusicMode,
  onTogglePlay,
  onSeek,
  onToggleEditedMode,
  onVolumeChange,
  onRestart,
  onToggleFollowMusic,
  onListenToMoment,
  onSelectElement,
  onSelectTime,
}) => {
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (duration <= 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const progress = Math.max(0, Math.min(1, clickX / rect.width));
    const targetTime = progress * duration;
    onSeek(targetTime);
    onSelectTime?.(targetTime);
  };

  const progressPercent = duration > 0 ? (playbackTime / duration) * 100 : 0;

  // Flatten all rhythm events across sections for timeline markers (Requirement 6)
  const timelineEvents: {
    sectionId: string;
    stepIndex: number;
    time: number;
    type: string;
    intensity: number;
    isEdited: boolean;
    isSelected: boolean;
  }[] = [];

  if (scene && duration > 0) {
    scene.sections.forEach((sec) => {
      const rhythmObj = sec.objects.find((o) => o.type === 'rhythm_towers');
      if (rhythmObj && rhythmObj.rhythmSteps) {
        const secEdit = editState?.[sec.id];
        rhythmObj.rhythmSteps.forEach((step) => {
          const stepEdit = secEdit?.rhythmSteps.find((s) => s.index === step.index);
          const t =
            step.eventTimeSeconds ?? sec.start + step.timeRatio * (sec.end - sec.start);
          const isSelected =
            selectedTimestamp !== null && Math.abs(t - selectedTimestamp) < 0.12;
          const isEdited =
            stepEdit !== undefined &&
            (Math.abs(stepEdit.intensity - (step.originalParameter ?? step.intensity)) > 0.02 ||
              !stepEdit.active);

          timelineEvents.push({
            sectionId: sec.id,
            stepIndex: step.index,
            time: t,
            type: stepEdit?.type || step.type,
            intensity: stepEdit?.intensity ?? step.intensity,
            isEdited,
            isSelected,
          });
        });
      }
    });
  }

  // Highlighted Time Range Window (Prompt 4, Req 2 & 3)
  let highlightRange: {
    start: number;
    end: number;
    startPct: number;
    widthPct: number;
    label: string;
    durationStr: string;
    color: string;
  } | null = null;

  if (selectedTimestamp !== null && duration > 0) {
    const layerColor = LAYER_CONFIGS[activeLayer]?.color || '#62D5E8';
    if (editScope === 'moment') {
      const dur = Math.max(0.2, Math.min(2.0, momentDuration));
      const start = Math.max(0, selectedTimestamp - dur / 2);
      const end = Math.min(duration, start + dur);
      const startPct = (start / duration) * 100;
      const widthPct = Math.max(0.8, ((end - start) / duration) * 100);
      highlightRange = {
        start,
        end,
        startPct,
        widthPct,
        label: `${LAYER_CONFIGS[activeLayer]?.label || 'Layer'} Moment`,
        durationStr: `${Math.round((end - start) * 1000)}ms`,
        color: layerColor,
      };
    } else {
      // Section scope
      const sec = scene?.sections.find(
        (s) => s.id === selectedSectionId || (selectedTimestamp >= s.start && selectedTimestamp <= s.end)
      );
      if (sec) {
        const start = sec.start;
        const end = sec.end;
        const startPct = (start / duration) * 100;
        const widthPct = ((end - start) / duration) * 100;
        highlightRange = {
          start,
          end,
          startPct,
          widthPct,
          label: `${sec.label} (${LAYER_CONFIGS[activeLayer]?.label})`,
          durationStr: `${(end - start).toFixed(1)}s`,
          color: layerColor,
        };
      }
    }
  }

  return (
    <footer className="h-20 px-6 border-t border-white/5 bg-[#0B1020]/95 flex flex-col justify-center shrink-0 z-30 select-none">
      {/* Musical Timeline Bar with Sections, Event Dots & Edited Markers (Requirement 6) */}
      <div
        className="relative w-full h-6 mb-1 cursor-pointer group flex items-center"
        onClick={handleTimelineClick}
      >
        {/* Background track */}
        <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden relative group-hover:h-2.5 transition-all">
          {/* Section divisions (strictly chronological left to right) */}
          {scene &&
            scene.sections.map((sec) => {
              const startPct = (sec.start / duration) * 100;
              const widthPct = ((sec.end - sec.start) / duration) * 100;
              const isCurrentSection = selectedSectionId === sec.id;
              return (
                <div
                  key={sec.id}
                  className={`absolute top-0 bottom-0 border-r border-white/20 transition-opacity ${
                    isCurrentSection ? 'opacity-90 ring-1 ring-[#62D5E8]' : 'opacity-40'
                  }`}
                  style={{
                    left: `${startPct}%`,
                    width: `${widthPct}%`,
                    backgroundColor: `${sec.dominantColor}45`,
                  }}
                  title={`${sec.label} (${sec.start.toFixed(1)}s - ${sec.end.toFixed(1)}s)`}
                />
              );
            })}

          {/* Stored Multi-Layer Edit Lines on Track */}
          {multiLayerEdits.map((e) => {
            const leftPct = (e.startTime / duration) * 100;
            const widthPct = Math.max(0.6, ((e.endTime - e.startTime) / duration) * 100);
            const color = LAYER_CONFIGS[e.layer]?.color || '#A58BFA';
            return (
              <div
                key={`track_edit_${e.editId}`}
                className="absolute top-0 bottom-0 pointer-events-none"
                style={{
                  left: `${leftPct}%`,
                  width: `${widthPct}%`,
                  backgroundColor: `${color}80`,
                }}
              />
            );
          })}

          {/* Filled playback progress */}
          <div
            className="h-full bg-gradient-to-r from-[#62D5E8] via-[#A58BFA] to-[#FFB66E] transition-[width] duration-75 relative"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Highlighted Time Range Window (Prompt 4, Req 2 & 3) */}
        {highlightRange && (
          <div
            className="absolute -top-1 -bottom-1 pointer-events-none rounded-md border-2 transition-all z-20"
            style={{
              left: `${highlightRange.startPct}%`,
              width: `${highlightRange.widthPct}%`,
              backgroundColor: `${highlightRange.color}35`,
              borderColor: highlightRange.color,
              boxShadow: `0 0 16px ${highlightRange.color}70`,
            }}
          >
            {/* Range Badge hovering above */}
            <div
              className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold whitespace-nowrap shadow-2xl flex items-center gap-1.5 border"
              style={{
                backgroundColor: '#0B1020',
                borderColor: highlightRange.color,
                color: '#FFFFFF',
              }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full animate-ping"
                style={{ backgroundColor: highlightRange.color }}
              />
              <span>{highlightRange.label}</span>
              <span className="opacity-75 font-normal" style={{ color: highlightRange.color }}>
                {highlightRange.durationStr}
              </span>
            </div>
          </div>
        )}

        {/* All Rhythm Event Markers on the Timeline (Requirement 6) */}
        {timelineEvents.map((evt) => {
          const evtPct = (evt.time / duration) * 100;

          // Case 1: Selected Object Marker (Prominent glowing diamond + badge)
          if (evt.isSelected) {
            return (
              <div
                key={`sel_${evt.sectionId}_${evt.stepIndex}`}
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-30 pointer-events-none flex flex-col items-center"
                style={{ left: `${evtPct}%` }}
              >
                <div className="w-3 h-3 rotate-45 bg-[#62D5E8] shadow-lg shadow-[#62D5E8]/90 border border-white" />
                <span className="absolute -top-6 whitespace-nowrap px-1.5 py-0.5 rounded bg-[#111A30] text-[10px] font-mono font-bold text-[#62D5E8] border border-[#62D5E8]/50 shadow-xl">
                  {formatTimestamp(evt.time)}
                </span>
              </div>
            );
          }

          // Case 2: Edited Object Marker (Purple/amber glowing dot)
          if (evt.isEdited) {
            return (
              <button
                key={`edit_${evt.sectionId}_${evt.stepIndex}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onSeek(evt.time);
                  onSelectElement?.(evt.sectionId, evt.stepIndex);
                }}
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20 w-2.5 h-2.5 rounded-full bg-[#C084FC] border border-white shadow-md shadow-[#C084FC]/80 hover:scale-150 transition-transform cursor-pointer"
                style={{ left: `${evtPct}%` }}
                title={`Edited ${evt.type} at ${formatTimestamp(evt.time)} (Click to inspect)`}
              />
            );
          }

          // Case 3: Default Rhythm Event Marker (Clean subtle dot)
          return (
            <button
              key={`dot_${evt.sectionId}_${evt.stepIndex}`}
              onClick={(e) => {
                e.stopPropagation();
                onSeek(evt.time);
                onSelectElement?.(evt.sectionId, evt.stepIndex);
              }}
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-10 w-1.5 h-1.5 rounded-full bg-white/40 hover:bg-white hover:scale-150 transition-all cursor-pointer"
              style={{ left: `${evtPct}%` }}
              title={`${evt.type} at ${formatTimestamp(evt.time)} (Click to select)`}
            />
          );
        })}

        {/* Live Playhead Scrubber Handle */}
        <div
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-white shadow-md shadow-white/50 border border-[#62D5E8] pointer-events-none transition-[left] duration-75 z-25"
          style={{ left: `${progressPercent}%` }}
        />
      </div>

      {/* Control Strip */}
      <div className="flex items-center justify-between text-xs">
        {/* Left: Playback buttons, Time, and Listen to Moment */}
        <div className="flex items-center gap-3">
          <button
            onClick={onRestart}
            className="p-1.5 rounded-lg text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors"
            title="Restart playback"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            disabled={duration <= 0}
            className="px-4 py-1.5 rounded-lg bg-[#62D5E8] text-[#0B1020] hover:bg-[#62D5E8]/90 font-semibold flex items-center gap-2 transition-all disabled:opacity-50 shadow-md shadow-[#62D5E8]/20"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
            <span>{isPlaying ? 'Pause' : 'Play Music'}</span>
          </button>

          <div className="font-mono text-[#93A4BE] text-xs">
            <span className="text-white">{formatTime(playbackTime)}</span>
            <span className="mx-1">/</span>
            <span>{formatTime(duration)}</span>
          </div>

          {/* Quick "Listen to Moment" Button */}
          {selectedTimestamp !== null && (
            <button
              onClick={() => onListenToMoment(selectedTimestamp)}
              className="px-2.5 py-1 rounded-lg bg-[#111A30] hover:bg-[#111A30]/80 border border-[#62D5E8]/40 text-xs font-medium text-[#62D5E8] flex items-center gap-1.5 transition-colors shadow-sm"
              title="Play 2 seconds of original recording around selected sculpture"
            >
              <Headphones className="w-3.5 h-3.5" />
              <span>Moment ({formatTimestamp(selectedTimestamp)})</span>
            </button>
          )}
        </div>

        {/* Center: Original vs Edited Mode Switch */}
        <div className="flex items-center p-1 rounded-xl bg-[#111A30] border border-white/10 shadow-inner">
          <button
            onClick={() => {
              if (isEditedMode) onToggleEditedMode();
            }}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              !isEditedMode
                ? 'bg-white/15 text-white shadow-sm'
                : 'text-[#93A4BE] hover:text-white'
            }`}
          >
            Original Audio
          </button>

          <button
            onClick={() => {
              if (!isEditedMode) onToggleEditedMode();
            }}
            className={`px-3.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isEditedMode
                ? 'bg-gradient-to-r from-[#62D5E8] to-[#A58BFA] text-[#0B1020] shadow-sm'
                : 'text-[#93A4BE] hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Edited SoundShape</span>
          </button>
        </div>

        {/* Right: Follow Music Mode Toggle & Master Volume */}
        <div className="flex items-center gap-3">
          {/* Follow-the-Music Mode Toggle */}
          <button
            onClick={onToggleFollowMusic}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 border ${
              followMusicMode
                ? 'bg-[#111A30] border-[#62D5E8] text-[#62D5E8] shadow-sm'
                : 'border-white/5 text-[#93A4BE] hover:text-white hover:bg-white/5'
            }`}
            title="Automatically center camera on the currently playing musical section"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Follow Music</span>
          </button>

          {/* Master Volume */}
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-[#93A4BE]" />
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(volume * 100)}
              onChange={(e) => onVolumeChange(Number(e.target.value) / 100)}
              className="w-16 accent-[#62D5E8]"
              title="Master Volume"
            />
            <span className="font-mono text-[11px] text-[#93A4BE] w-7">
              {Math.round(volume * 100)}%
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
