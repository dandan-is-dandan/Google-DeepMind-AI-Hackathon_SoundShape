import React, { useRef } from 'react';
import { SceneSection, WorldScene } from '../types/world';
import { Upload, Music, Sparkles, Activity, Play, Pause } from 'lucide-react';

interface LeftSidebarProps {
  scene: WorldScene | null;
  filename: string;
  duration: number;
  tempo: number;
  isPlaying: boolean;
  selectedSectionId: string | null;
  onFileUpload: (file: File) => void;
  onLoadSample: (type?: 'cosmic' | 'cyber') => void;
  onSelectSection: (sectionId: string) => void;
  onTogglePlay: () => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  scene,
  filename,
  duration,
  tempo,
  isPlaying,
  selectedSectionId,
  onFileUpload,
  onLoadSample,
  onSelectSection,
  onTogglePlay,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileUpload(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && (file.type.includes('audio') || file.name.endsWith('.mp3') || file.name.endsWith('.wav'))) {
      onFileUpload(file);
    }
  };

  return (
    <aside className="w-72 h-full border-r border-white/5 bg-[#0B1020]/90 backdrop-blur-md flex flex-col shrink-0 select-none overflow-y-auto">
      {/* File Upload / Source Area */}
      <div className="p-4 border-b border-white/5">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-[#93A4BE] mb-3">
          Music Source
        </h2>

        {/* Drop zone */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className="border border-dashed border-white/15 hover:border-[#62D5E8]/60 bg-[#111A30]/50 hover:bg-[#111A30]/80 rounded-xl p-3.5 text-center cursor-pointer transition-all duration-200 group"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/mp3,audio/wav,audio/mpeg,audio/wave"
            onChange={handleFileChange}
            className="hidden"
          />
          <Upload className="w-5 h-5 mx-auto text-[#62D5E8] mb-1.5 group-hover:scale-110 transition-transform" />
          <p className="text-xs font-medium text-white">Upload Audio</p>
          <p className="text-[11px] text-[#93A4BE] mt-0.5">MP3 or WAV · 15–30s</p>
        </div>

        {/* Sample Demo Buttons */}
        <div className="space-y-1.5 mt-2.5">
          <p className="text-[10px] font-mono text-[#93A4BE]">CONTRASTING DEMO TRACKS:</p>
          <button
            onClick={() => onLoadSample('cosmic')}
            className="w-full py-2 px-3 rounded-lg bg-gradient-to-r from-[#62D5E8]/15 to-[#A58BFA]/15 border border-white/10 hover:border-[#62D5E8]/50 text-xs font-medium text-white flex items-center justify-between transition-all hover:bg-white/5"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span>Cosmic Aurora</span>
            </div>
            <span className="text-[10px] font-mono text-[#62D5E8]">Dreamy · 124 BPM</span>
          </button>

          <button
            onClick={() => onLoadSample('cyber')}
            className="w-full py-2 px-3 rounded-lg bg-gradient-to-r from-[#EC4899]/15 to-[#8B5CF6]/15 border border-white/10 hover:border-[#EC4899]/50 text-xs font-medium text-white flex items-center justify-between transition-all hover:bg-white/5"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />
              <span>Cyber Pulse Apex</span>
            </div>
            <span className="text-[10px] font-mono text-[#EC4899]">Aggressive · 148 BPM</span>
          </button>
        </div>
      </div>

      {/* Track Info */}
      {duration > 0 && (
        <div className="p-4 border-b border-white/5 bg-[#111A30]/30">
          <div className="flex items-start justify-between gap-2">
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-white truncate" title={filename}>
                {filename || 'Untitled Audio'}
              </p>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-[#93A4BE] font-mono">
                <span>{duration.toFixed(1)}s</span>
                <span>·</span>
                <span>~{tempo} BPM</span>
              </div>
            </div>
            <button
              onClick={onTogglePlay}
              className="p-2 rounded-lg bg-[#62D5E8] text-[#0B1020] hover:bg-[#62D5E8]/90 transition-colors shadow-sm"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
            </button>
          </div>
        </div>
      )}

      {/* Musical Sections Navigator */}
      {scene && scene.sections.length > 0 && (
        <div className="p-4 flex-1">
          <div className="flex items-center justify-between mb-2.5">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-[#93A4BE]">
              Musical Landscape
            </h2>
            <span className="text-[11px] text-[#93A4BE] font-mono">
              {scene.sections.length} Islands
            </span>
          </div>

          <div className="space-y-2">
            {scene.sections.map((section: SceneSection, idx: number) => {
              const isSelected = selectedSectionId === section.id;
              return (
                <button
                  key={section.id}
                  onClick={() => onSelectSection(section.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all text-xs ${
                    isSelected
                      ? 'bg-[#111A30] border-[#62D5E8] shadow-md shadow-[#62D5E8]/10'
                      : 'bg-[#111A30]/40 border-white/5 hover:border-white/15 hover:bg-[#111A30]/70'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-white flex items-center gap-1.5">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: section.dominantColor }}
                      />
                      {section.label}
                    </span>
                    <span className="font-mono text-[10px] text-[#93A4BE]">
                      {section.start.toFixed(1)}s - {section.end.toFixed(1)}s
                    </span>
                  </div>

                  <p className="text-[11px] text-[#93A4BE] line-clamp-1 mb-2">
                    {section.mood}
                  </p>

                  {/* Energy bar */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-[#93A4BE] font-mono">Energy</span>
                    <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${Math.round(section.energy * 100)}%`,
                          backgroundColor: section.accentColor,
                        }}
                      />
                    </div>
                    <span className="text-[10px] font-mono text-white/80">
                      {Math.round(section.energy * 100)}%
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Theme & Rationale */}
          <div className="mt-5 p-3 rounded-xl bg-[#111A30]/30 border border-white/5">
            <div className="flex items-center gap-1.5 text-xs font-medium text-white mb-1">
              <Activity className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span className="capitalize">{scene.worldTheme.replace('_', ' ')}</span>
            </div>
            <p className="text-[11px] text-[#93A4BE] leading-relaxed">
              {scene.creativeRationale}
            </p>
          </div>
        </div>
      )}
    </aside>
  );
};
