import React from 'react';
import { AIAnalysisStatus, ViewMode, WorldScene } from '../types/world';
import { Sparkles, Globe, Layers, Disc3, Maximize2, Minimize2, RotateCcw, Activity, ShieldCheck, AlertTriangle } from 'lucide-react';

interface HeaderProps {
  scene: WorldScene | null;
  viewMode: ViewMode;
  selectedSectionId: string | null;
  selectedStepIndex: number | null;
  aiStatus: AIAnalysisStatus;
  modelUsed: string;
  isCinemaMode: boolean;
  onSetViewMode: (mode: ViewMode, sectionId?: string) => void;
  onToggleCinemaMode: () => void;
  onResetWorld: () => void;
  onOpenBlueprint?: () => void;
  onOpenDemo?: () => void;
  onOpenAudioTests?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  scene,
  viewMode,
  selectedSectionId,
  selectedStepIndex,
  aiStatus,
  modelUsed,
  isCinemaMode,
  onSetViewMode,
  onToggleCinemaMode,
  onResetWorld,
  onOpenBlueprint,
  onOpenDemo,
  onOpenAudioTests,
}) => {
  const isSceneVerified =
    scene?.verificationReport?.allPassed === true &&
    (scene.verificationReport.checks ? scene.verificationReport.checks.every((c) => c.passed) : true);
  const currentSection = scene?.sections.find((s) => s.id === selectedSectionId);

  return (
    <header className="h-14 px-6 border-b border-white/5 bg-[#0B1020]/95 flex items-center justify-between gap-6 shrink-0 z-30 select-none">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#62D5E8] via-[#A58BFA] to-[#FFB66E] flex items-center justify-center p-0.5 shadow-md shadow-[#62D5E8]/10">
          <div className="w-full h-full bg-[#0B1020] rounded-[6px] flex items-center justify-center">
            <Disc3 className="w-4 h-4 text-[#62D5E8] animate-spin-slow" />
          </div>
        </div>
        <div className="flex flex-col">
          <div className="flex items-baseline gap-2">
            <span className="text-base font-bold tracking-tight text-white font-['Space_Grotesk']">
              SoundShape
            </span>
            <span className="text-xs text-[#93A4BE] hidden sm:inline">
              Music Becomes a World
            </span>
          </div>
        </div>
      </div>

      {/* Zone 2: Navigation Breadcrumbs */}
      <div className="flex items-center gap-1.5 text-xs font-medium">
        <button
          onClick={() => onSetViewMode('world')}
          className={`px-2.5 py-1 rounded-md transition-colors flex items-center gap-1.5 ${
            viewMode === 'world'
              ? 'bg-[#111A30] text-[#62D5E8] border border-[#62D5E8]/30 shadow-sm'
              : 'text-[#93A4BE] hover:text-white'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>World</span>
        </button>

        {currentSection && (
          <>
            <span className="text-white/20">/</span>
            <button
              onClick={() => onSetViewMode('section', currentSection.id)}
              className={`px-2.5 py-1 rounded-md transition-colors flex items-center gap-1.5 ${
                viewMode === 'section'
                  ? 'bg-[#111A30] text-[#A58BFA] border border-[#A58BFA]/30 shadow-sm'
                  : 'text-[#93A4BE] hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{currentSection.label}</span>
            </button>
          </>
        )}

        {viewMode === 'element' && selectedStepIndex !== null && (
          <>
            <span className="text-white/20">/</span>
            <div className="px-2.5 py-1 rounded-md bg-[#111A30] text-[#FFB66E] border border-[#FFB66E]/30 font-mono text-[11px]">
              Rhythm Tower #{selectedStepIndex + 1}
            </div>
          </>
        )}
      </div>

      {/* Zone 3: Actions & Honest AI Status */}
      <div className="flex items-center gap-2.5 shrink-0">
        {/* 30-Second Differentiation Tour Trigger */}
        {onOpenDemo && (
          <button
            onClick={onOpenDemo}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#62D5E8]/10 via-[#A58BFA]/10 to-[#FFB66E]/10 border border-white/10 hover:border-white/25 text-xs font-medium text-white transition-all shadow-sm"
            title="Launch 30-Second Differentiation Tour"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#62D5E8]" />
            <span>30s Tour</span>
          </button>
        )}

        {/* DSP Tests Trigger */}
        {onOpenAudioTests && (
          <button
            onClick={onOpenAudioTests}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#111A30] border border-white/10 hover:border-[#62D5E8]/40 text-xs font-medium text-[#62D5E8] transition-all shadow-sm"
            title="Run OfflineAudioContext automated DSP pipeline tests"
          >
            <Activity className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">DSP Tests</span>
          </button>
        )}

        {/* Real AI Engine Status Indicator / Blueprint Inspector Trigger */}
        <button
          onClick={onOpenBlueprint}
          disabled={!scene}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs transition-all ${
            scene
              ? 'bg-[#111A30] border-white/10 hover:border-[#62D5E8]/50 cursor-pointer shadow-sm'
              : 'bg-[#111A30]/50 border-white/5 cursor-default'
          }`}
          title={scene ? 'Click to inspect Gemini Scene Blueprint & Acoustic Decisions' : undefined}
        >
          {aiStatus === 'requesting_gemini' || aiStatus === 'extracting_features' ? (
            <>
              <div className="w-2 h-2 rounded-full bg-[#62D5E8] animate-ping" />
              <span className="text-[#62D5E8] font-mono text-[11px]">Analyzing with Gemini</span>
            </>
          ) : aiStatus === 'gemini_complete' ? (
            <>
              <Sparkles className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span className="text-[#EAF2FF] font-medium text-[11px]">
                {modelUsed === 'gemini-4-argon' ? 'Gemini 4 Argon' : 'Gemini 3.8 Flash'}
              </span>
              {isSceneVerified ? (
                <span className="text-[10px] font-mono text-[#62D5E8] bg-[#62D5E8]/10 px-1.5 py-0.5 rounded flex items-center gap-1 border border-[#62D5E8]/20">
                  <ShieldCheck className="w-3 h-3 text-[#62D5E8]" />
                  <span>Verified</span>
                </span>
              ) : (
                <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded flex items-center gap-1 border border-amber-500/20">
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>Unverified</span>
                </span>
              )}
            </>
          ) : aiStatus === 'local_only' ? (
            <>
              <div className="w-2 h-2 rounded-full bg-[#FFB66E]" />
              <span className="text-[#FFB66E] font-medium text-[11px]">Local Engine</span>
              <span className="text-[10px] font-mono text-[#FFB66E] bg-[#FFB66E]/10 px-1 py-0.2 rounded hidden lg:inline">
                Blueprint
              </span>
            </>
          ) : aiStatus === 'gemini_failed' ? (
            <>
              <div className="w-2 h-2 rounded-full bg-red-400" />
              <span className="text-red-300 font-medium text-[11px]">Local Fallback</span>
            </>
          ) : (
            <span className="text-[#93A4BE] text-[11px]">Awaiting Music</span>
          )}
        </button>

        {/* Reset World */}
        {scene && (
          <button
            onClick={onResetWorld}
            title="Reset World Edits"
            className="p-1.5 rounded-md text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        )}

        {/* Cinema / Zen Mode Toggle */}
        <button
          onClick={onToggleCinemaMode}
          title={isCinemaMode ? 'Exit Full View' : 'Cinema / Full World View'}
          className="p-1.5 rounded-md text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors"
        >
          {isCinemaMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};
