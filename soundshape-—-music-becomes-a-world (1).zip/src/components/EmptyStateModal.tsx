import React from 'react';
import { AIAnalysisStatus } from '../types/world';
import { Disc3, Sparkles, Upload, Loader2, AlertTriangle, RefreshCw } from 'lucide-react';

interface EmptyStateModalProps {
  status: AIAnalysisStatus;
  errorMessage: string | null;
  onOpenUpload: () => void;
  onLoadSample: (type?: 'cosmic' | 'cyber') => void;
  onRetryGemini: () => void;
  onUseLocalFallback: () => void;
}

export const EmptyStateModal: React.FC<EmptyStateModalProps> = ({
  status,
  errorMessage,
  onOpenUpload,
  onLoadSample,
  onRetryGemini,
  onUseLocalFallback,
}) => {
  const isLoading =
    status === 'decoding' ||
    status === 'extracting_features' ||
    status === 'requesting_gemini' ||
    status === 'validating_scene' ||
    status === 'building_world';

  const isFailed = status === 'gemini_failed';

  // If ready or in full experience without errors, don't show modal
  if (status === 'gemini_complete' || status === 'local_only') {
    return null;
  }

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-6 bg-[#0B1020]/80 backdrop-blur-md select-none">
      <div className="max-w-md w-full p-8 rounded-3xl bg-[#111A30]/95 border border-white/10 shadow-2xl text-center relative overflow-hidden">
        {/* Glow accent */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#62D5E8]/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-[#A58BFA]/20 rounded-full blur-3xl pointer-events-none" />

        {/* LOADING STATE */}
        {isLoading && (
          <div className="space-y-6 py-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-[#0B1020] border border-[#62D5E8]/30 flex items-center justify-center shadow-lg shadow-[#62D5E8]/10">
              <Loader2 className="w-8 h-8 text-[#62D5E8] animate-spin" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-white mb-2 font-['Space_Grotesk']">
                Generating Your Music World
              </h3>
              <p className="text-xs text-[#93A4BE]">
                Transforming acoustic signals into 3D crystalline landscape
              </p>
            </div>

            {/* Honest Pipeline Steps */}
            <div className="space-y-2 text-left bg-[#0B1020]/60 p-4 rounded-2xl border border-white/5 text-xs">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-2 h-2 rounded-full ${
                    status === 'decoding'
                      ? 'bg-[#62D5E8] animate-ping'
                      : 'bg-[#62D5E8]'
                  }`}
                />
                <span className={status === 'decoding' ? 'text-white font-medium' : 'text-[#93A4BE]'}>
                  1. Reading & decoding audio waveform
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <div
                  className={`w-2 h-2 rounded-full ${
                    status === 'extracting_features'
                      ? 'bg-[#62D5E8] animate-ping'
                      : status === 'requesting_gemini' || status === 'building_world'
                      ? 'bg-[#62D5E8]'
                      : 'bg-white/20'
                  }`}
                />
                <span
                  className={
                    status === 'extracting_features'
                      ? 'text-white font-medium'
                      : 'text-[#93A4BE]'
                  }
                >
                  2. Extracting RMS, spectral frequencies & onsets
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <div
                  className={`w-2 h-2 rounded-full ${
                    status === 'requesting_gemini'
                      ? 'bg-[#A58BFA] animate-ping'
                      : status === 'building_world'
                      ? 'bg-[#62D5E8]'
                      : 'bg-white/20'
                  }`}
                />
                <span
                  className={
                    status === 'requesting_gemini'
                      ? 'text-white font-medium'
                      : 'text-[#93A4BE]'
                  }
                >
                  3. Interpreting musical geometry with Gemini
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <div
                  className={`w-2 h-2 rounded-full ${
                    status === 'building_world' ? 'bg-[#FFB66E] animate-ping' : 'bg-white/20'
                  }`}
                />
                <span
                  className={
                    status === 'building_world' ? 'text-white font-medium' : 'text-[#93A4BE]'
                  }
                >
                  4. Building 3D procedural landscape & sculptures
                </span>
              </div>
            </div>
          </div>
        )}

        {/* FAILED STATE */}
        {isFailed && (
          <div className="space-y-5 py-2">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-base font-bold text-white mb-1.5 font-['Space_Grotesk']">
                Gemini Analysis Notice
              </h3>
              <p className="text-xs text-[#93A4BE] leading-relaxed">
                {errorMessage || 'Unable to connect to Gemini API.'}
              </p>
            </div>

            <div className="space-y-2.5 pt-2">
              <button
                onClick={onUseLocalFallback}
                className="w-full py-2.5 px-4 rounded-xl bg-[#62D5E8] hover:bg-[#62D5E8]/90 text-[#0B1020] text-xs font-semibold shadow-md transition-colors"
              >
                Continue with Local Synthesis & World Generation
              </button>

              <button
                onClick={onRetryGemini}
                className="w-full py-2 px-4 rounded-xl bg-[#111A30] hover:bg-white/5 border border-white/10 text-xs font-medium text-[#93A4BE] hover:text-white flex items-center justify-center gap-2 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Gemini Request</span>
              </button>
            </div>
          </div>
        )}

        {/* EMPTY IDLE STATE */}
        {status === 'idle' && (
          <div className="space-y-6">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-[#62D5E8] via-[#A58BFA] to-[#FFB66E] p-0.5 shadow-xl shadow-[#62D5E8]/20">
              <div className="w-full h-full bg-[#0B1020] rounded-[22px] flex items-center justify-center">
                <Disc3 className="w-8 h-8 text-[#62D5E8]" />
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white tracking-tight mb-2 font-['Space_Grotesk']">
                Every song hides a world.
              </h2>
              <p className="text-xs text-[#93A4BE] leading-relaxed max-w-sm mx-auto">
                Upload a short music clip and turn its rhythm, energy, and atmosphere into an explorable 3D universe.
              </p>
            </div>

            <div className="space-y-2.5 pt-2">
              <button
                onClick={onOpenUpload}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#62D5E8] to-[#38BDF8] hover:opacity-95 text-[#0B1020] text-xs font-bold tracking-wide shadow-lg shadow-[#62D5E8]/25 flex items-center justify-center gap-2 transition-all"
              >
                <Upload className="w-4 h-4" />
                <span>Upload My Music (MP3 / WAV)</span>
              </button>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => onLoadSample('cosmic')}
                  className="py-2.5 px-3 rounded-xl bg-[#111A30] hover:bg-[#111A30]/80 border border-white/10 hover:border-[#62D5E8]/40 text-left transition-all"
                >
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-white mb-0.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#62D5E8]" />
                    <span>Cosmic Aurora</span>
                  </div>
                  <p className="text-[10px] text-[#93A4BE]">Dreamy · 124 BPM</p>
                </button>

                <button
                  onClick={() => onLoadSample('cyber')}
                  className="py-2.5 px-3 rounded-xl bg-[#111A30] hover:bg-[#111A30]/80 border border-white/10 hover:border-[#EC4899]/40 text-left transition-all"
                >
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-white mb-0.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />
                    <span>Cyber Pulse</span>
                  </div>
                  <p className="text-[10px] text-[#93A4BE]">Aggressive · 148 BPM</p>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
