import React, { useState } from 'react';
import {
  AudioTestSuiteReport,
  runAudioPipelineTestSuite,
} from '../audio/audioPipelineTest';
import {
  WorldVerifierTestSuiteReport,
  runWorldVerifierTestSuite,
} from '../audio/worldVerifierTest';
import {
  CheckCircle2,
  XCircle,
  Play,
  RotateCw,
  X,
  Volume2,
  Waves,
  Zap,
  Activity,
  Sliders,
  ShieldCheck,
  Wrench,
} from 'lucide-react';

interface AudioPipelineTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  audioBuffer: AudioBuffer | null;
  filename: string;
}

export const AudioPipelineTestModal: React.FC<AudioPipelineTestModalProps> = ({
  isOpen,
  onClose,
  audioBuffer,
  filename,
}) => {
  const [activeTab, setActiveTab] = useState<'dsp' | 'argon'>('dsp');
  const [report, setReport] = useState<AudioTestSuiteReport | null>(null);
  const [argonReport, setArgonReport] = useState<WorldVerifierTestSuiteReport | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  if (!isOpen) return null;

  const handleRunDspTests = async () => {
    setIsRunning(true);
    try {
      const results = await runAudioPipelineTestSuite(audioBuffer);
      setReport(results);
    } catch (err) {
      console.error('Audio pipeline test runner failed:', err);
    } finally {
      setIsRunning(false);
    }
  };

  const handleRunArgonTests = () => {
    setIsRunning(true);
    try {
      const results = runWorldVerifierTestSuite();
      setArgonReport(results);
    } catch (err) {
      console.error('Argon test runner failed:', err);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-[#0B1020] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-white/5 flex items-center justify-between bg-[#111A30]/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#62D5E8]/20 to-[#A58BFA]/20 border border-[#62D5E8]/30 flex items-center justify-center text-[#62D5E8]">
              {activeTab === 'dsp' ? <Activity className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
                {activeTab === 'dsp' ? 'Real Audio DSP Verification Suite' : 'Gemini 4 Argon Scene Verifier Suite'}
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-[#62D5E8]/10 text-[#62D5E8] border border-[#62D5E8]/20">
                  {activeTab === 'dsp' ? 'OfflineAudioContext' : 'Argon Verification Loop'}
                </span>
              </h2>
              <p className="text-xs text-[#93A4BE]">
                {activeTab === 'dsp'
                  ? `Target: ${filename || 'Standard Acoustic Reference Track'} (${audioBuffer ? `${audioBuffer.duration.toFixed(1)}s, ${audioBuffer.sampleRate}Hz` : 'Synthetic Reference'})`
                  : 'Automated 7-test suite testing validation, section continuity, tri-layer completeness, repair loop, and archetype regression audit.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-white/5 bg-[#0B1020]/80 px-4 pt-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('dsp')}
            className={`pb-2.5 px-3 flex items-center gap-2 border-b-2 transition-all ${
              activeTab === 'dsp'
                ? 'border-[#62D5E8] text-[#62D5E8]'
                : 'border-transparent text-[#93A4BE] hover:text-white'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Audio DSP Deltas (5 Tests)</span>
          </button>
          <button
            onClick={() => setActiveTab('argon')}
            className={`pb-2.5 px-3 flex items-center gap-2 border-b-2 transition-all ${
              activeTab === 'argon'
                ? 'border-[#62D5E8] text-[#62D5E8]'
                : 'border-transparent text-[#93A4BE] hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Gemini 4 Argon Verifier (7 Tests)</span>
          </button>
        </div>

        {/* Tab 1: DSP Tests */}
        {activeTab === 'dsp' && (
          <>
            <div className="p-4 bg-gradient-to-r from-[#62D5E8]/5 via-[#A58BFA]/5 to-[#FFB66E]/5 border-b border-white/5 text-xs text-[#93A4BE] leading-relaxed">
              <p>
                <strong className="text-white">Strict Verification: </strong>
                This suite renders original audio and edited signals using an{' '}
                <code className="text-[#62D5E8] bg-black/30 px-1 py-0.5 rounded font-mono">OfflineAudioContext</code>.
                It performs sample-by-sample root-mean-square (RMS) delta comparison to mathematically prove that
                the <strong className="text-white">ACTUAL uploaded MP3 recording samples</strong> are reshaped by sculptures,
                not synthesized overlays.
              </p>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 flex-1">
              {!report && !isRunning && (
                <div className="py-10 text-center flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-2xl bg-[#111A30] border border-white/5 flex items-center justify-center text-[#93A4BE] mb-3">
                    <Sliders className="w-6 h-6 text-[#62D5E8]" />
                  </div>
                  <p className="text-sm font-semibold text-white mb-1">Ready to Run Automated DSP Verification</p>
                  <p className="text-xs text-[#93A4BE] max-w-sm mb-4">
                    Click below to compute waveform sample deltas for Rhythm Crystals (gain envelope), Bass River (low-shelf EQ), and Energy Core.
                  </p>
                  <button
                    onClick={handleRunDspTests}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#62D5E8] to-[#A58BFA] text-[#0B1020] font-bold text-xs flex items-center gap-2 hover:opacity-95 transition-all shadow-lg shadow-[#62D5E8]/20"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Execute All 5 DSP Tests</span>
                  </button>
                </div>
              )}

              {isRunning && (
                <div className="py-12 text-center flex flex-col items-center justify-center space-y-3">
                  <RotateCw className="w-7 h-7 text-[#62D5E8] animate-spin" />
                  <p className="text-sm font-medium text-white">Rendering Offline Audio Buffers & Computing RMS Deltas...</p>
                  <p className="text-xs text-[#93A4BE]">Running DSP filter pipelines on audio samples</p>
                </div>
              )}

              {report && (
                <div className="space-y-3">
                  <div
                    className={`p-3.5 rounded-xl border flex items-center justify-between ${
                      report.allPassed
                        ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-400'
                        : 'bg-rose-950/30 border-rose-500/30 text-rose-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {report.allPassed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-rose-400" />
                      )}
                      <div>
                        <h4 className="text-xs font-bold font-['Space_Grotesk']">
                          {report.allPassed ? 'ALL TESTS VERIFIED: REAL AUDIO MODIFIED' : 'TEST FAILURES DETECTED'}
                        </h4>
                        <p className="text-[11px] opacity-80">{report.verdict}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold font-mono">
                        {report.testsPassed} / {report.testsTotal}
                      </span>
                      <p className="text-[10px] opacity-70">Passed</p>
                    </div>
                  </div>

                  {report.results.map((test) => (
                    <div
                      key={test.id}
                      className="p-3.5 rounded-xl bg-[#111A30]/60 border border-white/5 space-y-2 hover:border-white/10 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {test.passed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          )}
                          <span className="text-xs font-bold text-white font-['Space_Grotesk']">
                            {test.name}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-[#93A4BE]">
                          {test.targetSculpture}
                        </span>
                      </div>

                      <p className="text-[11px] text-[#93A4BE] leading-relaxed">
                        {test.description}
                      </p>

                      <div className="flex items-center gap-4 pt-1 border-t border-white/5 text-[10px] font-mono">
                        <div className="flex items-center gap-1.5 text-white/80">
                          <span className="text-[#93A4BE]">RMS Diff:</span>
                          <strong className="text-[#62D5E8]">
                            {test.rmsDifference > 0.000001
                              ? test.rmsDifference.toFixed(4)
                              : '0.000000 (Exact)'}
                          </strong>
                        </div>
                        <div className="flex items-center gap-1.5 text-white/80">
                          <span className="text-[#93A4BE]">Max Delta:</span>
                          <strong className="text-[#FFB66E]">
                            {test.maxSampleDelta.toFixed(4)}
                          </strong>
                        </div>
                        <div className="flex items-center gap-1.5 text-white/60 ml-auto">
                          <span>{test.sampleCount.toLocaleString()} samples evaluated</span>
                        </div>
                      </div>

                      <p className="text-[10px] text-emerald-400/90 font-mono bg-emerald-950/20 px-2 py-1 rounded">
                        {test.details}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {/* Tab 2: Gemini 4 Argon Verifier Tests */}
        {activeTab === 'argon' && (
          <>
            <div className="p-4 bg-gradient-to-r from-[#62D5E8]/5 via-[#A58BFA]/5 to-[#FFB66E]/5 border-b border-white/5 text-xs text-[#93A4BE] leading-relaxed">
              <p>
                <strong className="text-white">Programmatic Verification: </strong>
                Tests the deterministic validation and targeted repair loop required by Gemini 4 Argon.
                Covers valid scene pass, duration mismatch failure, overlapping boundary detection, missing sculpture detection, automated repair loop integrity, and graceful fallback.
              </p>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 flex-1">
              {!argonReport && !isRunning && (
                <div className="py-10 text-center flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-2xl bg-[#111A30] border border-white/5 flex items-center justify-center text-[#93A4BE] mb-3">
                    <ShieldCheck className="w-6 h-6 text-[#62D5E8]" />
                  </div>
                  <p className="text-sm font-semibold text-white mb-1">Automated Gemini 4 Argon Test Suite</p>
                  <p className="text-xs text-[#93A4BE] max-w-sm mb-4">
                    Verify that invalid Gemini outputs are deterministically intercepted and repaired before 3D rendering.
                  </p>
                  <button
                    onClick={handleRunArgonTests}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#62D5E8] to-[#A58BFA] text-[#0B1020] font-bold text-xs flex items-center gap-2 hover:opacity-95 transition-all shadow-lg shadow-[#62D5E8]/20"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Execute All 7 Argon Verifier Tests</span>
                  </button>
                </div>
              )}

              {isRunning && (
                <div className="py-12 text-center flex flex-col items-center justify-center space-y-3">
                  <RotateCw className="w-7 h-7 text-[#62D5E8] animate-spin" />
                  <p className="text-sm font-medium text-white">Running Gemini 4 Argon Verification Test Suite...</p>
                </div>
              )}

              {argonReport && (
                <div className="space-y-3">
                  <div
                    className={`p-3.5 rounded-xl border flex items-center justify-between ${
                      argonReport.allPassed
                        ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-400'
                        : 'bg-rose-950/30 border-rose-500/30 text-rose-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {argonReport.allPassed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <XCircle className="w-5 h-5 text-rose-400" />
                      )}
                      <div>
                        <h4 className="text-xs font-bold font-['Space_Grotesk']">
                          {argonReport.allPassed ? 'ALL 6 ARGON VERIFICATION TESTS PASSED' : 'TEST FAILURES DETECTED'}
                        </h4>
                        <p className="text-[11px] opacity-80">{argonReport.verdict}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold font-mono">
                        {argonReport.testsPassed} / {argonReport.testsTotal}
                      </span>
                      <p className="text-[10px] opacity-70">Passed</p>
                    </div>
                  </div>

                  {argonReport.results.map((test) => (
                    <div
                      key={test.id}
                      className="p-3.5 rounded-xl bg-[#111A30]/60 border border-white/5 space-y-2 hover:border-white/10 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {test.passed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          )}
                          <span className="text-xs font-bold text-white font-['Space_Grotesk']">
                            {test.name}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-[#62D5E8]">
                          Expected: {test.expectedResult.toUpperCase()}
                        </span>
                      </div>

                      <p className="text-[11px] text-[#93A4BE] leading-relaxed">
                        {test.description}
                      </p>

                      <p className="text-[10px] text-emerald-400/90 font-mono bg-emerald-950/20 px-2.5 py-1.5 rounded">
                        {test.details}
                      </p>

                      {test.diagnostics && test.diagnostics.length > 0 && (
                        <div className="text-[9px] font-mono text-[#93A4BE]/80 bg-black/30 p-2 rounded border border-white/5">
                          <span className="text-white/60 block mb-0.5 font-semibold">Report Details:</span>
                          {test.diagnostics.map((d, i) => (
                            <div key={i}>• {d}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {/* Footer */}
        <div className="p-4 border-t border-white/5 bg-[#111A30]/50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-[#93A4BE]">
            <Waves className="w-4 h-4 text-[#62D5E8]" />
            <span>SoundShape Automated Integrity Framework</span>
          </div>
          <div className="flex items-center gap-2">
            {((activeTab === 'dsp' && report) || (activeTab === 'argon' && argonReport)) && (
              <button
                onClick={activeTab === 'dsp' ? handleRunDspTests : handleRunArgonTests}
                disabled={isRunning}
                className="px-3.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <RotateCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
                <span>Re-run Tests</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

