import React from 'react';
import {
  DrumSoundType,
  EditScope,
  LAYER_CONFIGS,
  MultiLayerEdit,
  MusicalLayerType,
  ViewMode,
  WorldEditState,
  WorldScene,
} from '../types/world';
import { BeforeAfterProgress, RealAudioEngine } from '../audio/realAudioEngine';
import {
  RotateCcw,
  ArrowLeft,
  Sliders,
  Sparkles,
  Check,
  X,
  Headphones,
  Info,
  Zap,
  Waves,
  Activity,
  Volume2,
  Download,
  Trash2,
  Layers,
  Clock,
  Music,
  Play,
  Square,
  ArrowRight,
} from 'lucide-react';
import { formatTimestamp } from '../audio/metadataEnricher';
import { SelectedSculptureType } from '../three/SceneManager';

interface RightSidebarProps {
  scene: WorldScene | null;
  editState: WorldEditState;
  viewMode: ViewMode;
  selectedSectionId: string | null;
  selectedStepIndex: number | null;
  selectedSculptureType?: SelectedSculptureType | null;
  activeLayer: MusicalLayerType;
  editScope: EditScope;
  momentDuration: number;
  multiLayerEdits: MultiLayerEdit[];
  selectedTimestamp: number | null;
  comparisonProgress?: BeforeAfterProgress | null;
  onSelectLayer: (layer: MusicalLayerType) => void;
  onScopeChange: (scope: EditScope) => void;
  onMomentDurationChange: (duration: number) => void;
  onUpdateLayerEdit: (layer: MusicalLayerType, value: number) => void;
  onDeleteLayerEdit: (editId: string) => void;
  onToggleLayerEdit: (editId: string) => void;
  onResetLayerProperty: (layer: MusicalLayerType) => void;
  onExportWav?: () => void;
  onUpdateStep: (
    sectionId: string,
    stepIndex: number,
    updates: { intensity?: number; active?: boolean; type?: DrumSoundType }
  ) => void;
  onUpdateSectionRhythmDensity: (sectionId: string, density: number) => void;
  onUpdateSectionBass: (sectionId: string, bass: number) => void;
  onUpdateSectionEnergy: (sectionId: string, energy: number) => void;
  onResetElement: (sectionId: string, stepIndex: number) => void;
  onResetSection: (sectionId: string) => void;
  onBackToSection: () => void;
  onBackToWorld: () => void;
  onListenToMoment: (timestamp: number) => void;
  onCompareMoment?: (timestamp: number) => void;
  onListenToWindow?: (start: number, end: number) => void;
  onCompareWindow?: (start: number, end: number) => void;
  onPlayBeforeAudition?: (start: number, end: number) => void;
  onPlayAfterAudition?: (start: number, end: number) => void;
  onPlayABComparison?: (start: number, end: number) => void;
  onStopComparison?: () => void;
  onOpenAudioTests?: () => void;
}

export const RightSidebar: React.FC<RightSidebarProps> = ({
  scene,
  editState,
  viewMode,
  selectedSectionId,
  selectedStepIndex,
  selectedSculptureType,
  activeLayer,
  editScope,
  momentDuration,
  multiLayerEdits,
  selectedTimestamp,
  onSelectLayer,
  onScopeChange,
  onMomentDurationChange,
  onUpdateLayerEdit,
  onDeleteLayerEdit,
  onToggleLayerEdit,
  onResetLayerProperty,
  onExportWav,
  onUpdateStep,
  onUpdateSectionRhythmDensity,
  onUpdateSectionBass,
  onUpdateSectionEnergy,
  onResetElement,
  onResetSection,
  onBackToSection,
  onBackToWorld,
  onListenToMoment,
  onCompareMoment,
  onListenToWindow,
  onCompareWindow,
  comparisonProgress,
  onPlayBeforeAudition,
  onPlayAfterAudition,
  onPlayABComparison,
  onStopComparison,
  onOpenAudioTests,
}) => {
  if (!scene || !selectedSectionId) {
    return (
      <aside className="w-84 h-full border-l border-white/5 bg-[#0B1020]/90 backdrop-blur-md p-6 flex flex-col justify-center items-center text-center shrink-0 select-none">
        <div className="w-12 h-12 rounded-2xl bg-[#111A30] border border-white/10 flex items-center justify-center text-[#93A4BE] mb-3">
          <Sliders className="w-5 h-5" />
        </div>
        <h3 className="text-sm font-semibold text-white mb-1">Spatial Layer Inspector</h3>
        <p className="text-xs text-[#93A4BE] max-w-[220px] leading-relaxed">
          Select any musical island or time location to inspect and reshape multiple musical layers simultaneously.
        </p>
        {onOpenAudioTests && (
          <button
            onClick={onOpenAudioTests}
            className="mt-6 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-[#62D5E8] flex items-center gap-1.5 transition-colors"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Verify DSP Pipeline</span>
          </button>
        )}
      </aside>
    );
  }

  const section = scene.sections.find((s) => s.id === selectedSectionId);
  if (!section) return null;

  const currentSectionEdit = editState[selectedSectionId];
  const selectedStep =
    selectedStepIndex !== null
      ? currentSectionEdit?.rhythmSteps.find((s) => s.index === selectedStepIndex)
      : null;

  // Compute active target time and window
  const activeTime =
    selectedTimestamp !== null
      ? selectedTimestamp
      : selectedStep?.eventTimeSeconds ?? (section.start + section.end) / 2;

  let windowStart: number;
  let windowEnd: number;

  if (editScope === 'moment') {
    const dur = Math.max(0.2, Math.min(2.0, momentDuration));
    windowStart = Math.max(0, activeTime - dur / 2);
    windowEnd = Math.min(scene.duration, windowStart + dur);
  } else {
    windowStart = section.start;
    windowEnd = section.end;
  }

  const windowDurationMs = Math.round((windowEnd - windowStart) * 1000);
  const activeLayerConfig = LAYER_CONFIGS[activeLayer];

  // Retrieve current active edit for this layer at this range if exists
  const currentLayerEdit = multiLayerEdits.find(
    (e) =>
      e.sectionId === section.id &&
      e.layer === activeLayer &&
      e.scope === editScope &&
      Math.abs(e.startTime - windowStart) < 0.25
  );

  const currentValue = currentLayerEdit ? currentLayerEdit.editedValue : activeLayerConfig.defaultValue;
  const isEdited = currentLayerEdit !== undefined && currentLayerEdit.editedValue !== activeLayerConfig.defaultValue;

  // Stored edits at this containing section or timestamp range
  const relevantEdits = multiLayerEdits.filter(
    (e) =>
      e.sectionId === section.id &&
      ((e.scope === 'section') ||
        (activeTime >= e.startTime - 0.1 && activeTime <= e.endTime + 0.1))
  );

  const relevantEnabledEdits = relevantEdits.filter((e) => e.enabled);

  const isComparing = Boolean(
    comparisonProgress &&
      comparisonProgress.phase !== 'idle' &&
      comparisonProgress.phase !== 'complete'
  );
  const isBeforeActive = comparisonProgress?.phase === 'before';
  const isAfterActive = comparisonProgress?.phase === 'after';
  const isABActive =
    comparisonProgress?.type === 'ab_comparison' &&
    (comparisonProgress.phase === 'before' ||
      comparisonProgress.phase === 'pause' ||
      comparisonProgress.phase === 'after');

  const isRhythmSelected = viewMode === 'element' && selectedStep !== null;
  const isBassSculpture = selectedSculptureType === 'bass_river';
  const isEnergySculpture = selectedSculptureType === 'energy_core';

  const layersList: MusicalLayerType[] = ['energy', 'bass', 'treble', 'texture', 'pitch', 'timing'];

  return (
    <aside className="w-84 h-full border-l border-white/5 bg-[#0B1020]/95 backdrop-blur-md flex flex-col shrink-0 select-none overflow-y-auto">
      {/* Top Breadcrumb & Header */}
      <div className="p-3.5 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {viewMode === 'element' || isBassSculpture || isEnergySculpture ? (
            <button
              onClick={onBackToSection}
              className="p-1 rounded-md text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1 text-xs"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Section</span>
            </button>
          ) : (
            <button
              onClick={onBackToWorld}
              className="p-1 rounded-md text-[#93A4BE] hover:text-white hover:bg-white/5 transition-colors flex items-center gap-1 text-xs"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>World</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <span
            className="w-2 h-2 rounded-full"
            style={{ backgroundColor: activeLayerConfig.color }}
          />
          <span className="text-[11px] font-mono text-white font-semibold">
            {activeLayerConfig.label} Layer
          </span>
        </div>
      </div>

      <div className="p-4 space-y-4 flex-1">
        {/* 1. SECTION & TIME LOCATION HEADER */}
        <div className="p-3 rounded-xl bg-[#111A30]/60 border border-white/5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white tracking-wide font-['Space_Grotesk']">
              {section.label}
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-[#62D5E8]/15 text-[#62D5E8]">
              {section.start.toFixed(1)}s – {section.end.toFixed(1)}s
            </span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-white/5 text-xs font-mono">
            <span className="text-[#93A4BE]">Selected Time:</span>
            <span className="text-[#62D5E8] font-bold">{formatTimestamp(activeTime)}</span>
          </div>
        </div>

        {/* 2. TIME RANGE / EDIT SCOPE SELECTOR (Prompt 4, Req 3) */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span>Editing Time Range</span>
            </span>
            <span className="text-[10px] font-mono text-[#93A4BE]">
              {editScope === 'moment' ? `${windowDurationMs}ms Window` : 'Whole Section'}
            </span>
          </div>

          {/* Scope Segment Control */}
          <div className="grid grid-cols-2 p-1 rounded-xl bg-[#111A30]/80 border border-white/10 gap-1">
            <button
              onClick={() => onScopeChange('moment')}
              className={`py-1.5 rounded-lg text-xs font-semibold transition-all ${
                editScope === 'moment'
                  ? 'bg-[#62D5E8] text-[#0B1020] shadow-sm'
                  : 'text-[#93A4BE] hover:text-white'
              }`}
            >
              Moment (Window)
            </button>
            <button
              onClick={() => onScopeChange('section')}
              className={`py-1.5 rounded-lg text-xs font-semibold transition-all ${
                editScope === 'section'
                  ? 'bg-[#62D5E8] text-[#0B1020] shadow-sm'
                  : 'text-[#93A4BE] hover:text-white'
              }`}
            >
              Full Section
            </button>
          </div>

          {/* Moment Duration Slider (if moment scope selected) */}
          {editScope === 'moment' && (
            <div className="p-2.5 rounded-lg bg-[#111A30]/40 border border-white/5 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#93A4BE]">Window Width:</span>
                <span className="font-mono text-[#62D5E8] font-semibold">{windowDurationMs} ms</span>
              </div>
              <input
                type="range"
                min={200}
                max={2000}
                step={50}
                value={Math.round(momentDuration * 1000)}
                onChange={(e) => onMomentDurationChange(Number(e.target.value) / 1000)}
                className="w-full accent-[#62D5E8] h-1.5"
              />
              <div className="flex justify-between text-[9px] font-mono text-[#93A4BE]/70">
                <span>200 ms</span>
                <span className="text-white/60">500 ms (Default)</span>
                <span>2.0 s</span>
              </div>
            </div>
          )}

          {/* Window Bounds Display */}
          <div className="text-[10px] font-mono text-center text-[#93A4BE]/80">
            Active Slice: {windowStart.toFixed(3)}s – {windowEnd.toFixed(3)}s
          </div>
        </div>

        {/* 3. MUSICAL LAYER SELECTOR (6 Available Layers - Prompt 4, Req 2) */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span>Select Musical Layer</span>
            </span>
            <span className="text-[10px] font-mono text-[#93A4BE]">6 Layers</span>
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            {layersList.map((layerKey) => {
              const cfg = LAYER_CONFIGS[layerKey];
              const isCurrent = activeLayer === layerKey;
              return (
                <button
                  key={layerKey}
                  onClick={() => onSelectLayer(layerKey)}
                  className={`p-2 rounded-xl text-left border transition-all flex flex-col gap-1 relative ${
                    isCurrent
                      ? 'bg-white/10 ring-1 shadow-md scale-[1.02]'
                      : 'bg-[#111A30]/60 border-white/5 hover:border-white/20 text-[#93A4BE] hover:text-white'
                  }`}
                  style={{
                    borderColor: isCurrent ? cfg.color : undefined,
                    boxShadow: isCurrent ? `0 0 12px ${cfg.color}35` : undefined,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: cfg.color }}
                    />
                    {multiLayerEdits.some((e) => e.layer === layerKey && e.sectionId === section.id) && (
                      <span className="w-1.5 h-1.5 rounded-full bg-white" />
                    )}
                  </div>
                  <span className="text-[11px] font-bold text-white">{cfg.label}</span>
                  <span className="text-[9px] font-mono text-[#93A4BE] truncate">
                    {cfg.property}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. RESHAPE SELECTED PROPERTY (Prompt 4, Req 1: Reshape -> Hear the Change) */}
        <div className="space-y-3 p-3.5 rounded-xl bg-[#111A30]/60 border border-white/5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5" style={{ color: activeLayerConfig.color }} />
              <span>Reshape {activeLayerConfig.label}</span>
            </span>
            <span
              className="font-mono text-xs font-bold"
              style={{ color: activeLayerConfig.color }}
            >
              {currentValue > 0 && activeLayerConfig.unit === 'dB' ? '+' : ''}
              {activeLayerConfig.unit === 'Hz'
                ? `${Math.round(currentValue).toLocaleString()} Hz`
                : `${currentValue} ${activeLayerConfig.unit}`}
            </span>
          </div>

          <p className="text-[11px] text-[#93A4BE] leading-tight">
            {activeLayerConfig.description}
          </p>

          <div className="space-y-1.5 pt-1">
            <input
              type="range"
              min={activeLayerConfig.minValue}
              max={activeLayerConfig.maxValue}
              step={activeLayerConfig.step}
              value={currentValue}
              onChange={(e) => onUpdateLayerEdit(activeLayer, Number(e.target.value))}
              className="w-full h-2 cursor-pointer"
              style={{ accentColor: activeLayerConfig.color }}
            />
            <div className="flex justify-between text-[9px] font-mono text-[#93A4BE]">
              <span>
                {activeLayerConfig.minValue} {activeLayerConfig.unit}
              </span>
              <span className="text-white/60">
                Default ({activeLayerConfig.defaultValue} {activeLayerConfig.unit})
              </span>
              <span>
                +{activeLayerConfig.maxValue} {activeLayerConfig.unit}
              </span>
            </div>
          </div>

          {/* Reset Property button */}
          {isEdited && (
            <button
              onClick={() => onResetLayerProperty(activeLayer)}
              className="w-full py-1.5 rounded-lg border border-white/10 hover:border-white/25 text-[11px] text-[#93A4BE] hover:text-white flex items-center justify-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset {activeLayerConfig.label} to Original</span>
            </button>
          )}
        </div>

        {/* 5. HEAR YOUR CHANGES: Intuitive Before / After / A-B Comparison Panel (Prompt 5, Part A) */}
        <div className="space-y-3 p-3.5 rounded-xl bg-[#111A30]/80 border border-white/10 shadow-lg relative overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-bold text-white text-xs tracking-wide">
              <Headphones className="w-3.5 h-3.5 text-[#62D5E8]" />
              <span>Hear Your Changes</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-white/5 border border-white/10 text-[#62D5E8]">
              {relevantEnabledEdits.length > 0
                ? `${relevantEnabledEdits.length} Active Edit${relevantEnabledEdits.length > 1 ? 's' : ''}`
                : 'No Active Edits'}
            </span>
          </div>

          {/* Subtitle / Timestamp Info */}
          <div className="flex items-center justify-between text-[11px] font-mono text-[#93A4BE] pt-0.5 border-b border-white/5 pb-2">
            <span>Time: <strong className="text-white">{formatTimestamp(activeTime)}</strong></span>
            <span>Slice: <strong className="text-[#62D5E8]">{windowDurationMs} ms</strong></span>
          </div>

          {/* Active Comparison Status & Progress Bar (when playing) */}
          {isComparing && (
            <div className="p-2.5 rounded-lg bg-black/40 border border-[#62D5E8]/30 space-y-2 animate-fade-in">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full animate-ping ${
                      isBeforeActive
                        ? 'bg-slate-300'
                        : isAfterActive
                        ? 'bg-[#62D5E8]'
                        : 'bg-[#A58BFA]'
                    }`}
                  />
                  <span className="font-semibold text-white">
                    {comparisonProgress?.type === 'ab_comparison'
                      ? (comparisonProgress.phase === 'before'
                          ? 'Step 1 of 2 — Original'
                          : comparisonProgress.phase === 'pause'
                          ? 'Switching to Step 2...'
                          : 'Step 2 of 2 — Edited')
                      : isBeforeActive
                      ? 'Now Playing: Original'
                      : 'Now Playing: Edited'}
                  </span>
                </div>
                {onStopComparison && (
                  <button
                    onClick={onStopComparison}
                    className="px-2 py-0.5 rounded bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 text-[10px] font-medium flex items-center gap-1 transition-colors"
                    title="Stop preview playback"
                  >
                    <Square className="w-2.5 h-2.5 fill-current" />
                    <span>Stop</span>
                  </button>
                )}
              </div>

              {/* Progress bar */}
              <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className={`h-full transition-all duration-100 ${
                    isBeforeActive
                      ? 'bg-slate-300'
                      : isAfterActive
                      ? 'bg-gradient-to-r from-[#62D5E8] to-[#A58BFA]'
                      : 'bg-[#A58BFA]'
                  }`}
                  style={{ width: `${Math.round((comparisonProgress?.progressRatio ?? 0) * 100)}%` }}
                />
              </div>
            </div>
          )}

          {/* Primary Action Buttons */}
          <div className="space-y-2">
            {/* Row 1: [ Before: Original ] [ After: Edited ] */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  if (isBeforeActive && onStopComparison) {
                    onStopComparison();
                  } else if (onPlayBeforeAudition) {
                    onPlayBeforeAudition(windowStart, windowEnd);
                  } else if (onListenToWindow) {
                    onListenToWindow(windowStart, windowEnd);
                  }
                }}
                className={`py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all border ${
                  isBeforeActive
                    ? 'bg-white/20 border-white text-white shadow-[0_0_12px_rgba(255,255,255,0.3)] ring-1 ring-white/50'
                    : 'bg-[#111A30] border-white/10 hover:border-white/25 text-[#EAF2FF] hover:bg-white/5'
                }`}
                title="Play the unprocessed original recording passage"
              >
                {isBeforeActive ? (
                  <Square className="w-3 h-3 fill-current text-white" />
                ) : (
                  <Play className="w-3 h-3 text-[#93A4BE]" />
                )}
                <span>Before: Original</span>
              </button>

              <button
                onClick={() => {
                  if (isAfterActive && onStopComparison) {
                    onStopComparison();
                  } else if (onPlayAfterAudition) {
                    onPlayAfterAudition(windowStart, windowEnd);
                  } else if (onListenToWindow) {
                    onListenToWindow(windowStart, windowEnd);
                  }
                }}
                className={`py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all border ${
                  isAfterActive
                    ? 'bg-[#62D5E8]/20 border-[#62D5E8] text-white shadow-[0_0_12px_rgba(98,213,232,0.35)] ring-1 ring-[#62D5E8]'
                    : 'bg-[#111A30] border-white/10 hover:border-[#62D5E8]/40 text-[#EAF2FF] hover:bg-white/5'
                }`}
                title="Play the same passage with current DSP edits applied"
              >
                {isAfterActive ? (
                  <Square className="w-3 h-3 fill-current text-[#62D5E8]" />
                ) : (
                  <Sparkles className="w-3 h-3 text-[#62D5E8]" />
                )}
                <span>After: Edited</span>
              </button>
            </div>

            {/* Row 2: [ Compare A -> B ] */}
            <button
              onClick={() => {
                if (isABActive && onStopComparison) {
                  onStopComparison();
                } else if (onPlayABComparison) {
                  onPlayABComparison(windowStart, windowEnd);
                } else if (onCompareWindow) {
                  onCompareWindow(windowStart, windowEnd);
                } else if (onCompareMoment) {
                  onCompareMoment(activeTime);
                }
              }}
              className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all border shadow-sm ${
                isABActive
                  ? 'bg-gradient-to-r from-[#62D5E8]/25 via-[#A58BFA]/25 to-[#FFB66E]/25 border-[#62D5E8] text-white ring-1 ring-[#62D5E8]/60 shadow-[0_0_14px_rgba(98,213,232,0.25)]'
                  : 'bg-gradient-to-r from-[#62D5E8]/10 via-[#A58BFA]/10 to-[#FFB66E]/10 border-white/15 hover:border-white/30 text-white hover:bg-white/10'
              }`}
              title="Automatically play the original passage followed by the edited passage"
            >
              {isABActive ? (
                <Square className="w-3.5 h-3.5 fill-current text-[#62D5E8]" />
              ) : (
                <ArrowRight className="w-3.5 h-3.5 text-[#62D5E8]" />
              )}
              <span>Compare A → B</span>
              <span className="text-[10px] font-normal text-[#93A4BE]">
                ({isABActive ? 'Playing...' : 'Original then Edited'})
              </span>
            </button>
          </div>

          {/* Show What Changed Summary (Requirement A5) */}
          <div className="pt-2 border-t border-white/5 space-y-1.5">
            {relevantEnabledEdits.length === 0 ? (
              <div className="p-2.5 rounded-lg bg-white/5 border border-white/5 text-center text-[11px] text-[#93A4BE] space-y-0.5">
                <p className="font-medium text-white/80">No active edits in this range</p>
                <p className="text-[10px] text-[#93A4BE]/80">
                  Original and Edited will sound identical until you adjust layers above.
                </p>
              </div>
            ) : (
              <div className="space-y-1.5">
                <div className="text-[10px] font-mono uppercase tracking-wider text-[#93A4BE]/80 flex items-center justify-between">
                  <span>What Changed:</span>
                  <span className="text-[#62D5E8]">
                    {relevantEnabledEdits.length} Effect{relevantEnabledEdits.length > 1 ? 's' : ''}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {relevantEnabledEdits.map((e) => {
                    const cfg = LAYER_CONFIGS[e.layer];
                    return (
                      <div
                        key={e.editId}
                        className="px-2 py-1 rounded-lg bg-[#111A30] border border-white/5 flex items-center justify-between text-[10px] font-mono"
                      >
                        <span className="flex items-center gap-1 text-white font-medium truncate">
                          <span
                            className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ backgroundColor: cfg.color }}
                          />
                          <span className="truncate">{cfg.label}</span>
                        </span>
                        <span className="text-[#62D5E8] font-bold shrink-0 ml-1">
                          {e.editedValue > 0 && cfg.unit === 'dB' ? '+' : ''}
                          {e.editedValue}
                          {cfg.unit === 'Hz' ? 'Hz' : cfg.unit}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 6. SIMULTANEOUS EDITS STACK AT THIS LOCATION (Prompt 4, Req 1 & 3) */}
        {relevantEdits.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-white/5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5 text-[#A58BFA]" />
                <span>Simultaneous Edits Stack</span>
              </span>
              <span className="text-[10px] font-mono text-[#93A4BE]">
                {relevantEdits.length} Active
              </span>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {relevantEdits.map((e) => {
                const cfg = LAYER_CONFIGS[e.layer];
                return (
                  <div
                    key={e.editId}
                    className={`p-2 rounded-lg border text-xs flex items-center justify-between gap-2 transition-all ${
                      e.enabled
                        ? 'bg-[#111A30]/80 border-white/10'
                        : 'bg-white/5 border-white/5 opacity-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{ backgroundColor: cfg.color }}
                      />
                      <div className="min-w-0">
                        <p className="font-bold text-white truncate text-[11px]">{cfg.label}</p>
                        <p className="text-[10px] font-mono text-[#93A4BE]">
                          {e.editedValue > 0 && cfg.unit === 'dB' ? '+' : ''}
                          {e.editedValue} {cfg.unit} ({e.scope})
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => onToggleLayerEdit(e.editId)}
                        className={`p-1 rounded-md text-[10px] font-medium transition-colors ${
                          e.enabled ? 'text-[#62D5E8] hover:bg-white/10' : 'text-[#93A4BE]'
                        }`}
                        title={e.enabled ? 'Disable this layer edit' : 'Enable this layer edit'}
                      >
                        {e.enabled ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => onDeleteLayerEdit(e.editId)}
                        className="p-1 rounded-md text-[#93A4BE] hover:text-red-400 hover:bg-white/10 transition-colors"
                        title="Delete this edit"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 7. RHYTHM CRYSTAL ENVELOPE (If element is selected) */}
        {isRhythmSelected && selectedStep && (
          <div className="space-y-3 pt-3 border-t border-white/5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white font-['Space_Grotesk'] flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-[#62D5E8]" />
                <span>Rhythm Crystal #{selectedStep.index + 1}</span>
              </span>
              <span className="text-[10px] font-mono text-[#62D5E8]">
                {Math.round(selectedStep.intensity * 100)}%
              </span>
            </div>

            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={Math.round(selectedStep.intensity * 100)}
              onChange={(e) => {
                const val = Number(e.target.value) / 100;
                onUpdateStep(section.id, selectedStep.index, { intensity: val });
              }}
              className="w-full accent-[#62D5E8]"
            />

            <div className="flex items-center justify-between text-[11px]">
              <span className="text-[#93A4BE]">Beat Envelope</span>
              <button
                onClick={() => {
                  onUpdateStep(section.id, selectedStep.index, { active: !selectedStep.active });
                }}
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-medium ${
                  selectedStep.active ? 'bg-[#62D5E8]/20 text-[#62D5E8]' : 'bg-white/10 text-[#93A4BE]'
                }`}
              >
                {selectedStep.active ? 'Active' : 'Ducked (-24dB)'}
              </button>
            </div>
          </div>
        )}

        {/* 8. EXPORT GENUINE EDITED WAV (Offline Render) */}
        {onExportWav && (
          <button
            onClick={onExportWav}
            className="w-full py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-white flex items-center justify-center gap-2 transition-all mt-2"
            title="Render all multi-layer edits offline and download a standard 16-bit PCM WAV file"
          >
            <Download className="w-3.5 h-3.5 text-[#62D5E8]" />
            <span>Export Edited Audio (WAV)</span>
          </button>
        )}
      </div>
    </aside>
  );
};
