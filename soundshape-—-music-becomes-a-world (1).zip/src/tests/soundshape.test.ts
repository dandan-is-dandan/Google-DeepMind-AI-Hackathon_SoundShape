import { WorldSceneSchema, WorldScene } from '../types/world';
import { extractAudioFeatures } from '../audio/featureExtractor';
import { enrichSceneWithMusicalMetadata, formatTimestamp } from '../audio/metadataEnricher';

/**
 * Automated test suite for SoundShape
 */
export function runTests() {
  console.log('--- Running SoundShape Test Suite ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`✓ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`✗ FAIL: ${testName}`);
      failed++;
    }
  }

  // 1. Scene Parsing Validation Test (Valid Scene)
  const validScene: WorldScene = {
    duration: 24,
    worldTheme: 'dreamy_ocean',
    spatialArrangement: 'crescent_bay',
    overallMood: 'Serene ambient journey with rising harmonic intensity',
    globalPalette: ['#62D5E8', '#A58BFA', '#FFB66E'],
    terrainRoughness: 0.35,
    lightingAtmosphere: 'Cyan starlight with gentle mist',
    creativeRationale: 'Ethereal pads map to floating translucent glass islands.',
    sections: [
      {
        id: 'section_1',
        start: 0,
        end: 12,
        label: 'Ambient Intro',
        energy: 0.3,
        mood: 'Calm water surface',
        landscapeType: 'glass_island',
        dominantColor: '#62D5E8',
        accentColor: '#A58BFA',
        objects: [
          {
            id: 'rhythm_1',
            type: 'rhythm_towers',
            editable: true,
            name: 'Rhythm Towers',
            description: 'Soft harmonic pulses',
            rhythmSteps: [
              { index: 0, timeRatio: 0, intensity: 0.6, active: true, type: 'kick' },
              { index: 1, timeRatio: 0.5, intensity: 0.4, active: true, type: 'hihat' },
            ],
          },
        ],
      },
      {
        id: 'section_2',
        start: 12,
        end: 24,
        label: 'Climax',
        energy: 0.9,
        mood: 'Radiant crystal resonance',
        landscapeType: 'crystal_peak',
        dominantColor: '#A58BFA',
        accentColor: '#FFB66E',
        objects: [
          {
            id: 'core_2',
            type: 'energy_core',
            editable: true,
            name: 'Energy Core',
            description: 'Climax power',
            energyLevel: 0.9,
          },
        ],
      },
    ],
  };

  const parsed = WorldSceneSchema.safeParse(validScene);
  assert(parsed.success, 'Valid scene parsing succeeds');

  // 2. Invalid Scene Rejection Test (Less than 2 sections)
  const invalidScene1 = { ...validScene, sections: [validScene.sections[0]] };
  const rejected1 = WorldSceneSchema.safeParse(invalidScene1);
  assert(!rejected1.success, 'Rejects scene with less than 2 sections');

  // 3. Invalid Scene Rejection Test (Energy out of 0-1 bounds)
  const invalidScene2 = {
    ...validScene,
    sections: [
      { ...validScene.sections[0], energy: 1.5 },
      validScene.sections[1],
    ],
  };
  const rejected2 = WorldSceneSchema.safeParse(invalidScene2);
  assert(!rejected2.success, 'Rejects section with energy > 1.0');

  // 4. Section Timeline Consistency Test
  const coversAllTime =
    validScene.sections[0].start === 0 &&
    validScene.sections[validScene.sections.length - 1].end === validScene.duration;
  assert(coversAllTime, 'Sections span from 0 to full duration');

  // 5. Parameter Clamping Test (Intensity bounds)
  const rawIntensity = 1.35;
  const clampedIntensity = Math.max(0, Math.min(1, rawIntensity));
  assert(clampedIntensity === 1.0, 'Parameter intensity is clamped to 1.0');

  // 6. Metadata Enrichment Test
  const enriched = enrichSceneWithMusicalMetadata(validScene, null);
  const step0 = enriched.sections[0].objects[0].rhythmSteps![0];
  assert(step0.objectId === 'tower_section_1_step0', 'Metadata enricher populates unique objectId');
  assert(step0.eventTimeSeconds === 0, 'Step 0 eventTimeSeconds calculated accurately');
  assert(step0.instrumentType?.includes('Synthesized Kick Drum') === true, 'Step 0 instrumentType assigned');
  assert(typeof step0.sourceFeatureType === 'string' && step0.sourceFeatureType.length > 0, 'Step 0 sourceFeatureType assigned');

  // 7. Moment Playback Window Clamping Test
  const clipDuration = 24.0;
  const targetTime = 0.5; // near start
  const startOffset = Math.max(0, targetTime - 1.0);
  const momentDuration = Math.min(2.0, clipDuration - startOffset);
  assert(startOffset === 0, 'Moment start offset clamped to 0 for early timestamps');
  assert(momentDuration === 2.0, 'Moment duration stays 2.0s');

  const nearEndTime = 23.5;
  const endStartOffset = Math.max(0, nearEndTime - 1.0);
  const endMomentDuration = Math.min(2.0, clipDuration - endStartOffset);
  assert(endStartOffset === 22.5, 'Moment near end starts at 22.5s');
  assert(endMomentDuration === 1.5, 'Moment near end clamped to remaining 1.5s duration');

  // 8. Timestamp Formatting Test
  assert(formatTimestamp(65.3) === '01:05.3', 'Formats timestamp 65.3s as 01:05.3');

  // 9. Multi-Layer Simultaneous Edits at Same Timestamp (Prompt 4)
  const testEdits = [
    {
      editId: 'edit_energy_1',
      sectionId: 'section_1',
      scope: 'moment' as const,
      startTime: 5.0,
      endTime: 5.5,
      layer: 'energy' as const,
      property: 'Loudness Gain',
      originalValue: 0,
      editedValue: 3.5,
      unit: 'dB',
      enabled: true,
    },
    {
      editId: 'edit_bass_1',
      sectionId: 'section_1',
      scope: 'moment' as const,
      startTime: 5.0,
      endTime: 5.5,
      layer: 'bass' as const,
      property: 'Low-Shelf EQ',
      originalValue: 0,
      editedValue: 6.0,
      unit: 'dB',
      enabled: true,
    },
    {
      editId: 'edit_texture_1',
      sectionId: 'section_1',
      scope: 'moment' as const,
      startTime: 5.0,
      endTime: 5.5,
      layer: 'texture' as const,
      property: 'Filter Cutoff',
      originalValue: 12000,
      editedValue: 3200,
      unit: 'Hz',
      enabled: true,
    },
  ];

  const sameTimeEdits = testEdits.filter((e) => e.startTime === 5.0 && e.endTime === 5.5);
  assert(sameTimeEdits.length === 3, 'Multiple independent edits coexist at exact same timestamp');
  assert(new Set(sameTimeEdits.map((e) => e.layer)).size === 3, 'Each simultaneous edit targets a distinct musical layer');

  // 10. Moment Window Bounded Duration Verification (200ms to 2000ms)
  const dur1 = Math.max(0.2, Math.min(2.0, 0.1));
  const dur2 = Math.max(0.2, Math.min(2.0, 2.5));
  const dur3 = Math.max(0.2, Math.min(2.0, 0.5));
  assert(dur1 === 0.2, 'Clamps undersized moment window to 200ms');
  assert(dur2 === 2.0, 'Clamps oversized moment window to 2000ms');
  assert(dur3 === 0.5, 'Preserves default 500ms moment window');

  console.log(`--- Test Results: ${passed} passed, ${failed} failed ---`);
  return { passed, failed };
}

runTests();
