import { RealAudioEngine } from '../src/audio/realAudioEngine';

console.log('--- SOUNDSHAPE REAL AUDIO DSP MATH & FORMULA VERIFICATION ---');

// 1. Verify Bass Intensity mapping
const minBassDb = RealAudioEngine.bassIntensityToDb(0.0);
const midBassDb = RealAudioEngine.bassIntensityToDb(0.5);
const maxBassDb = RealAudioEngine.bassIntensityToDb(1.0);

console.log(`Bass River 0.0: ${minBassDb.toFixed(2)} dB (Expected: -14.00 dB)`);
console.log(`Bass River 0.5: ${midBassDb.toFixed(2)} dB (Expected: 0.00 dB)`);
console.log(`Bass River 1.0: +${maxBassDb.toFixed(2)} dB (Expected: +11.00 dB)`);

if (Math.abs(minBassDb - -14.0) > 0.01 || Math.abs(midBassDb - 0.0) > 0.01 || Math.abs(maxBassDb - 11.0) > 0.01) {
  throw new Error('Bass River dB mapping assertion failed');
}

// 2. Verify Energy Core gain mapping
const minEnergyGain = RealAudioEngine.energyLevelToLinearGain(0.0);
const midEnergyGain = RealAudioEngine.energyLevelToLinearGain(0.5);
const maxEnergyGain = RealAudioEngine.energyLevelToLinearGain(1.0);

console.log(`Energy Core 0.0: ${minEnergyGain.toFixed(2)}x (Expected: 0.35x / -9.1 dB)`);
console.log(`Energy Core 0.5: ${midEnergyGain.toFixed(2)}x (Expected: 1.00x / 0 dB)`);
console.log(`Energy Core 1.0: ${maxEnergyGain.toFixed(2)}x (Expected: 1.55x / +3.8 dB)`);

if (Math.abs(minEnergyGain - 0.35) > 0.01 || Math.abs(midEnergyGain - 1.0) > 0.01 || Math.abs(maxEnergyGain - 1.55) > 0.01) {
  throw new Error('Energy Core linear gain mapping assertion failed');
}

// 3. Verify Rhythm Crystal gain envelope mapping
const mutedGain = RealAudioEngine.rhythmIntensityToGain(0.8, false);
const duckedGain = RealAudioEngine.rhythmIntensityToGain(0.0, true);
const neutralGain = RealAudioEngine.rhythmIntensityToGain(0.5, true);
const accentedGain = RealAudioEngine.rhythmIntensityToGain(1.0, true);

console.log(`Rhythm Crystal Muted: ${mutedGain.toFixed(2)}x (Expected: 0.06x / -24 dB)`);
console.log(`Rhythm Crystal 0% (Duck): ${duckedGain.toFixed(2)}x (Expected: 0.15x / -16 dB)`);
console.log(`Rhythm Crystal 50% (Neutral): ${neutralGain.toFixed(2)}x (Expected: 1.00x / 0 dB)`);
console.log(`Rhythm Crystal 100% (Accent): ${accentedGain.toFixed(2)}x (Expected: 1.85x / +5.3 dB)`);

if (mutedGain !== 0.06 || Math.abs(duckedGain - 0.15) > 0.01 || Math.abs(neutralGain - 1.0) > 0.01 || Math.abs(accentedGain - 1.85) > 0.01) {
  throw new Error('Rhythm Crystal gain mapping assertion failed');
}

// 4. Verify Rhythm Window calculations
const windowInfo = RealAudioEngine.getRhythmWindow(12.5, 30.0, 16);
console.log(`Rhythm Window: duration = ${Math.round(windowInfo.duration * 1000)}ms, [${windowInfo.start.toFixed(2)}s - ${windowInfo.end.toFixed(2)}s]`);
if (windowInfo.duration < 0.15 || windowInfo.duration > 0.4) {
  throw new Error('Rhythm window duration out of target 150-400ms range');
}

console.log('✅ ALL DSP MATH CHECKS PASSED SUCCESSFULLY!');
