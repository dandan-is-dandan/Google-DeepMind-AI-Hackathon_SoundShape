import * as THREE from 'three';
import { buildWorldLandscape } from '../src/three/islandGenerator';
import { determineLandscapeArchetype } from '../src/three/landscapeArchetypes';
import { WorldScene } from '../src/types/world';

console.log('=== SOUNDSHAPE PROCEDURAL WORLD GENERATION VERIFICATION ===\n');

// -------------------------------------------------------------
// TRACK A: "Cosmic Aurora" (Calm Ambient Dreamy Ocean Track)
// -------------------------------------------------------------
const trackAScene: WorldScene = {
  duration: 24,
  worldTheme: 'dreamy_ocean',
  spatialArrangement: 'linear_archipelago',
  overallMood: 'Ethereal cosmic sanctuary with translucent glass pools and floating starlight',
  globalPalette: ['#62D5E8', '#A58BFA', '#38BDF8', '#0B1020'],
  terrainRoughness: 0.25,
  lightingAtmosphere: 'Soft cyan and lavender caustics illuminating translucent floating atolls',
  creativeRationale: 'Calm ambient progression characterized by low energy, open breathing spaces, and gentle curves.',
  sections: [
    {
      id: 'section_1',
      start: 0,
      end: 8,
      label: 'Starlight Opening',
      energy: 0.25,
      mood: 'Still, translucent, ambient reflection',
      landscapeType: 'glass_island',
      dominantColor: '#62D5E8',
      accentColor: '#A58BFA',
      objects: [
        {
          id: 'rhythm_0',
          type: 'rhythm_towers',
          editable: true,
          name: 'Rhythm Towers',
          description: 'Delicate crystal pulses',
          rhythmSteps: [
            { index: 0, timeRatio: 0.1, intensity: 0.4, active: true, type: 'kick' },
            { index: 1, timeRatio: 0.5, intensity: 0.35, active: true, type: 'snare' },
            { index: 2, timeRatio: 0.9, intensity: 0.3, active: true, type: 'hihat' },
          ],
        },
        { id: 'bass_0', type: 'bass_river', editable: true, name: 'Bass River', description: 'Gentle stream', bassIntensity: 0.3 },
        { id: 'core_0', type: 'energy_core', editable: true, name: 'Energy Core', description: 'Floating pearl', energyLevel: 0.25 },
      ],
    },
    {
      id: 'section_2',
      start: 8,
      end: 16,
      label: 'Celestial Drift',
      energy: 0.38,
      mood: 'Gentle swelling harmonic ribbons',
      landscapeType: 'glass_island',
      dominantColor: '#A58BFA',
      accentColor: '#62D5E8',
      objects: [
        {
          id: 'rhythm_1',
          type: 'rhythm_towers',
          editable: true,
          name: 'Rhythm Towers',
          description: 'Harmonic crystal ripples',
          rhythmSteps: [
            { index: 0, timeRatio: 0.2, intensity: 0.45, active: true, type: 'kick' },
            { index: 1, timeRatio: 0.6, intensity: 0.4, active: true, type: 'snare' },
          ],
        },
        { id: 'bass_1', type: 'bass_river', editable: true, name: 'Bass River', description: 'Flowing current', bassIntensity: 0.4 },
        { id: 'core_1', type: 'energy_core', editable: true, name: 'Energy Core', description: 'Luminous core', energyLevel: 0.38 },
      ],
    },
    {
      id: 'section_3',
      start: 16,
      end: 24,
      label: 'Luminescent Horizon',
      energy: 0.48,
      mood: 'Warm twilight resonance',
      landscapeType: 'floating_plateau',
      dominantColor: '#38BDF8',
      accentColor: '#FFB66E',
      objects: [
        {
          id: 'rhythm_2',
          type: 'rhythm_towers',
          editable: true,
          name: 'Rhythm Towers',
          description: 'Ascending crystal terrace',
          rhythmSteps: [
            { index: 0, timeRatio: 0.25, intensity: 0.5, active: true, type: 'kick' },
            { index: 1, timeRatio: 0.75, intensity: 0.5, active: true, type: 'snare' },
          ],
        },
        { id: 'bass_2', type: 'bass_river', editable: true, name: 'Bass River', description: 'Broad pool', bassIntensity: 0.5 },
        { id: 'core_2', type: 'energy_core', editable: true, name: 'Energy Core', description: 'Twilight beacon', energyLevel: 0.48 },
      ],
    },
  ],
};

// -------------------------------------------------------------
// TRACK B: "Cyber Pulse Apex" (High-Energy Electronic / Canyon Track)
// -------------------------------------------------------------
const trackBScene: WorldScene = {
  duration: 24,
  worldTheme: 'crystal_canyon',
  spatialArrangement: 'fractured_spire',
  overallMood: 'Aggressive rhythmic ascent culminating in fractured mountain canyon peaks',
  globalPalette: ['#06B6D4', '#EC4899', '#8B5CF6', '#0F172A'],
  terrainRoughness: 0.85,
  lightingAtmosphere: 'High-contrast neon lasers cutting through obsidian cliff crags',
  creativeRationale: 'Heavy transients and relentless bass drive high physical terraces and soaring crystal peaks.',
  sections: [
    {
      id: 'section_1',
      start: 0,
      end: 8,
      label: 'Sub-bass Ignition',
      energy: 0.52,
      mood: 'Propulsive stepped rhythm launch',
      landscapeType: 'cyber_grid',
      dominantColor: '#06B6D4',
      accentColor: '#FFB66E',
      objects: [
        {
          id: 'rhythm_0',
          type: 'rhythm_towers',
          editable: true,
          name: 'Rhythm Towers',
          description: 'Stepped city towers',
          rhythmSteps: [
            { index: 0, timeRatio: 0.1, intensity: 0.7, active: true, type: 'kick' },
            { index: 1, timeRatio: 0.5, intensity: 0.65, active: true, type: 'snare' },
            { index: 2, timeRatio: 0.9, intensity: 0.6, active: true, type: 'hihat' },
          ],
        },
        { id: 'bass_0', type: 'bass_river', editable: true, name: 'Bass River', description: 'Engineered canal', bassIntensity: 0.65 },
        { id: 'core_0', type: 'energy_core', editable: true, name: 'Energy Core', description: 'Grid nexus', energyLevel: 0.52 },
      ],
    },
    {
      id: 'section_2',
      start: 8,
      end: 16,
      label: 'Architectural Surge',
      energy: 0.68,
      mood: 'Ascending terraces and viaduct arches',
      landscapeType: 'neon_spires',
      dominantColor: '#8B5CF6',
      accentColor: '#EC4899',
      objects: [
        {
          id: 'rhythm_1',
          type: 'rhythm_towers',
          editable: true,
          name: 'Rhythm Towers',
          description: 'High-velocity rhythm towers',
          rhythmSteps: [
            { index: 0, timeRatio: 0.15, intensity: 0.8, active: true, type: 'kick' },
            { index: 1, timeRatio: 0.45, intensity: 0.75, active: true, type: 'snare' },
            { index: 2, timeRatio: 0.85, intensity: 0.7, active: true, type: 'hihat' },
          ],
        },
        { id: 'bass_1', type: 'bass_river', editable: true, name: 'Bass River', description: 'Surging conduit', bassIntensity: 0.75 },
        { id: 'core_1', type: 'energy_core', editable: true, name: 'Energy Core', description: 'High-voltage reactor', energyLevel: 0.68 },
      ],
    },
    {
      id: 'section_3',
      start: 16,
      end: 24,
      label: 'Fractured Apex Drop',
      energy: 0.92,
      mood: 'Monumental crystalline canyon eruption',
      landscapeType: 'crystal_peak',
      dominantColor: '#EC4899',
      accentColor: '#06B6D4',
      objects: [
        {
          id: 'rhythm_2',
          type: 'rhythm_towers',
          editable: true,
          name: 'Rhythm Towers',
          description: 'Jagged canyon obelisks',
          rhythmSteps: [
            { index: 0, timeRatio: 0.05, intensity: 0.95, active: true, type: 'kick' },
            { index: 1, timeRatio: 0.35, intensity: 0.9, active: true, type: 'snare' },
            { index: 2, timeRatio: 0.65, intensity: 0.9, active: true, type: 'kick' },
            { index: 3, timeRatio: 0.95, intensity: 0.85, active: true, type: 'hihat' },
          ],
        },
        { id: 'bass_2', type: 'bass_river', editable: true, name: 'Bass River', description: 'Violent neon fissure', bassIntensity: 0.95 },
        { id: 'core_2', type: 'energy_core', editable: true, name: 'Energy Core', description: 'Colossal apex star', energyLevel: 0.92 },
      ],
    },
  ],
};

// 1. Build 3D World for Track A
const worldA = buildWorldLandscape(trackAScene);
console.log('--- TRACK A: "Cosmic Aurora" ---');
worldA.islands.forEach((isl, i) => {
  console.log(`Island #${i + 1} (${isl.sectionId}):`);
  console.log(`  Archetype: ${isl.archetype}`);
  console.log(`  Center: (${isl.center.x.toFixed(1)}, ${isl.center.y.toFixed(1)}, ${isl.center.z.toFixed(1)})`);
  console.log(`  Radius: ${isl.radius.toFixed(2)}`);
  console.log(`  Rhythm Crystals: ${isl.rhythmTowers.length}`);
  console.log(`  Has Bass River: ${!!isl.bassRiverGroup}, Has Energy Core: ${!!isl.energyCoreGroup}`);
});

// 2. Build 3D World for Track B
const worldB = buildWorldLandscape(trackBScene);
console.log('\n--- TRACK B: "Cyber Pulse Apex" ---');
worldB.islands.forEach((isl, i) => {
  console.log(`Island #${i + 1} (${isl.sectionId}):`);
  console.log(`  Archetype: ${isl.archetype}`);
  console.log(`  Center: (${isl.center.x.toFixed(1)}, ${isl.center.y.toFixed(1)}, ${isl.center.z.toFixed(1)})`);
  console.log(`  Radius: ${isl.radius.toFixed(2)}`);
  console.log(`  Rhythm Crystals: ${isl.rhythmTowers.length}`);
  console.log(`  Has Bass River: ${!!isl.bassRiverGroup}, Has Energy Core: ${!!isl.energyCoreGroup}`);
});

// 3. ASSERTIONS: Verify Genuine Structural Differences
console.log('\n--- VERIFYING STRUCTURAL DIFFERENTIATION ASSERTIONS ---');

// Assertion 1: Chronological Left-to-Right Ordering
for (let i = 0; i < worldA.islands.length - 1; i++) {
  if (worldA.islands[i].center.x >= worldA.islands[i + 1].center.x) {
    throw new Error(`Track A chronological ordering failure at island ${i}`);
  }
  if (worldB.islands[i].center.x >= worldB.islands[i + 1].center.x) {
    throw new Error(`Track B chronological ordering failure at island ${i}`);
  }
}
console.log('✅ Assertion 1 PASSED: Strict Left-to-Right Chronological Island Ordering verified.');

// Assertion 2: Distinct Archetypes across contrasting tracks
const archetypesA = worldA.islands.map((isl) => isl.archetype);
const archetypesB = worldB.islands.map((isl) => isl.archetype);

console.log(`Track A Archetypes: ${archetypesA.join(', ')}`);
console.log(`Track B Archetypes: ${archetypesB.join(', ')}`);

if (archetypesA.includes('fractured_peak') && !archetypesA.includes('glass_sanctuary')) {
  throw new Error('Track A should be dominated by glass_sanctuary and calm landscapes');
}
if (!archetypesB.includes('fractured_peak')) {
  throw new Error('Track B apex section must generate a fractured_peak archetype');
}
console.log('✅ Assertion 2 PASSED: Contrasting music generates measurably distinct landscape archetypes.');

// Assertion 3: Elevation Difference Reflecting Energy
const avgElevationA = worldA.islands.reduce((sum, isl) => sum + isl.center.y, 0) / worldA.islands.length;
const avgElevationB = worldB.islands.reduce((sum, isl) => sum + isl.center.y, 0) / worldB.islands.length;
console.log(`Track A Avg Elevation: ${avgElevationA.toFixed(2)}, Track B Avg Elevation: ${avgElevationB.toFixed(2)}`);

if (avgElevationB <= avgElevationA) {
  throw new Error('Track B (high-energy) must have higher spatial elevation than Track A (ambient)');
}
console.log('✅ Assertion 3 PASSED: Regional elevation deterministically maps to audio energy.');

// Assertion 4: Separation of Environmental vs Editable Objects
let totalTowersA = 0;
let totalTerrainMeshesA = 0;
worldA.rootGroup.traverse((child) => {
  if (child.userData?.isRhythmTower) totalTowersA++;
  if (child.userData?.isIslandTerrain || child.userData?.isDecorative) totalTerrainMeshesA++;
});
console.log(`Track A: ${totalTowersA} editable rhythm crystals vs ${totalTerrainMeshesA} environmental/decorative meshes`);

if (totalTowersA === 0 || totalTerrainMeshesA === 0) {
  throw new Error('Failure in environmental vs editable object separation');
}
console.log('✅ Assertion 4 PASSED: Environmental geometry clearly separated from editable sculptures.');

console.log('\n🎉 ALL PROCEDURAL WORLD GENERATION VERIFICATIONS PASSED SUCCESSFULLY!');
